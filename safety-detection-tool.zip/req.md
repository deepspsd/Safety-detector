## Ground Floor

- \* Monitor inward and outward movement, in the main entrance and the passage,

Inwards - they need to show the invoice to the camera, / camera should scan that and store info along with the number of goods and if possible the weight, and then only the goods can enter.

Outwards - We will provide an order form, this needs to be shown to the camera, this form will be stored along with the image of the person showing the form, then only outward work should happen.

- A. Work should start by 8.

- B. Dough Mixing monitoring.

- C. Biscuit cutting section monitoring.

- D. Owen section monitoring.

- E. Packing section one in entrance and one next to the oven needs to be monitored

- F. Glassdoor entry attendance should happen, if any stock movement is there that also should be monitored.

- G. Main entrance loading and unloading monitoring should happen.

- H. Allthe 3 floors need to be clean, if not altern/ sound should come.

- Stocks should be monitored on the section behind the main entrance.

## What to be

- A. For employees to wear a head cap or not(headcap is compulsory with proper dressing).

- B. Same applies to Uniforms.

- C. Clean shaved or not.

- D. Hair cut (big hair is not allowed - optional)

- E. They should not chew(alert should come to admin)

Employee should not be Idle more than 5 mins.

## What to be monitored

1. for packing section, the employee can be idle in one position but their hands should be in movement.


- 2. Bangles are not allowed.

- 3. for the Dough section, after finishing the job the person should not be standing idle, he should move to another section, if not an alert/ alarm should come(during the process he should only monitor);

- 4. Under the biscuit cutting section, once the machine starts then the employee should start working, after finishing he/ she should go to the packing section.

## First Floor

- \> . Four working tables are there, in that 2 tables are complete work site, motioning needs to be done from 6 AM. The doe mixing work has to start by 6:00AM, it's compulsory.

- ® Dress code same monitoring

- [2] Lift monitoring for all 3 floors.

- Raw material stock needs to be monitored in all 3 floors.

- m Under the section we have cylinders that need to be monitored, usage, count the passage number of usage days.

- No one should be idle for more than 5 mins.

- [2] Dress code.

- x . Item monitoring.

- a. Items should not keep openly

- b. Cleanliness.

- c. Items going in/out from the lift need to be monitored. Where they are being kept. On the second floor after finished goods that need to be monitored, it has been sent to the vehicle no not.

## Second Floor

- \> Here work starts by 5 AM.

- ® Once the fore is on, someone should be there to monitor(needs to make sure the gasis not being wasted, for ex, of water is boiling more than 10 mins then it is a loss of us, if oil is. getting heat and being idle more than 10 mins, then it is a loss for us.)

- al Dress code is compulsory for all the 3 floors

- Cleaning is compulsory.

- m Stocks need to be monitored in all the floors.


- F. Noo ne should simply eat the ite ms/ dry fruits from the store,

- G. alarm is stealing/ hrowing/ passing pi the Koods/ goo Items from windows, then an alert/ sh ould come Immediately.

- H. If any car camera is not working, then an alert should come t the hi admi "

- I. If someone is nding in front of the camera for more than 1 mins, then an alert/ sound should come.

## Shop

- A. Moni nitor cash (if ifi it goes to the cashbox, they should not put it in their pocket).

- B. Monitor dress code.

- C. If they are paying the vendor -> we need to take a picture of the payee.

- D. How much time they are standing idle.

- E. If an employee is not there in the shop for more than 1 mins, an alert should come to the admin.

## In all Store-

- 1. Inward and outward in store to be monitored

- 2. Authorised entry.

- Dashboard should be clean and easy to understand.

- Mobile notifications are compulsory.

- All the data needs to be stored on premise.

- Take of the data security part. care
