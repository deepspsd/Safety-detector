# 🏭 OccuSafe — Complete Model Upgrade & Fine-Tuning Guide
### Biscuit Factory Safety Detection System (Client-Specific)

---

## 📋 Project Understanding Summary

### What You Already Have
| Component | Detail |
|---|---|
| **Base Model** | `ppe.pt` — YOLOv8, 10 classes, ~87MB |
| **Helmet Model** | `helmet_model.pt` — keremberke/yolov8m-hard-hat-detection, ~52MB |
| **Backend** | FastAPI + SQLite, WebSocket real-time stream |
| **Frontend** | React 19 + Vite, live monitor, alerts dashboard |
| **Source Repo** | [biswadeep-roy/Safety-Detection-YOLOv8](https://github.com/biswadeep-roy/Safety-Detection-YOLOv8) |

### What `ppe.pt` Currently Detects
```
0: Hardhat          ✅ compliant
1: Mask             ✅ compliant
2: NO-Hardhat       ❌ violation
3: NO-Mask          ❌ violation
4: NO-Safety Vest   ❌ violation
5: Person           👤 neutral
6: Safety Cone      🟠 neutral
7: Safety Vest      ✅ compliant
8: machinery        🔵 neutral
9: vehicle          🔵 neutral
```

> [!NOTE]
> `helmet_model.pt` is a construction hardhat model. Bakery cloth caps are visually very different (soft vs rigid, color, shape). **Do not assume it works for bakery caps** — run a side-by-side val test on 50 sample bakery-cap frames first before deciding.

---

## 🧠 Three-Way Problem Taxonomy

> [!IMPORTANT]
> Before touching any model, requirements must be split into three technically distinct types. A single fine-tuned YOLO model **cannot solve all of them**.

| Problem Type | Definition | Solved By |
|---|---|---|
| **Object / PPE Detection** | Is X present or absent in a frame? (cap, bangles, document, cylinder) | YOLOv8 fine-tuned model |
| **Temporal / Behavioral** | Idle time, standing duration, work-start compliance, camera downtime | Object tracking (ByteTrack) + Rule Engine (Python, no ML) |
| **Action / State Recognition** | Chewing, hands-in-motion vs idle, boiling water/oil idle | MediaPipe landmarks / frame-diff heuristics + rules |

Only the **first category** is a "fine-tune the model" task. The rest is application logic built on top of detection + tracking output. This distinction is critical to set correct client expectations.

---

## 🏭 Client Requirements — Full Gap Analysis

| Requirement | Floor | Feasibility | Solution |
|---|---|---|---|
| **Head cap / Hairnet** | All | ✅ YOLO class | Fine-tune `Bakery-Head-Cap` + `NO-Bakery-Head-Cap` |
| **Uniform / Dress code** | All | Medium | Partially covered by `Safety Vest` class; needs uniform annotation |
| **Clean shaved** | All | Hard | Deprioritize — subjective, face attribute model needed |
| **Hair length** | All | Hard | Optional — MediaPipe face landmark |
| **Chewing detection** | All | Medium | MediaPipe Face Mesh mouth-aspect-ratio, **not YOLO** |
| **Idle > 5 min** | All | ✅ Easy | ByteTrack ID + centroid-stationary timer (engineering, no ML) |
| **Hand movement (packing)** | Ground | Medium | YOLOv8-Pose or frame optical flow |
| **Bangles** | All | ✅ YOLO class | Fine-tune `Bangles` class (client footage only) |
| **Invoice / Form scanning** | Ground | Medium | Detect `Document-in-hand` + OCR pipeline (Section 9) |
| **Cylinder usage** | 1st | ✅ YOLO class | Fine-tune `Cylinder` class |
| **Gas stove + idle > 10 min** | 2nd | Hard v1 | D-Fire pre-trained model + FlameIdleMonitor (Section 9) |
| **Dirty floor** | All | Hard v1 | Frame-difference vs baseline (Section 9), not YOLO |
| **Cash pocket monitoring** | Shop | Hard | Hand-trajectory heuristic, ~50-60% v1 accuracy |
| **Stock kept openly** | All | Medium | `Exposed-Item` YOLO class |
| **Camera blocked > 1 min** | All | ✅ Easy | BBox overlap with camera zone + timer, zero ML |
| **Person absent from shop > 1 min** | Shop | ✅ Easy | Zone occupancy check, Person count = 0 alert |
| **Loading/unloading** | Ground | ✅ Covered | `vehicle` + `Person` already in ppe.pt |

---

## 🎯 MODEL UPGRADE PLAN

### Corrected New Classes (IDs 10–16, preserving IDs 0–9 intact)

> [!IMPORTANT]
> `NO-Bakery-Head-Cap` (ID 11) is the **critical paired violation class**. Without it the model has no signal to fire cap-missing alerts — it only knows when someone IS wearing the cap, not when they're NOT. Annotate both ID 10 and ID 11 in the same sessions.

```
Classes to add via fine-tuning:
10: Bakery-Head-Cap     ✅ compliant  — cloth cap worn correctly
11: NO-Bakery-Head-Cap  ❌ violation  — CRITICAL: cap absent/incorrectly worn
12: Bangles             ❌ violation  — always a violation in food production
13: Document-in-hand    🔵 neutral   — triggers OCR pipeline at entrance
14: Cylinder            🔵 neutral   — counted for usage logging
15: Exposed-Item        ❌ violation  — stock kept openly
16: Cashbox             🔵 neutral   — zone anchor for cash monitoring

Total: 17 classes (10 original + 7 new)

❌ DO NOT add dirty-floor or flame as YOLO classes.
   Use heuristic v1 approaches instead (Section 9 below) —
   far less annotation burden with acceptable v1 accuracy.
```

### System Architecture (Upgraded)

```
Camera Feed (RTSP/USB)
       |
       v
YOLOv8 Inference ── (ppe_factory_v2.pt — 17 classes)
       |
       v
ByteTrack / BoT-SORT ── (built into Ultralytics, persistent track IDs)
       |
       v
Zone Mapper ── (per-camera polygon zones: entrance, dough table, oven, packing, shop)
       |
       v
Rule Engine ── (idle timers, OCR trigger, dress-code checks, time-of-day checks)
       |
       v
Alert Dispatcher ── (FCM push, sound alarm, DB log, snapshot save)
```

### Phase 2 — Pose Estimation (YOLOv8-Pose)

Used for: hand movement detection (packing section), chewing detection, idle posture.
Model: `yolov8n-pose.pt` — use as-is, no fine-tuning needed for v1.

### Phase 3 — Face Attribute Model

Used for: clean shave check, hair length check, attendance identity.
Use: `face_recognition` + DeepFace or custom binary classifier.

---

## 📦 BEST PUBLIC DATASETS FOR FINE-TUNING

> [!NOTE]
> None of these fully solve bakery-specific classes. Use them to **seed** head-cap and uniform classes for faster convergence — the dominant training signal must come from the client's own 15-day footage.

### 1. Head Cap / Hairnet (Best Match for Bakery)

| Dataset | Relevance | Source |
|---|---|---|
| **SHEL5K** (5K images, 6 classes) | Head cap/hardhat baseline, robustness | `github.com/MoyoG/SHEL5K` |
| **Hairnet Detection** (Prince Suman, 3.5K imgs) | Closest analog to bakery cloth cap — **direct fit** | `universe.roboflow.com` → search "hairnet-detection-vktcj" |
| **Safety Food System** (9.9K imgs) | Best match: food-industry uniform + headcap combined | `universe.roboflow.com` → search "Safety Food System hairnet" |
| **EPP Internship** (4.3K imgs, coverall/hairnet/mask) | Food-grade PPE, multi-class | `universe.roboflow.com` → search "EPP Internship hairnet" |
| **Cap and Hairnet Material** (374 imgs) | Small but bakery-cap-specific | `universe.roboflow.com/tshirtsvariations/cap-and-hairnet-material` |

> **Search tip:** `universe.roboflow.com/search?q=class:hairnet` — returns a live updated list.

### 2. Head Cap — What NOT to Use

| Dataset | Why to Skip |
|---|---|
| **DeepFashion2** | Fashion clothing, not food-industry caps |
| **iMaterialist** | Retail fashion segments, wrong domain |
| **Construction PPE datasets** | Rigid hardhats, not cloth caps |

### 3. Bangles / Jewellery

No public dataset exists. **100% dependent on client footage.** Annotate wrist-region crops heavily augmented (rotate, brightness, blur).

### 4. Fire / Flame (for v1 heuristic model — NOT baked into ppe.pt)

| Dataset | Source | Size |
|---|---|---|
| **D-Fire** | [github.com/gaiasd/DFireDataset](https://github.com/gaiasd/DFireDataset) | 21,000 images |
| **Fire Detection YOLOv8** | Roboflow — "fire flame detection" | 6,000+ |

### 5. Medical PPE (Extra Variance)

| Dataset | Source |
| **CPPE-5** | `huggingface.co/datasets/cppe-5` — extra mask/uniform variance |

### 6. Beard / Clean-Shaved (For YOLOv8n/s)

> Since a lightweight YOLO model is preferred over heavy face-recognition pipelines, you can fine-tune YOLOv8 to detect `Beard` vs `Clean-Shaven-Face` as separate classes.
| Dataset | Source |
|---|---|
| **CelebA (Annotated for Beard)** | Extract images with the `Male` and `No_Beard` / `5_o_Clock_Shadow` attributes, convert to YOLO format. |
| **Masked/Unmasked Face Datasets** | Many COVID-era datasets have `Face` classes which can be manually re-labeled for beard presence. |
| **Roboflow Universe - Beard Detection** | Search "Beard detection" (e.g. `universe.roboflow.com/beard-detection-k9j3g`). Contains cropped face bounding boxes labeled for beard/no-beard. |

### 7. Chewing / Eating (For YOLOv8n/s)

> Detecting chewing directly via YOLO bounding boxes is challenging due to the temporal nature of the action. However, you can train a YOLO classifier or object detector on the `Person-Eating` vs `Person-Idle` action.
| Dataset | Source |
|---|---|
| **AVA Dataset (Action Visual Understanding)** | Contains bounding boxes for actions like "eating", "drinking", "talking". Convert the `eating` annotations to YOLO format. |
| **Roboflow Universe - Eating/Drinking** | Search `eating drinking detection` for pre-annotated YOLO datasets capturing hand-to-mouth actions. |

### 8. Forklift / Pallet Truck

| Dataset | Source |
|---|---|
| **OpenImages V7** | Filter for `Forklift` class. Provides thousands of high-quality bounding box annotations. |
| **Roboflow - Forklift Detection** | Search `forklift`. Extremely common industrial dataset, very high accuracy right out of the box. |
| **COCO Dataset** | Contains `truck` and `car`, but OpenImages is better for specific industrial vehicles like forklifts and pallet jacks. |

---

## 🔬 FINE-TUNING ON KAGGLE — STEP-BY-STEP GUIDE

> [!IMPORTANT]
> Kaggle gives **30h free GPU per week** (T4 x2 or P100). This is sufficient for YOLOv8 fine-tuning.

### Step 1: Upload Assets as Kaggle Datasets

- **Dataset 1:** `ppe-weights` — upload `ppe.pt`
- **Dataset 2:** `bakery-dataset` — YOLO-format images/labels/data.yaml (built in Section below)
- **Notebook settings:** Accelerator → GPU T4 x2, Internet → ON

### Step 2: Install Dependencies

```python
!pip install ultralytics easyocr -q
from ultralytics import YOLO
import torch
print(torch.cuda.is_available(), torch.cuda.get_device_name(0))
```

### Step 3: `data.yaml` — 17 Classes (10 original + 7 new)

> **Note:** `NO-Bakery-Head-Cap` (ID 11) is the violation class paired with `Bakery-Head-Cap` (ID 10). IDs 12–16 are the new factory-specific classes.

```yaml
path: /kaggle/input/bakery-dataset
train: images/train
val:   images/val
nc: 17
names:
  0: Hardhat
  1: Mask
  2: NO-Hardhat
  3: NO-Mask
  4: NO-Safety Vest
  5: Person
  6: Safety Cone
  7: Safety Vest
  8: machinery
  9: vehicle
  10: Bakery-Head-Cap       # compliant — cloth cap worn correctly
  11: NO-Bakery-Head-Cap    # violation — cap absent/incorrectly worn ← CRITICAL
  12: Bangles               # violation — always flagged in food production
  13: Document-in-hand      # neutral — triggers OCR pipeline at entrance
  14: Cylinder              # neutral — logged for usage counting
  15: Exposed-Item          # violation — stock kept openly
  16: Cashbox               # neutral — zone anchor for cash monitoring
```

### Step 4: Fine-Tune Command

```python
from ultralytics import YOLO

model = YOLO('/kaggle/input/ppe-weights/ppe.pt')

results = model.train(
    data='/kaggle/input/bakery-dataset/data.yaml',
    epochs=100,
    imgsz=640,
    batch=16,             # T4 GPU (16GB VRAM)
    freeze=10,            # freeze backbone → protects original 10-class knowledge
    lr0=0.001,            # lower LR for fine-tuning (not training from scratch)
    lrf=0.01,
    patience=20,          # early stop if val mAP plateaus
    momentum=0.937,
    weight_decay=0.0005,
    warmup_epochs=3,
    workers=2,
    device=0,
    project='bakery_finetune',
    name='v1',
    # Augmentation — important for variable bakery lighting
    hsv_h=0.015,
    hsv_s=0.7,
    hsv_v=0.4,
    flipud=0.1,
    fliplr=0.5,
    mosaic=1.0,
    mixup=0.2,
    save=True,
    save_period=10,
)
# freeze=10 is the key safeguard against catastrophic forgetting.
# It keeps the backbone frozen while the head learns the 7 new classes.
```

### Step 5: Validate — Confirm Old Classes Did Not Degrade

> [!WARNING]
> After `.train()` the `model` object points to the **last epoch checkpoint**, not the best checkpoint. Reload `best.pt` explicitly before calling `.val()` — otherwise metrics are misleading.

```python
# Reload best checkpoint explicitly
best_model = YOLO('bakery_finetune/v1/weights/best.pt')
metrics = best_model.val(data='/kaggle/input/bakery-dataset/data.yaml')

print(f"Overall mAP50:    {metrics.box.map50:.3f}")
print(f"Overall mAP50-95: {metrics.box.map:.3f}")
print()
print("Per-class mAP50-95:")
for i, name in best_model.names.items():
    per_cls = metrics.box.maps[i]
    flag = "⚠️  DEGRADED — raise freeze or lower lr0" if i < 10 and per_cls < 0.60 else ""
    print(f"  {i:2d}  {name:<25} {per_cls:.3f}  {flag}")

# Rule: if any original class (ID 0-9) drops > 5 mAP points vs ppe.pt baseline,
# increase freeze (e.g. freeze=15) or reduce lr0 (e.g. 0.0005) and retrain.
```

### Step 6: Export & Download

```python
# Export for deployment
best_model.export(format='onnx')  # or 'engine' for TensorRT on edge GPU

# Download
import shutil
shutil.copy('bakery_finetune/v1/weights/best.pt', '/kaggle/working/ppe_factory_v2.pt')
# /kaggle/working/ files are downloadable from the Kaggle UI
```

---

## 📹 CLIENT FOOTAGE — Data Collection Pipeline

> [!CAUTION]
> Real client footage = highest accuracy for bakery-specific classes. Keep it on-premise. Do not upload to Roboflow cloud if the client's data security requirement applies to annotation stage — use CVAT (self-hostable) instead.

### Step 1: Organize Footage by Camera/Zone

```
client_footage/
├── ground_floor/
│   ├── entrance_cam/      ← document scan, inward/outward
│   ├── dough_mixing_cam/
│   └── packing_cam/
├── first_floor/
│   ├── table_cam/
│   └── lift_cam/
└── second_floor/
    ├── stove_cam/         ← flame monitoring
    └── stock_cam/
```

### Step 2: Zone-Adaptive Frame Extraction

> Sample at different rates per zone — entrance/shop events are brief (document flash, hand-off) while oven/dough zones are slow and static.

```python
import cv2, os

# Frames to skip between saves (assumes ~25-30 fps camera)
ZONE_SAMPLE_RATES = {
    "entrance":     8,   # ~3 fps — document flashes are brief
    "shop_counter": 8,   # ~3 fps — fast hand movements
    "packing":     15,   # ~2 fps — hand movement detection
    "dough_table": 25,   # ~1 fps — slow static activity
    "oven":        25,   # ~1 fps — flame rarely changes fast
    "default":     25,
}

def extract_frames(video_path, out_dir, zone="default"):
    every_n_frames = ZONE_SAMPLE_RATES.get(zone, ZONE_SAMPLE_RATES["default"])
    os.makedirs(out_dir, exist_ok=True)
    cap = cv2.VideoCapture(video_path)
    i, saved = 0, 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if i % every_n_frames == 0:
            cv2.imwrite(f"{out_dir}/frame_{saved:05d}.jpg", frame)
            saved += 1
        i += 1
    cap.release()
    print(f"Saved {saved} frames from {video_path} (zone={zone}, skip={every_n_frames})")

# Usage:
# extract_frames("ground_floor/entrance_cam.mp4", "frames/entrance", zone="entrance")
# extract_frames("second_floor/oven_cam.mp4",     "frames/oven",     zone="oven")
```

> Prioritize frames across different times of day — bakery has bright oven-area light vs dim storage areas. Capture early-shift footage (5 AM, 6 AM) separately where lighting may be poor.

### Step 3: Auto-Label Existing Classes with `ppe.pt`

```python
from ultralytics import YOLO

model = YOLO("backend/ppe.pt")
model.predict(
    source="frames/",
    save=False,
    save_txt=True,   # saves YOLO .txt label files
    save_conf=True,
    conf=0.4,
    project="auto_labels/",
    name="pre_annotated"
)
# This pre-labels all 10 original classes — saves ~70% of manual annotation time.
# Manually draw boxes ONLY for the 7 new classes on top.
```

### Step 4: Annotation Tool Choice

| Tool | Best For | Privacy |
|---|---|---|
| **Roboflow** (roboflow.com) | Cloud browser-based, auto-label, built-in augmentation | Data leaves premises |
| **CVAT** (cvat.ai) | Self-hosted on factory server — footage never leaves | Full on-prem |
| **Label Studio** | Local, simpler UI | Full on-prem |

> If client's data security requirement extends to annotation, use **CVAT** self-hosted.

### Step 5: Minimum Data Volume Before First Training Run

| Class | Min Images | Notes |
|---|---|---|
| Bakery-Head-Cap | 300+ | Seed with Roboflow hairnet datasets, then client footage |
| NO-Bakery-Head-Cap | 300+ | **Must annotate in same sessions as ID 10** |
| Bangles | 150+ | Rare occurrence — heavy augmentation required |
| Document-in-hand | 250+ | High pose variance (angle, partial occlusion) |
| Cylinder | 100+ | Low visual variance, few images needed |
| Exposed-Item | 150+ | Zone-specific, moderate variance |
| Cashbox | 150+ | Zone-specific |

---

## ⚙️ TRACKING + RULE ENGINE (Non-ML Layer)

### ByteTrack Integration

```python
# Built into Ultralytics — no extra install needed
results = model.track(
    source='rtsp://camera_ip/stream',
    tracker='bytetrack.yaml',
    persist=True,
    stream=True
)
```

> [!WARNING]
> **FastAPI / asyncio threading issue:** `model.track()` is a **blocking generator loop**. Running it directly inside an `async` FastAPI WebSocket handler will freeze the entire event loop and block all other connections. Always wrap it in a background thread:

```python
import asyncio, threading, queue
from fastapi import WebSocket

def _tracking_worker(camera_url: str, result_q: queue.Queue):
    """Blocking loop — must run in a daemon thread, never in the async event loop."""
    for result in model.track(source=camera_url, tracker='bytetrack.yaml',
                               persist=True, stream=True, verbose=False):
        result_q.put(result)

async def ws_camera_stream(websocket: WebSocket, camera_id: str):
    await websocket.accept()
    result_q = queue.Queue(maxsize=5)
    t = threading.Thread(
        target=_tracking_worker,
        args=(CAMERA_URLS[camera_id], result_q),
        daemon=True
    )
    t.start()
    loop = asyncio.get_event_loop()
    while True:
        result = await loop.run_in_executor(None, result_q.get)
        # process result → send annotated frame back via websocket
```

### Zone Polygon Mapper

```python
from shapely.geometry import Point, Polygon

ZONES = {
    "entrance":     [(10,10),(300,10),(300,400),(10,400)],
    "dough_table":  [(320,50),(620,50),(620,350),(320,350)],
    "oven_section": [(640,80),(940,80),(940,380),(640,380)],
    "shop_counter": [(50,200),(350,200),(350,500),(50,500)],
    "packing":      [(400,300),(700,300),(700,580),(400,580)],
}
zone_polys = {k: Polygon(v) for k, v in ZONES.items()}

def get_zone(cx, cy):
    for name, poly in zone_polys.items():
        if poly.contains(Point(cx, cy)):
            return name
    return "unknown"
```

### Idle Timer State Machine

```python
import time

track_state = {}  # track_id -> {last_pos, last_moved_ts, zone}

IDLE_LIMIT_SEC = {
    "default":         300,  # 5 min — general idle rule (all floors)
    "camera_standing":  60,  # 1 min — blocking camera alert
    "gas_idle":        600,  # 10 min — stove/oil idle (2nd floor)
    "shop_counter":     60,  # 1 min — employee absent from shop
}

# Resolution-adaptive movement threshold.
# 15px works for 640px-wide frames; scale for higher-res feeds.
# e.g. 1920px wide → threshold = 45px
FRAME_WIDTH = 1280  # update per camera
MOVE_THRESHOLD_PX = max(10, int(15 * (FRAME_WIDTH / 640)))

def update_track(track_id, cx, cy, zone, now):
    st = track_state.get(track_id,
            {"last_pos": (cx, cy), "last_moved_ts": now, "zone": zone})
    dist = ((cx - st["last_pos"][0])**2 + (cy - st["last_pos"][1])**2) ** 0.5
    if dist > MOVE_THRESHOLD_PX:
        st["last_moved_ts"] = now
        st["last_pos"] = (cx, cy)
        st["zone"] = zone
    track_state[track_id] = st
    idle_for = now - st["last_moved_ts"]
    limit = IDLE_LIMIT_SEC.get(zone, IDLE_LIMIT_SEC["default"])
    if idle_for > limit:
        fire_alert(track_id, zone, idle_for)

def fire_alert(track_id, zone, idle_for):
    print(f"ALERT: track {track_id} idle {idle_for:.0f}s in zone {zone}")
    # → push to alert_service.py (DB + FCM)
```

### Shift-Start Time Checks

```python
import datetime

SHIFT_START = {
    "ground_floor":  "08:00",
    "first_floor":   "06:00",
    "second_floor":  "05:00",
}

def check_shift_start(floor, first_activity_ts):
    expected = datetime.datetime.strptime(SHIFT_START[floor], "%H:%M").time()
    if first_activity_ts.time() > expected:
        fire_alert(f"{floor}_late_start", floor, 0)
```

---

## 📄 OCR PIPELINE — Document-in-Hand (Invoice / Order Form)

> [!IMPORTANT]
> This is a **Phase 1 / P1 feature**. The client's entire inward/outward flow at the entrance depends on it. Trigger OCR when `Document-in-hand` (class 13) is detected at the entrance zone.

```python
# pip install easyocr
import easyocr
import cv2, datetime, numpy as np

_ocr_reader = easyocr.Reader(['en'], gpu=True)  # load once at startup

def scan_document_in_frame(frame: np.ndarray, bbox: list, direction: str) -> dict:
    """
    direction: 'inward' | 'outward'
    Returns dict stored in DB for audit trail.
    """
    x1, y1, x2, y2 = bbox
    h, w = frame.shape[:2]
    # Expand crop 10% to handle slight bbox misalignment
    pad_x = int((x2 - x1) * 0.10)
    pad_y = int((y2 - y1) * 0.10)
    crop = frame[max(0, y1-pad_y):min(h, y2+pad_y),
                 max(0, x1-pad_x):min(w, x2+pad_x)]

    # Pre-process: grayscale + Otsu threshold → improves OCR on printed text
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    _, sharp = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    results = _ocr_reader.readtext(sharp)
    text = " ".join([r[1] for r in results if r[2] > 0.4])  # confidence > 0.4

    return {
        "timestamp":  datetime.datetime.now().isoformat(),
        "direction":  direction,            # inward / outward
        "raw_text":   text,
        "approved":   len(text.strip()) > 10,   # basic sanity check
        "snapshot":   crop,                 # save image crop for audit trail
    }
# approved=False → fire deny-entry alert + sound alarm
# Integrates with existing alert_service.py
```

> **Limitation to set with client:** OCR accuracy degrades with handwritten forms, poor lighting, or motion blur. For v1, recommend **printed/typed invoices only**. Handwritten = Phase 2 fine-tune.

---

## 🔥 DIRTY-FLOOR & FLAME — v1 Heuristic Approach

> These were intentionally **NOT** added as YOLO classes — the annotation burden is very high and v1 accuracy from heuristics is acceptable enough to validate the feature with the client first.

### Dirty Floor — Client-Provided Clean Reference Photos as Baseline

> [!IMPORTANT]
> **The client will provide photos of how each floor/zone should look when it is clean.** These become the reference baseline — the detector compares every live frame against it and fires an alert when there is significant deviation. This is the right approach and requires **zero model training**.

**What to ask the client to provide:**
- One photo per camera view, taken from the exact same camera angle, when the floor/zone is at its cleanest (after morning cleaning before shift start)
- If different shifts have different lighting (e.g. lights off at 5 AM, on at 6 AM), ask for **one photo per lighting condition** per camera
- Photos should be taken from a fixed mounted camera, not a phone

**How to organize the baseline images:**

```
backend/
└── baselines/
    ├── ground_floor/
    │   ├── entrance_cam.jpg        ← client-provided clean photo
    │   ├── dough_mixing_cam.jpg
    │   └── packing_cam.jpg
    ├── first_floor/
    │   ├── table_cam_01.jpg
    │   └── lift_cam.jpg
    └── second_floor/
        ├── stove_cam.jpg
        └── stock_cam.jpg
```

**The detector — loads client-provided photos automatically:**

```python
import cv2, numpy as np, os

class DirtyFloorDetector:
    """
    Compares each live camera frame to the client-supplied 'clean state' photo.
    Significant pixel difference = debris / spill / dirt present → alert.

    The client provides the baseline photos — no training or annotation needed.
    One detector instance per camera. Reload baseline anytime client updates the photo.
    """
    def __init__(self, baseline_path: str, threshold: float = 0.08,
                 blur_kernel: int = 21, pixel_diff_cutoff: int = 30):
        """
        baseline_path : path to client-provided clean-state JPEG/PNG
        threshold     : fraction of pixels that must differ to trigger alert
                        (0.08 = 8% of frame — tune per zone based on FP rate)
        blur_kernel   : gaussian blur size to ignore minor texture differences
        pixel_diff_cutoff : minimum pixel intensity diff to count as changed
        """
        if not os.path.exists(baseline_path):
            raise FileNotFoundError(
                f"Clean baseline image not found: {baseline_path}\n"
                f"Ask client to provide a clean-state photo for this camera."
            )
        raw = cv2.imread(baseline_path, cv2.IMREAD_GRAYSCALE)
        self.baseline = cv2.GaussianBlur(raw, (blur_kernel, blur_kernel), 0)
        self.threshold = threshold
        self.blur_kernel = blur_kernel
        self.pixel_diff_cutoff = pixel_diff_cutoff
        self.baseline_path = baseline_path

    def reload(self):
        """Hot-reload baseline if client provides an updated clean photo."""
        raw = cv2.imread(self.baseline_path, cv2.IMREAD_GRAYSCALE)
        self.baseline = cv2.GaussianBlur(raw, (self.blur_kernel, self.blur_kernel), 0)

    def is_dirty(self, frame: np.ndarray, floor_mask: np.ndarray = None) -> tuple:
        """
        Returns (is_dirty: bool, changed_fraction: float)
        floor_mask : optional binary mask to ignore walls, equipment, etc.
                     Only evaluate floor area pixels — draw in any image editor.
        """
        # Resize frame to match baseline dimensions if camera resolution changed
        h, w = self.baseline.shape[:2]
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.resize(gray, (w, h))
        gray = cv2.GaussianBlur(gray, (self.blur_kernel, self.blur_kernel), 0)

        diff = cv2.absdiff(self.baseline, gray)
        if floor_mask is not None:
            diff = cv2.bitwise_and(diff, diff, mask=floor_mask)

        _, thresh = cv2.threshold(diff, self.pixel_diff_cutoff, 255, cv2.THRESH_BINARY)
        total_pixels = floor_mask.sum() // 255 if floor_mask is not None else thresh.size
        changed_fraction = thresh.sum() / (255 * total_pixels)
        return changed_fraction > self.threshold, round(changed_fraction, 4)


# ── Load all detectors at startup from the baselines/ folder ──────────
BASELINE_DIR = "baselines"

def load_all_detectors(threshold: float = 0.08) -> dict:
    """
    Scan baselines/ folder and create one DirtyFloorDetector per camera image.
    Returns dict: camera_id -> DirtyFloorDetector
    """
    detectors = {}
    for root, _, files in os.walk(BASELINE_DIR):
        for f in files:
            if f.lower().endswith(('.jpg', '.jpeg', '.png')):
                cam_id = os.path.splitext(f)[0]  # e.g. 'entrance_cam'
                path   = os.path.join(root, f)
                try:
                    detectors[cam_id] = DirtyFloorDetector(path, threshold=threshold)
                    print(f"✅ Loaded clean baseline for: {cam_id}")
                except FileNotFoundError as e:
                    print(f"⚠️  {e}")
    return detectors

detectors = load_all_detectors()


# ── Per-frame check (call from your tracking loop) ────────────────────
dirty_streak = {}  # cam_id -> consecutive dirty count

def check_floor(cam_id: str, frame: np.ndarray):
    if cam_id not in detectors:
        return
    is_dirty, fraction = detectors[cam_id].is_dirty(frame)
    if is_dirty:
        dirty_streak[cam_id] = dirty_streak.get(cam_id, 0) + 1
        # Alert only after 5 consecutive dirty checks (avoids false positives
        # when workers walk through the zone momentarily)
        if dirty_streak[cam_id] >= 5:
            fire_alert(cam_id, "floor_dirty",
                       extra=f"changed_fraction={fraction:.1%}")
    else:
        dirty_streak[cam_id] = 0  # reset streak on clean frame
```

**Practical notes:**
- `threshold=0.08` (8% of pixels changed) is a good starting point — tune per zone based on false positive rate in first week of deployment
- If a zone has fixed equipment (machines, tables), draw a **floor-only mask** in any paint tool (white = floor area to check, black = ignore) and pass it as `floor_mask`
- If the factory lights on between shifts, load a separate baseline per lighting condition using `detector.reload()` on a schedule
- Client can replace the baseline photo anytime (e.g. after repainting the floor) — just update the file and call `detector.reload()`
- Expected accuracy: ~75-85% for obvious debris/spills; misses subtle dirt or gradual grime. Not suitable as sole evidence for disciplinary action — flag for human review.

### Flame / Gas-Idle — Dedicated D-Fire Model (Separate Pass on Stove Camera Only)

```python
from ultralytics import YOLO
import time

# Pre-trained on D-Fire dataset (21K images) — no fine-tuning needed
# Download: https://github.com/gaiasd/DFireDataset
fire_model = YOLO('yolov8_dfire.pt')

class FlameIdleMonitor:
    """
    Fires alert when: flame ON + no person supervising + > 10 min.
    Run only on 2nd floor stove camera — don't run on all cameras (GPU cost).
    """
    def __init__(self, idle_limit_sec: int = 600):
        self.flame_first_seen: dict = {}   # zone_id -> first flame timestamp
        self.idle_limit = idle_limit_sec

    def update(self, zone_id: str, frame: np.ndarray, person_present: bool, now: float):
        results = fire_model(frame, conf=0.35, verbose=False)
        flame_on = any(
            fire_model.names[int(b.cls[0])] in ('fire', 'smoke')
            for r in results for b in r.boxes
        )
        if flame_on:
            self.flame_first_seen.setdefault(zone_id, now)
            idle_duration = now - self.flame_first_seen[zone_id]
            if not person_present and idle_duration > self.idle_limit:
                fire_alert(f"flame_idle_{zone_id}", zone_id, idle_duration)
        else:
            self.flame_first_seen.pop(zone_id, None)  # reset on flame off
# Expected accuracy: ~85% precision for open flame. Steam/vapor ~40-60% recall.
# Recommend IoT gas sensor as hardware fallback for reliable monitoring.
```

---

## ⚙️ BACKEND INTEGRATION

### 1. Update `yolo_service.py` — Extend Class Maps

```python
PPE_CLASS_NAMES = [
    'Hardhat', 'Mask', 'NO-Hardhat', 'NO-Mask',
    'NO-Safety Vest', 'Person', 'Safety Cone',
    'Safety Vest', 'machinery', 'vehicle',
    # NEW — factory-specific
    'Bakery-Head-Cap',      # 10
    'NO-Bakery-Head-Cap',   # 11  ← violation class
    'Bangles',              # 12  ← violation class
    'Document-in-hand',     # 13
    'Cylinder',             # 14
    'Exposed-Item',         # 15  ← violation class
    'Cashbox',              # 16
]

VIOLATION_CLASSES = {
    'NO-Hardhat', 'NO-Mask', 'NO-Safety Vest',
    'NO-Bakery-Head-Cap',   # NEW
    'Bangles',              # NEW — always a violation
    'Exposed-Item',         # NEW
}

COMPLIANT_CLASSES = {
    'Hardhat', 'Mask', 'Safety Vest',
    'Bakery-Head-Cap',      # NEW
}
```

### 2. Add Factory Worker Role Rules

```python
ROLE_RULES["Factory Worker"] = {
    "required_violations": [
        "NO-Bakery-Head-Cap",
        "Bangles",
    ],
    "required_compliant": ["Bakery-Head-Cap"],
    "required_sim": [],
    "severity": "critical",
    "alert_prefix": "🏭 Factory safety violation",
}
```

### 3. Deploy Updated Model

```bash
# 1. Download best.pt from Kaggle → rename
mv best.pt ppe_factory_v2.pt

# 2. Place in backend/
cp ppe_factory_v2.pt backend/ppe_factory_v2.pt

# 3. Update config.py
# YOLO_MODEL = "ppe_factory_v2.pt"
```

---

## 📱 MOBILE NOTIFICATIONS SETUP

> [!IMPORTANT]
> Client requirement: **Mobile notifications are compulsory.**

### Firebase Cloud Messaging (Recommended)

```python
# pip install firebase-admin
import firebase_admin
from firebase_admin import messaging, credentials

cred = credentials.Certificate("firebase-key.json")
firebase_admin.initialize_app(cred)

def send_mobile_alert(title: str, body: str, device_tokens: list):
    message = messaging.MulticastMessage(
        notification=messaging.Notification(title=title, body=body),
        tokens=device_tokens,
    )
    response = messaging.send_each_for_multicast(message)
    return response.success_count
# FCM only relays push notification — no video data leaves premises.
```

---

## 🔒 DATA SECURITY (On-Premise Requirement)

> [!CAUTION]
> Client explicitly requires: "All data stored on premise" + "Take care of data security."

### On-Premise Architecture

```
Factory LAN (Isolated — no internet for main pipeline)
├── NVR / Cameras   → RTSP streams (never leave factory)
├── Inference Server
│   ├── GPU: RTX 3060+ recommended
│   ├── RAM: 16GB+
│   └── OccuSafe FastAPI backend
├── Database
│   └── SQLite → PostgreSQL (recommended for multi-user + multi-camera)
└── Dashboard
    └── Accessible only on factory LAN IP range
```

```python
# .env — restrict to LAN only
ALLOWED_HOSTS=192.168.1.0/24

# Encrypt DB at rest: use sqlcipher3 or LUKS on NAS
# Local HTTPS: mkcert localhost 192.168.1.x
# Roles: extend existing JWT auth to admin / supervisor / viewer
```

---

## 🗺️ PHASED DELIVERY ROADMAP

> [!NOTE]
> **Annotation dependency:** Phases 1 and 3 both require labeled client footage. Start annotation work **in parallel with Phase 2 engineering** — do not wait. Bangles, Document-in-hand, and Cashbox must be annotated during Phase 2 so Phase 3 is not blocked.

| Phase | Week | Scope | Depends On |
|---|---|---|---|
| **1** | 1-3 | PPE compliance (Bakery-Head-Cap + NO-Bakery-Head-Cap, mask, vest) + entry-exit doc scan via OCR | Annotate IDs 10-11 + 13. Fine-tune on Kaggle. Deploy OCR pipeline. |
| **2** | 2-4 | Idle-time monitoring all floors + shop, shift-start checks, camera-down alerts | ByteTrack + rule engine only. **No new model needed.** Build while Phase 1 annotation is in progress. |
| **3** | 4-5 | New YOLO classes: bangles, cylinders, cashbox, exposed-items | Full annotation pipeline completed. Re-run Kaggle fine-tune with IDs 12-16. |
| **4** | 6+ | Hard problems: chewing (MediaPipe), cleanliness v1 (frame-diff), gas-idle v1 (D-Fire), cash-in-pocket | Separate R&D timeline. Set accuracy ceiling expectations with client explicitly before starting. |

---

## 🧰 TOOLS SUMMARY

| Tool | Purpose | Cost |
|---|---|---|
| **Kaggle** | GPU training (T4 x2) | Free — 30h/week |
| **Roboflow** | Cloud annotation + dataset management | Free — up to 10,000 images |
| **CVAT** | Self-hosted annotation (on-prem security) | Free, self-hosted |
| **Ultralytics YOLOv8** | Training framework | Free, MIT |
| **EasyOCR** | Document text extraction | Free, MIT |
| **Firebase FCM** | Mobile push notifications | Free up to 1M/month |
| **D-Fire model** | Flame detection (pre-trained) | Free |
| **gdown** | Google Drive model downloads | Free |

---

## ⚠️ RISKS & CLIENT EXPECTATIONS

| Risk | Expected Accuracy | Mitigation |
|---|---|---|
| **NO-Bakery-Head-Cap underrepresented** in 15-day footage | Depends on footage coverage | Augment aggressively; flag to client before quoting accuracy |
| **Bangles** — zero public dataset | Fully footage-dependent | If < 150 samples in archive, extend collection period |
| **Dirty floor** (frame-diff heuristic) | ~70-80% for obvious debris | Not suitable for disciplinary action alone — human review of flagged frames |
| **Gas/oil idle** (D-Fire model, open flame) | ~85% precision | Steam/vapor ~40-60% recall — recommend IoT gas sensor as hardware fallback |
| **Cash-in-pocket** (hand-to-pocket) | ~50-60% v1 | Action recognition needed; recommend cashbox-open sensor for reliability |
| **Catastrophic forgetting** during fine-tune | — | Always reload `best.pt` and validate IDs 0-9 mAP after every training run |
| **Bakery cap vs hardhat** model confusion | — | Test `helmet_model.pt` on 50 bakery-cap frames before using it |

---

## ❓ OPEN QUESTIONS FOR CLIENT

1. **Camera specs**: Brand/model? Do they support RTSP? Resolution?
2. **Server hardware**: What GPU is available on-premise?
3. **Network**: Dedicated factory LAN? VLAN separation between cameras and admin PCs?
4. **Mobile app**: Android only or iOS too?
5. **Invoice format**: Printed or handwritten? (Determines OCR difficulty)
6. **Identity / attendance**: Do workers have ID cards or face recognition needed?
7. **Head cap color**: Any specific color = compliant? (E.g. white cap only)
8. **Annotation access**: Can footage be shared with annotation team, or must stay on-site?
