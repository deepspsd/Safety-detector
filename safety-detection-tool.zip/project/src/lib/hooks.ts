import { useEffect, useState, useCallback } from 'react';
import type { Alert, Camera, SystemSetting, AttendanceRecord, Employee, DocumentRecord, WorkflowEvent, CylinderLog, VideoJob, Zone, CalibrationVersion } from './db';
import * as camerasApi from '@/api/cameras.api';
import * as alertsApi from '@/api/alerts.api';
import * as settingsApi from '@/api/settings.api';
import * as attendanceApi from '@/api/attendance.api';
import * as facesApi from '@/api/faces.api';
import * as documentsApi from '@/api/documents.api';
import * as workflowApi from '@/api/workflow.api';
import * as videoApi from '@/api/video.api';

export function useAlerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      setAlerts(await alertsApi.listAlerts());
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { alerts, loading, refresh };
}

export function useCameras() {
  const [cameras, setCameras] = useState<Camera[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      setCameras(await camerasApi.listCameras());
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { cameras, loading, refresh };
}

export async function addCamera(cam: Partial<Camera>): Promise<void> { await camerasApi.createCamera(cam); }
export async function updateCamera(id: string, cam: Partial<Camera>): Promise<void> { await camerasApi.updateCamera(id, cam); }
export async function deleteCamera(id: string): Promise<void> { await camerasApi.deleteCamera(id); }

export async function confirmAlert(id: string): Promise<void> { await alertsApi.confirmAlert(id); }
export async function dismissAlert(id: string): Promise<void> { await alertsApi.dismissAlert(id); }
export async function deleteAlert(id: string): Promise<void> { await alertsApi.deleteAlert(id); }
export async function deleteAllAlerts(): Promise<void> { await alertsApi.deleteAllAlerts(); }

export function useSettings() {
  const [settings, setSettings] = useState<SystemSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      setSettings(await settingsApi.listSettings());
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { settings, loading, refresh };
}
export async function updateSetting(key: string, value: string): Promise<void> { await settingsApi.updateSetting(key, value); }

export function useAttendance() {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      setRecords(await attendanceApi.listAttendance());
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { records, loading, refresh };
}
export async function clockInEmployee(rec: { employee_name: string; camera_name: string; method: string; notes: string }): Promise<void> { await attendanceApi.clockIn(rec); }
export async function clockOutEmployee(id: string): Promise<void> { await attendanceApi.clockOut(id); }

export function useEmployees() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      setEmployees(await facesApi.listFaces());
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { employees, loading, refresh };
}
export async function addEmployee(emp: { name: string; role: string; department: string; thumbnail_b64?: string }): Promise<void> { await facesApi.registerFace({ label: emp.name, image_b64: emp.thumbnail_b64 || '' }); }
export async function updateEmployee(id: string, emp: Partial<Employee>): Promise<void> { await facesApi.renameFace(id, emp.name || ''); }
export async function deleteEmployee(id: string): Promise<void> { await facesApi.deleteFace(id); }

export function useDocuments() {
  const [documents, setDocuments] = useState<DocumentRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      setDocuments(await documentsApi.listDocuments());
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { documents, loading, refresh };
}
export async function addDocument(doc: { direction: string; ocr_text: string; camera_name: string }): Promise<void> { await documentsApi.scanDocument(doc); }
export async function approveDocument(id: string): Promise<void> { await documentsApi.approveDocument(id); }
export async function rejectDocument(id: string): Promise<void> { await documentsApi.rejectDocument(id); }
export async function deleteDocument(id: string): Promise<void> { await documentsApi.deleteDocument(id); }

export function useWorkflowEvents() {
  const [events, setEvents] = useState<WorkflowEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      const e = await workflowApi.getWorkflowSummary();
      setEvents(e.events || []);
    } catch {
      setEvents([]);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { events, loading, refresh };
}

export function useCylinderLogs() {
  const [logs, setLogs] = useState<CylinderLog[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      setLogs(await settingsApi.getCylinderLogs());
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { logs, loading, refresh };
}

export function useVideoJobs() {
  const [jobs, setJobs] = useState<VideoJob[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      setJobs([]); // No backend endpoint to list jobs
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return { jobs, loading, refresh };
}
export async function addVideoJob(filename: string): Promise<string> {
  const jobId = await videoApi.uploadVideo(new File([], filename));
  return jobId || 'new-job';
}
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export async function updateVideoJob(_id: string, _updates: Partial<VideoJob>): Promise<void> {
  // Not natively supported by backend in this generic way, typically backend pushes updates
}

export function useZones(cameraId: string | null) {
  const [zones, setZones] = useState<Zone[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    if (!cameraId) { setZones([]); setLoading(false); return; }
    try {
      setZones(await camerasApi.getZones(cameraId));
    } finally {
      setLoading(false);
    }
  }, [cameraId]);
  useEffect(() => { refresh(); }, [refresh]);
  return { zones, loading, refresh };
}
export async function addZone(cameraId: string, zoneName: string, polygonJson: string, color: string): Promise<void> { await camerasApi.createZone(cameraId, zoneName, 'custom', polygonJson, color); }
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export async function deleteZone(_id: string): Promise<void> {
  console.warn("Delete zone by ID without camera ID not supported. Ensure usage is correct.");
}

export function useCalibrations(cameraId: string | null) {
  const [versions, setVersions] = useState<CalibrationVersion[]>([]);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    if (!cameraId) { setVersions([]); setLoading(false); return; }
    try {
      setVersions(await camerasApi.getCalibrations(cameraId));
    } finally {
      setLoading(false);
    }
  }, [cameraId]);
  useEffect(() => { refresh(); }, [refresh]);
  return { versions, loading, refresh };
}
export async function saveCalibrationSnapshot(cameraId: string): Promise<void> { await camerasApi.saveCalibrationSnapshot(cameraId); }
