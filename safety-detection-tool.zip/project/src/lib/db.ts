export type Camera = {
  id: string;
  name: string;
  floor: string;
  zone_type: string;
  rtsp_url: string;
  status: string;
  camera_code: string;
  department: string;
  fps: number;
  capabilities: string[];
  created_at: string;
  updated_at: string;
};

export type Alert = {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  title: string;
  message: string;
  camera_id: string | null;
  camera_name: string;
  floor: string;
  confidence: number;
  status: 'pending_review' | 'confirmed' | 'dismissed';
  snapshot_url: string;
  detected_at: string;
  created_at: string;
};

export type SystemSetting = {
  key: string;
  value: string;
  description: string;
};

export type NotificationLog = {
  id: string;
  channel: string;
  recipient: string;
  subject: string;
  body: string;
  status: string;
  sent_at: string;
};

export type AttendanceRecord = {
  id: string;
  employee_id: string;
  employee_name: string;
  camera_id: string | null;
  camera_name: string;
  method: 'face' | 'manual' | 'qr';
  clock_in: string;
  clock_out: string | null;
  notes: string;
};

export type Employee = {
  id: string;
  name: string;
  role: string;
  department: string;
  active: boolean;
  face_id: string | null;
  thumbnail_b64: string;
  created_at: string;
};

export type DocumentRecord = {
  id: string;
  direction: 'inward' | 'outward';
  ocr_text: string;
  approved: boolean;
  rejected: boolean;
  camera_id: string | null;
  camera_name: string;
  snapshot_url: string;
  created_at: string;
};

export type WorkflowEvent = {
  id: string;
  event_type: 'cash' | 'stock' | 'lift' | 'packing';
  message: string;
  severity: string;
  camera_name: string;
  track_id: string | null;
  floor_from: string | null;
  floor_to: string | null;
  duration: number | null;
  created_at: string;
};

export type CylinderLog = {
  id: string;
  camera_name: string;
  event_type: string;
  usage_day_count: number;
  created_at: string;
};

export type VideoJob = {
  id: string;
  filename: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  total_violations: number;
  annotated_video_url: string;
  video_duration_sec: number;
  created_at: string;
};

export type Zone = {
  id: string;
  camera_id: string;
  zone_name: string;
  zone_type: string;
  polygon_json: string;
  color: string;
  active: boolean;
  created_at: string;
  updated_at: string;
};

export type CalibrationVersion = {
  id: string;
  camera_id: string;
  version: number;
  snapshot: string;
  created_at: string;
};
