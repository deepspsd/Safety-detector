import { useRef } from 'react';
import { Camera, Check } from 'lucide-react';

interface FaceRegistrationFormProps {
  form: { name: string; role: string; department: string };
  setForm: (form: any) => void;
  thumbnail: string;
  setThumbnail: (thumb: string) => void;
  onCancel: () => void;
  onSubmit: () => void;
}

export function FaceRegistrationForm({ form, setForm, thumbnail, setThumbnail, onCancel, onSubmit }: FaceRegistrationFormProps) {
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; 
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setThumbnail(reader.result as string);
    reader.readAsDataURL(file);
  };

  return (
    <div className="panel clockin-form">
      <div className="face-upload-area" onClick={() => fileRef.current?.click()}>
        {thumbnail ? (
          <img src={thumbnail} alt="Preview" className="face-preview" />
        ) : (
          <div className="face-placeholder">
            <Camera size={32} />
            <small>Click to upload a face photo</small>
          </div>
        )}
        <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleFile} />
      </div>
      <div className="form-modal-body">
        <label className="form-field">
          <span>Name</span>
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Employee name" />
        </label>
        <label className="form-field">
          <span>Role</span>
          <input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} placeholder="e.g. baker, packer" />
        </label>
        <label className="form-field">
          <span>Department</span>
          <input value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} placeholder="e.g. Production" />
        </label>
      </div>
      <div className="form-modal-footer">
        <button className="secondary-button" onClick={onCancel}>Cancel</button>
        <button className="primary-button" onClick={onSubmit}><Check size={16} /> Save</button>
      </div>
    </div>
  );
}
