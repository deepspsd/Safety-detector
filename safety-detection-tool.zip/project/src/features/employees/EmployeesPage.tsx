import { useState } from 'react';
import { Upload, Trash2, Loader2 } from 'lucide-react';
import { useEmployees, addEmployee, updateEmployee, deleteEmployee } from '@/lib/hooks';
import { useToast } from '@/providers/ToastProvider';
import { FaceRegistrationForm } from './FaceRegistrationForm';
import { FaceCard } from './FaceCard';
import type { Employee } from '@/lib/db';

export function EmployeesPage() {
  const { showToast } = useToast();
  const { employees, loading, refresh } = useEmployees();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', role: '', department: '' });
  const [thumbnail, setThumbnail] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Employee | null>(null);

  const handleSubmit = async () => {
    if (!form.name) { showToast('Please enter a name', 'error'); return; }
    if (editingId) { 
      await updateEmployee(editingId, form); 
      showToast('Employee updated', 'success'); 
    } else { 
      await addEmployee({ ...form, thumbnail_b64: thumbnail }); 
      showToast('Employee registered', 'success'); 
    }
    refresh(); 
    setShowForm(false); 
    setEditingId(null);
    setForm({ name: '', role: '', department: '' }); 
    setThumbnail('');
  };

  return (
    <div className="employees-page">
      <div className="cameras-toolbar">
        <div className="cameras-count"><strong>{employees.length}</strong> employees registered</div>
        <button 
          className="primary-button" 
          onClick={() => { 
            setForm({ name: '', role: '', department: '' }); 
            setThumbnail(''); 
            setEditingId(null); 
            setShowForm(true); 
          }}
        >
          <Upload size={16} /> Register Face
        </button>
      </div>
      
      {showForm && (
        <FaceRegistrationForm 
          form={form} 
          setForm={setForm} 
          thumbnail={thumbnail} 
          setThumbnail={setThumbnail} 
          onCancel={() => setShowForm(false)} 
          onSubmit={handleSubmit} 
        />
      )}
      
      <div className="cameras-grid">
        {loading ? (
          <div className="loading-row"><Loader2 size={18} className="spin" /> Loading...</div>
        ) : (
          employees.map((emp) => (
            <FaceCard 
              key={emp.id} 
              emp={emp} 
              onEdit={(emp) => { 
                setForm({ name: emp.name, role: emp.role, department: emp.department }); 
                setEditingId(emp.id); 
                setShowForm(true); 
              }} 
              onDelete={setDeleteTarget} 
            />
          ))
        )}
      </div>
      
      {deleteTarget && (
        <div className="modal-backdrop" onClick={() => setDeleteTarget(null)}>
          <div className="confirm-dialog" onClick={(e) => e.stopPropagation()}>
            <div className="confirm-icon"><Trash2 size={24} /></div>
            <h3>Delete employee?</h3>
            <p>This will remove "{deleteTarget.name}" and their face encoding.</p>
            <div className="confirm-actions">
              <button className="secondary-button" onClick={() => setDeleteTarget(null)}>Cancel</button>
              <button 
                className="danger-button" 
                onClick={async () => { 
                  await deleteEmployee(deleteTarget.id); 
                  refresh(); 
                  setDeleteTarget(null); 
                  showToast('Employee deleted', 'success'); 
                }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
