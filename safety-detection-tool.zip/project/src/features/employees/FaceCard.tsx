import { Edit3, Trash2 } from 'lucide-react';
import type { Employee } from '@/lib/db';

interface FaceCardProps {
  emp: Employee;
  onEdit: (emp: Employee) => void;
  onDelete: (emp: Employee) => void;
}

export function FaceCard({ emp, onEdit, onDelete }: FaceCardProps) {
  return (
    <div className="camera-card">
      <div className="camera-card-top">
        <div className="face-thumb">
          {emp.thumbnail_b64 ? (
            <img src={emp.thumbnail_b64} alt={emp.name} />
          ) : (
            <div className="face-placeholder-sm">
              {emp.name.split(' ').map((n) => n[0]).join('')}
            </div>
          )}
        </div>
        <strong>{emp.name}</strong>
        <span className={`status-badge ${emp.active ? 'confirmed' : 'dismissed'}`}>
          {emp.active ? 'Active' : 'Inactive'}
        </span>
      </div>
      <div className="camera-card-body">
        <div className="camera-info-row"><small>Role</small><span>{emp.role || '—'}</span></div>
        <div className="camera-info-row"><small>Department</small><span>{emp.department || '—'}</span></div>
        <div className="camera-info-row"><small>Face ID</small><span>{emp.face_id ? 'Linked' : 'Not linked'}</span></div>
      </div>
      <div className="camera-card-actions">
        <button className="card-action" onClick={() => onEdit(emp)}>
          <Edit3 size={14} /> Edit
        </button>
        <button className="card-action danger" onClick={() => onDelete(emp)}>
          <Trash2 size={14} /> Delete
        </button>
      </div>
    </div>
  );
}
