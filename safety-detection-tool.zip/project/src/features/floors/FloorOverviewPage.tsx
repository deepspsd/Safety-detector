import { Camera, AlertTriangle, Clock3, Zap } from 'lucide-react';
import type { Camera as CameraType, Alert } from '@/lib/db';
import { FloorCameraCard } from './FloorCameraCard';
import { FloorRulesSummary } from './FloorRulesSummary';

const floorRules: Record<string, string[]> = {
  ground: ['Entrance monitoring', 'Dough mixing', 'Biscuit cutting', 'Oven', 'Packing', 'Loading/unloading', 'Cleanliness'],
  first: ['Four work tables', 'Dough mixing (starts 6 AM)', 'Lift monitoring', 'Raw material stock', 'Cylinders', 'Dress code'],
  second: ['Work starts 5 AM', 'Fire/gas monitoring', 'Oil/water waste', 'Stocks', 'No eating/stealing', 'Window security'],
  shop: ['Cash monitoring', 'Dress code', 'Vendor payments', 'Idle detection'],
};

export function FloorOverviewPage({ floorId, cameras, alerts, onOpenMonitor }: {
  floorId: string; cameras: CameraType[]; alerts: Alert[]; onOpenMonitor: () => void;
}) {
  const floorCameras = cameras.filter((c) => c.floor === floorId);
  const floorAlerts = alerts.filter((a) => a.floor === floorId);
  const floorName = { ground: 'Ground Floor', first: 'First Floor', second: 'Second Floor', shop: 'Shop Floor' }[floorId] || floorId;
  const rules = floorRules[floorId] || [];

  return (
    <div className="floor-page">
      <div className="floor-header">
        <div>
          <div className="eyebrow"><span className="live-dot" /> FLOOR OVERVIEW</div>
          <h1>{floorName}</h1>
          <p>{floorCameras.length} cameras · {floorAlerts.length} alerts today</p>
        </div>
        <button className="primary-button" onClick={onOpenMonitor}>
          <Camera size={16} /> Open Live Monitor
        </button>
      </div>
      <div className="floor-grid">
        <div className="floor-main">
          <div className="panel">
            <div className="panel-header">
              <div>
                <h2>Cameras on this floor</h2>
                <p>Click a camera to view its live feed</p>
              </div>
            </div>
            <div className="floor-camera-grid">
              {floorCameras.map((cam, i) => (
                <FloorCameraCard key={cam.id} cam={cam} index={i} onOpenMonitor={onOpenMonitor} />
              ))}
            </div>
          </div>
          <div className="panel">
            <div className="panel-header">
              <div>
                <h2>Recent alerts on this floor</h2>
                <p>Latest safety events</p>
              </div>
            </div>
            <div className="alert-list">
              {floorAlerts.length === 0 ? (
                <div className="loading-row">No alerts on this floor.</div>
              ) : (
                floorAlerts.slice(0, 8).map((alert) => (
                  <div className="alert-row" key={alert.id}>
                    <div className={`severity-icon ${alert.severity}`}>
                      {alert.severity === 'critical' ? (
                        <AlertTriangle size={15} />
                      ) : alert.severity === 'high' ? (
                        <Zap size={15} />
                      ) : (
                        <Clock3 size={15} />
                      )}
                    </div>
                    <div className="alert-copy">
                      <strong>{alert.title}</strong>
                      <small>{alert.camera_name} · {alert.detected_at}</small>
                    </div>
                    <span className={`severity-text ${alert.severity}`}>{alert.severity}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
        <div className="floor-side">
          <FloorRulesSummary rules={rules} />
        </div>
      </div>
    </div>
  );
}
