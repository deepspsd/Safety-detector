import type { Camera as CameraType } from '@/lib/db';

const fallbackImages = [
  'https://images.pexels.com/photos/5953714/pexels-photo-5953714.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/34718930/pexels-photo-34718930.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/11515346/pexels-photo-11515346.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
];

export function FloorCameraCard({ cam, index, onOpenMonitor }: { cam: CameraType; index: number; onOpenMonitor: () => void }) {
  return (
    <div className="floor-camera-card" onClick={onOpenMonitor}>
      <img src={fallbackImages[index % fallbackImages.length]} alt={cam.name} />
      <div className="floor-camera-info">
        <div className={`camera-status-dot ${cam.status}`} />
        <strong>{cam.name}</strong>
        <small>{cam.zone_type} · {cam.fps} FPS</small>
      </div>
    </div>
  );
}
