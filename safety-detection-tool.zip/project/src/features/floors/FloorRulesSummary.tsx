export function FloorRulesSummary({ rules }: { rules: string[] }) {
  return (
    <div className="panel">
      <div className="panel-header">
        <div>
          <h2>Monitoring rules</h2>
          <p>What is being monitored on this floor</p>
        </div>
      </div>
      <div className="rules-list">
        {rules.map((rule) => (
          <div className="rule-row" key={rule}>
            <div className="rule-dot" />
            <span>{rule}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
