import { useState } from 'react';
import { ShieldCheck, Mail, Lock, User, ChevronDown, Loader2, AlertCircle } from 'lucide-react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '@/providers/AuthProvider';

type Role = 'Construction Worker' | 'Doctor' | 'Traffic Police' | 'College' | 'Home' | 'Bakery Worker' | 'None';
const roles: Role[] = ['Construction Worker', 'Doctor', 'Traffic Police', 'College', 'Home', 'Bakery Worker', 'None'];

export function LoginPage() {
  const navigate = useNavigate();
  const { login, user } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) { setError('Please enter your email and password.'); return; }
    setLoading(true); setError('');
    try {
      await login(email, password);
      navigate('/dashboard', { replace: true });
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Unable to sign in. Check your email and password.');
    } finally {
      setLoading(false);
    }
  };

  if (user) return <Navigate to="/dashboard" replace />;

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-brand"><div className="auth-brand-mark"><ShieldCheck size={26} strokeWidth={2.5} /></div><span>Occu<span>Safe</span></span></div>
        <h1>Admin Login</h1>
        <p>Sign in to your safety monitoring dashboard</p>
        {error && <div className="auth-error"><AlertCircle size={16} /> {error}</div>}
        <form onSubmit={handleSubmit} className="auth-form">
          <label className="auth-field"><Mail size={16} /><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Admin email" /></label>
          <label className="auth-field"><Lock size={16} /><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" /></label>
          <button type="submit" className="auth-submit" disabled={loading}>{loading ? <Loader2 size={18} className="spin" /> : 'Sign in'}</button>
        </form>
        <p className="auth-switch">Need an admin account? <button onClick={() => navigate('/signup')}>Register</button></p>
      </div>
    </div>
  );
}

export function SignupPage() {
  const navigate = useNavigate();
  const { signup, user } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<Role>('Bakery Worker');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) { setError('Please fill in all fields.'); return; }
    setLoading(true); setError('');
    try {
      await signup({ email, password, name, role });
      navigate('/dashboard', { replace: true });
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Unable to create the account. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (user) return <Navigate to="/dashboard" replace />;

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-brand"><div className="auth-brand-mark"><ShieldCheck size={26} strokeWidth={2.5} /></div><span>Occu<span>Safe</span></span></div>
        <h1>Admin Registration</h1>
        <p>Create an admin account for OccuSafe</p>
        {error && <div className="auth-error"><AlertCircle size={16} /> {error}</div>}
        <form onSubmit={handleSubmit} className="auth-form">
          <label className="auth-field"><User size={16} /><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" /></label>
          <label className="auth-field"><Mail size={16} /><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email address" /></label>
          <label className="auth-field"><Lock size={16} /><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" /></label>
          <div className="auth-field"><ChevronDown size={16} /><select value={role} onChange={(e) => setRole(e.target.value as Role)}>{roles.map((r) => <option key={r} value={r}>{r}</option>)}</select></div>
          <button type="submit" className="auth-submit" disabled={loading}>{loading ? <Loader2 size={18} className="spin" /> : 'Create account'}</button>
        </form>
        <p className="auth-switch">Already have an account? <button onClick={() => navigate('/login')}>Sign in</button></p>
      </div>
    </div>
  );
}
