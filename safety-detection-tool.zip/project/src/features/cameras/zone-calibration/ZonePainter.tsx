import { useRef, useState, useEffect, useCallback } from 'react';
import {
  Undo2, Save, Trash2, MousePointer2, X, Eye, EyeOff,
  Edit3, Copy, CheckSquare, AlertTriangle, RefreshCw,
} from 'lucide-react';
import { getZones, createZone, updateZone, softDeleteZone, getSnapshot, saveCalibrationSnapshot } from '@/api/cameras.api';
import { useToast } from '@/providers/ToastProvider';
import type { Zone } from '@/lib/db';

// Zone-type catalog from workflow spec
export type ZoneTypeEntry = {
  value: string;
  label: string;
  color: string;
  usedBy: string;
};

export const ZONE_TYPE_CATALOG: ZoneTypeEntry[] = [
  { value: 'entrance',        label: 'Entrance',        color: '#3B82F6', usedBy: 'OCR gate, attendance' },
  { value: 'cashbox',         label: 'Cash Box',        color: '#10B981', usedBy: 'Cash-tracking heuristic' },
  { value: 'window',          label: 'Window',          color: '#EF4444', usedBy: 'Throw-detection' },
  { value: 'oven',            label: 'Oven',            color: '#F97316', usedBy: 'Oven-region monitoring' },
  { value: 'packing_station', label: 'Packing Station', color: '#8B5CF6', usedBy: 'Hands-in-motion idle check' },
  { value: 'biscuit_cutting', label: 'Biscuit Cutting', color: '#EAB308', usedBy: 'Machine-start workflow check' },
  { value: 'dough_section',   label: 'Dough Section',   color: '#14B8A6', usedBy: 'Post-task movement check' },
  { value: 'cylinder_area',   label: 'Cylinder Area',   color: '#A16207', usedBy: 'Cylinder usage logging' },
  { value: 'stock_area',      label: 'Stock Area',      color: '#6B7280', usedBy: 'Stock/item monitoring' },
  { value: 'custom',          label: 'Custom',          color: '#EC4899', usedBy: 'Free-text purpose note required' },
];

export function getZoneColor(zoneType: string): string {
  return ZONE_TYPE_CATALOG.find((z) => z.value === zoneType)?.color ?? '#EC4899';
}

type NPoint = { nx: number; ny: number };

function normToCanvas(p: NPoint, W: number, H: number) {
  return { x: p.nx * W, y: p.ny * H };
}

type Mode = 'drawing' | 'idle' | 'editing';

export function ZonePainter({ cameraId }: { cameraId: string }) {
  const { showToast } = useToast();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const liveTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [zones, setZones] = useState<Zone[]>([]);
  const [snapshotUrl, setSnapshotUrl] = useState('');
  const [snapshotTs, setSnapshotTs] = useState(Date.now());
  const [imageLoaded, setImageLoaded] = useState(false);
  const [cameraOffline, setCameraOffline] = useState(false);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<Mode>('idle');
  const [currentPoints, setCurrentPoints] = useState<NPoint[]>([]);
  const [draggingIdx, setDraggingIdx] = useState<number | null>(null);
  const [editingZone, setEditingZone] = useState<Zone | null>(null);
  const [zoneType, setZoneType] = useState('entrance');
  const [customName, setCustomName] = useState('');
  const [zoneColor, setZoneColor] = useState(getZoneColor('entrance'));
  const [livePreview, setLivePreview] = useState(false);
  const [saving, setSaving] = useState(false);

  const effectiveName = editingZone ? editingZone.zone_name : (customName.trim() || zoneType);

  // Load data
  const refresh = useCallback(async () => {
    if (!cameraId) return;
    setLoading(true);
    try {
      const [url, zs] = await Promise.all([getSnapshot(cameraId), getZones(cameraId)]);
      setSnapshotUrl(url);
      setZones(zs);
      setCameraOffline(false);
    } catch {
      setCameraOffline(true);
    } finally {
      setLoading(false);
    }
  }, [cameraId]);

  useEffect(() => { refresh(); }, [refresh]);

  // Live preview polling
  useEffect(() => {
    if (livePreview) {
      liveTimerRef.current = setInterval(() => setSnapshotTs(Date.now()), 2500);
    } else {
      if (liveTimerRef.current) clearInterval(liveTimerRef.current);
    }
    return () => { if (liveTimerRef.current) clearInterval(liveTimerRef.current); };
  }, [livePreview]);

  const displayUrl = livePreview && snapshotUrl
    ? snapshotUrl + '?t=' + snapshotTs
    : snapshotUrl;

  // Canvas drawing
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img || !imageLoaded) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    // Draw saved zones
    zones.forEach((zone) => {
      try {
        const pts: NPoint[] = JSON.parse(zone.polygon_json);
        if (pts.length < 2) return;
        const color = zone.color || getZoneColor(zone.zone_type || 'custom');
        ctx.beginPath();
        pts.forEach((p, i) => {
          const { x, y } = normToCanvas(p, W, H);
          if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        });
        ctx.closePath();
        ctx.fillStyle = color + '33';
        ctx.fill();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.setLineDash([]);
        ctx.stroke();

        // Zone label
        const cx = pts.reduce((s, p) => s + normToCanvas(p, W, H).x, 0) / pts.length;
        const cy = pts.reduce((s, p) => s + normToCanvas(p, W, H).y, 0) / pts.length;
        ctx.font = 'bold 12px Manrope, sans-serif';
        ctx.fillStyle = color;
        ctx.shadowColor = 'rgba(0,0,0,0.7)';
        ctx.shadowBlur = 4;
        ctx.fillText(zone.zone_name, cx - 30, cy);
        ctx.shadowBlur = 0;

        // Editing vertex dots
        if (editingZone?.id === zone.id) {
          pts.forEach((p) => {
            const { x, y } = normToCanvas(p, W, H);
            ctx.beginPath();
            ctx.arc(x, y, 6, 0, Math.PI * 2);
            ctx.fillStyle = color;
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 1.5;
            ctx.fill();
            ctx.stroke();
          });
        }
      } catch {}
    });

    // Draw current WIP polygon
    if (currentPoints.length > 0) {
      const color = zoneColor;
      ctx.beginPath();
      currentPoints.forEach((p, i) => {
        const { x, y } = normToCanvas(p, W, H);
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      if (currentPoints.length >= 3) {
        ctx.closePath();
        ctx.fillStyle = color + '22';
        ctx.fill();
      }
      ctx.strokeStyle = color;
      ctx.setLineDash([6, 4]);
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.setLineDash([]);

      // Vertex dots
      currentPoints.forEach((p, i) => {
        const { x, y } = normToCanvas(p, W, H);
        ctx.beginPath();
        ctx.arc(x, y, 5, 0, Math.PI * 2);
        ctx.fillStyle = i === 0 ? color : '#ffffff';
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.fill();
        ctx.stroke();
      });
    }
  }, [zones, currentPoints, zoneColor, imageLoaded, editingZone]);

  useEffect(() => { draw(); }, [draw]);

  // Canvas resize observer
  useEffect(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img) return;
    const ro = new ResizeObserver(() => {
      canvas.width = img.clientWidth || 640;
      canvas.height = img.clientHeight || 360;
      draw();
    });
    ro.observe(img);
    return () => ro.disconnect();
  }, [draw]);

  // Event helpers
  const getNormPos = useCallback((e: React.MouseEvent<HTMLCanvasElement>): NPoint => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return { nx: (e.clientX - rect.left) / rect.width, ny: (e.clientY - rect.top) / rect.height };
  }, []);

  const SNAP = 0.02;

  const isNearFirst = useCallback((p: NPoint): boolean => {
    if (currentPoints.length < 2) return false;
    const first = currentPoints[0];
    return Math.abs(p.nx - first.nx) < SNAP && Math.abs(p.ny - first.ny) < SNAP;
  }, [currentPoints]);

  // Save zone
  const handleSaveInternal = async (pts: NPoint[]) => {
    if (pts.length < 3) return;
    if (zoneType === 'custom' && !customName.trim()) {
      showToast('Enter a custom zone name', 'warning');
      return;
    }
    setSaving(true);
    try {
      const polygonJson = JSON.stringify(pts);
      if (editingZone) {
        await updateZone(editingZone.id, polygonJson, zoneColor, zoneType);
        showToast('Zone updated', 'success');
      } else {
        await createZone(cameraId, effectiveName, zoneType, polygonJson, zoneColor);
        await saveCalibrationSnapshot(cameraId);
        showToast('Zone saved', 'success');
      }
      setCurrentPoints([]);
      setEditingZone(null);
      setMode('idle');
      setCustomName('');
      refresh();
    } catch (err: any) {
      showToast('Save failed: ' + (err?.message ?? ''), 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleCloseShape = () => {
    if (currentPoints.length < 3) {
      showToast('Need at least 3 points', 'warning');
      return;
    }
    handleSaveInternal(currentPoints);
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (mode !== 'drawing') return;
    if (draggingIdx !== null) return;
    const pos = getNormPos(e);
    if (isNearFirst(pos) && currentPoints.length >= 3) {
      handleCloseShape();
      return;
    }
    setCurrentPoints((prev) => [...prev, pos]);
  };

  const handleRightClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    setCurrentPoints((prev) => prev.slice(0, -1));
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (currentPoints.length === 0) return;
    const pos = getNormPos(e);
    const idx = currentPoints.findIndex(
      (p) => Math.abs(p.nx - pos.nx) < SNAP && Math.abs(p.ny - pos.ny) < SNAP
    );
    if (idx >= 0) setDraggingIdx(idx);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (draggingIdx === null) return;
    const pos = getNormPos(e);
    setCurrentPoints((prev) => prev.map((p, i) => (i === draggingIdx ? pos : p)));
  };

  // Edit / Copy / Delete
  const handleEditZone = (zone: Zone) => {
    try {
      const pts: NPoint[] = JSON.parse(zone.polygon_json);
      setCurrentPoints(pts);
      setEditingZone(zone);
      setZoneType(zone.zone_type || 'custom');
      setZoneColor(zone.color || getZoneColor(zone.zone_type));
      setMode('editing');
    } catch {
      showToast('Could not load zone', 'error');
    }
  };

  const handleCopyZone = (zone: Zone) => {
    handleEditZone(zone);
    setEditingZone(null);
    setCustomName(zone.zone_name + '_copy');
    setZoneType('custom');
    setMode('drawing');
  };

  const handleDeleteZone = async (zone: Zone) => {
    try {
      await softDeleteZone(zone.id);
      await saveCalibrationSnapshot(cameraId);
      showToast('Zone deleted', 'info');
      refresh();
    } catch {
      showToast('Delete failed', 'error');
    }
  };

  // Auto-set color from zone type
  useEffect(() => { setZoneColor(getZoneColor(zoneType)); }, [zoneType]);

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: 24, color: '#829089', fontSize: 13 }}>
      <RefreshCw size={16} className="spin" /> Loading zone painter...
    </div>
  );

  return (
    <div className="zone-painter">
      {/* Camera offline banner */}
      {cameraOffline && (
        <div className="zone-offline-banner">
          <AlertTriangle size={14} />
          Camera currently offline — showing last known frame. Calibration will apply when camera reconnects.
        </div>
      )}

      {/* Toolbar */}
      <div className="zone-painter-toolbar">
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', flex: 1 }}>
          <label className="form-field" style={{ marginBottom: 0, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <span style={{ whiteSpace: 'nowrap', fontWeight: 600, fontSize: 11 }}>Zone type</span>
            <select value={zoneType} onChange={(e) => setZoneType(e.target.value)}>
              {ZONE_TYPE_CATALOG.map((t) => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>
          </label>
          {zoneType === 'custom' && (
            <label className="form-field" style={{ marginBottom: 0, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <span style={{ whiteSpace: 'nowrap', fontWeight: 600, fontSize: 11 }}>Name</span>
              <input value={customName} onChange={(e) => setCustomName(e.target.value)} placeholder="e.g. packing_zone_2" style={{ width: 160 }} />
            </label>
          )}
          <label className="form-field" style={{ marginBottom: 0, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <span style={{ whiteSpace: 'nowrap', fontWeight: 600, fontSize: 11 }}>Color</span>
            <input
              type="color"
              value={zoneColor}
              onChange={(e) => setZoneColor(e.target.value)}
              style={{ width: 34, height: 28, padding: 2, border: '1px solid #d1d5db', borderRadius: 6, cursor: 'pointer', background: 'none' }}
            />
          </label>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <button
            className={'monitor-toggle ' + (livePreview ? 'enabled' : '')}
            onClick={() => setLivePreview((v) => !v)}
            title="Live snapshot refresh every 2.5s"
          >
            {livePreview ? <Eye size={13} /> : <EyeOff size={13} />}
            <span /> {livePreview ? 'Live' : 'Static'}
          </button>
          {mode === 'idle' && (
            <button className="primary-button" onClick={() => setMode('drawing')}>+ New Zone</button>
          )}
        </div>
      </div>

      {/* Mode hint */}
      {mode !== 'idle' && (
        <div className="zone-painter-hint">
          <MousePointer2 size={13} />
          {mode === 'drawing'
            ? 'Click to place vertices (min 3). Right-click to undo last. Click near first point or press Close Shape to finish.'
            : 'Editing — drag vertices to reposition. Press Save to apply changes.'}
          <span style={{ marginLeft: 8, fontWeight: 700, color: '#4e9b78' }}>Zone: {effectiveName}</span>
        </div>
      )}

      {/* Canvas + Image */}
      <div className="zone-painter-canvas-wrap">
        <img
          ref={imgRef}
          src={displayUrl || 'https://images.pexels.com/photos/5953714/pexels-photo-5953714.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'}
          alt="Camera snapshot"
          crossOrigin="anonymous"
          onLoad={(e) => {
            const t = e.currentTarget;
            const canvas = canvasRef.current;
            if (canvas) {
              canvas.width = t.clientWidth || 640;
              canvas.height = t.clientHeight || 360;
            }
            setImageLoaded(true);
          }}
          onError={() => setCameraOffline(true)}
          className="zone-painter-bg"
          style={{ cursor: mode === 'drawing' ? 'crosshair' : mode === 'editing' ? 'move' : 'default' }}
        />
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          onContextMenu={handleRightClick}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={() => setDraggingIdx(null)}
          onMouseLeave={() => setDraggingIdx(null)}
          className="zone-painter-canvas"
        />
      </div>

      {/* Actions bar */}
      {mode !== 'idle' && (
        <div className="zone-painter-actions">
          <button className="secondary-button" onClick={() => setCurrentPoints((p) => p.slice(0, -1))} disabled={currentPoints.length === 0}>
            <Undo2 size={14} /> Undo
          </button>
          <button className="secondary-button" onClick={() => setCurrentPoints([])} disabled={currentPoints.length === 0}>
            <Trash2 size={14} /> Clear ({currentPoints.length} pts)
          </button>
          {currentPoints.length >= 3 && (
            <button className="secondary-button" onClick={handleCloseShape}>
              <CheckSquare size={14} /> Close Shape
            </button>
          )}
          <button className="primary-button" onClick={() => handleSaveInternal(currentPoints)} disabled={currentPoints.length < 3 || saving}>
            <Save size={14} /> {saving ? 'Saving...' : 'Save Zone'}
          </button>
          <button className="secondary-button" style={{ marginLeft: 'auto' }} onClick={() => { setCurrentPoints([]); setEditingZone(null); setMode('idle'); setCustomName(''); }}>
            <X size={14} /> Cancel
          </button>
        </div>
      )}

      {/* Saved zones list */}
      <div className="zone-saved-list">
        <div className="zone-saved-header">
          <strong>Saved zones ({zones.length})</strong>
          <button className="text-button" onClick={refresh}><RefreshCw size={12} /> Refresh</button>
        </div>
        {zones.length === 0 ? (
          <div style={{ color: '#9aa59f', fontSize: 11, padding: '10px 0' }}>
            No zones saved yet. Click New Zone to start drawing.
          </div>
        ) : zones.map((z) => {
          const color = z.color || getZoneColor(z.zone_type);
          const ptCount = (() => { try { return JSON.parse(z.polygon_json).length; } catch { return 0; } })();
          return (
            <div className="zone-saved-row" key={z.id}>
              <span className="zone-color-dot" style={{ background: color }} />
              <div className="zone-saved-info">
                <strong className="zone-name-label">{z.zone_name}</strong>
                <small>{ZONE_TYPE_CATALOG.find((t) => t.value === z.zone_type)?.label ?? z.zone_type} · {ptCount} pts</small>
              </div>
              <div className="zone-saved-actions">
                <button className="card-action" onClick={() => handleEditZone(z)}><Edit3 size={12} /> Edit</button>
                <button className="card-action" onClick={() => handleCopyZone(z)}><Copy size={12} /> Copy</button>
                <button className="card-action danger" onClick={() => handleDeleteZone(z)}><Trash2 size={12} /></button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Zone type reference */}
      <details className="zone-type-ref" style={{ marginTop: 12 }}>
        <summary style={{ cursor: 'pointer', fontSize: 11, color: '#6b7280', fontWeight: 600 }}>Zone type reference</summary>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginTop: 8 }}>
          {ZONE_TYPE_CATALOG.map((t) => (
            <div key={t.value} style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '6px 8px', background: '#f7f9f8', borderRadius: 6, border: '1px solid #e8eef0' }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: t.color, flexShrink: 0 }} />
              <div>
                <div style={{ fontSize: 10, fontWeight: 700, color: '#3d4d45' }}>{t.label}</div>
                <div style={{ fontSize: 9, color: '#9aa59f' }}>{t.usedBy}</div>
              </div>
            </div>
          ))}
        </div>
      </details>
    </div>
  );
}
