import { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, Save, RotateCcw } from 'lucide-react';
import { ZonePainter } from './ZonePainter';
import { getCamera, getCalibrations, saveCalibrationSnapshot, restoreCalibration } from '@/api/cameras.api';
import { useToast } from '@/providers/ToastProvider';
import type { Camera, CalibrationVersion } from '@/lib/db';

export function ZoneCalibrationPage({ cameraId, onBack }: { cameraId: string; onBack: () => void }) {
  const { showToast } = useToast();
  const [camera, setCamera] = useState<Camera | null>(null);
  const [versions, setVersions] = useState<CalibrationVersion[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!cameraId) return;
    const [cam, vers] = await Promise.all([
      getCamera(cameraId), getCalibrations(cameraId),
    ]);
    setCamera(cam);
    setVersions(vers);
    setLoading(false);
  }, [cameraId]);

  useEffect(() => { refresh(); }, [refresh]);

  const handleSaveSnapshot = async () => {
    if (!cameraId) return;
    await saveCalibrationSnapshot(cameraId);
    showToast('Calibration snapshot saved', 'success');
    refresh();
  };

  const handleRestore = async (version: number) => {
    if (!cameraId) return;
    await restoreCalibration(cameraId, version);
    showToast('Restored calibration v' + version, 'success');
    refresh();
  };

  if (loading) return <div className="loading-row">Loading calibration...</div>;
  if (!camera) return <div className="empty-state"><h3>Camera not found</h3></div>;

  return (
    <div className="zone-calibration-page">
      <div className="zone-cal-header">
        <button className="secondary-button" onClick={onBack}>
          <ArrowLeft size={16} /> Back to Cameras
        </button>
        <div>
          <div className="eyebrow"><span className="live-dot" /> ZONE CALIBRATION</div>
          <h1>{camera.name}</h1>
          <p>{camera.floor} &middot; {camera.zone_type} &middot; Draw detection zones on the camera snapshot</p>
        </div>
        <button className="primary-button" onClick={handleSaveSnapshot}>
          <Save size={16} /> Save Snapshot
        </button>
      </div>

      <div className="zone-cal-grid">
        <div className="panel zone-cal-main">
          <ZonePainter cameraId={camera.id} />
        </div>
        <div className="panel zone-cal-side">
          <div className="panel-header">
            <div><h2>Calibration history</h2><p>Restore previous calibration versions</p></div>
          </div>
          {versions.length === 0 ? (
            <div className="loading-row">No saved snapshots yet.</div>
          ) : (
            <div className="settings-list">
              {versions.map((v) => (
                <div className="threshold-row" key={v.id}>
                  <div className="threshold-info">
                    <strong>Version {v.version}</strong>
                    <small>{v.created_at}</small>
                  </div>
                  <button className="secondary-button small" onClick={() => handleRestore(v.version)}>
                    <RotateCcw size={13} /> Restore
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
