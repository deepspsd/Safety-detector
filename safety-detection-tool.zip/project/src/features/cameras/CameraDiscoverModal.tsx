import { useState } from 'react';
import { Plus, ScanLine, Loader2, X } from 'lucide-react';
import { discoverCameras } from '@/api/cameras.api';
import { useToast } from '@/providers/ToastProvider';
import type { Camera } from '@/lib/db';

interface CameraDiscoverModalProps {
  onClose: () => void;
  onAdd: (cam: Partial<Camera>) => void;
}

export function CameraDiscoverModal({ onClose, onAdd }: CameraDiscoverModalProps) {
  const { showToast } = useToast();
  const [scanning, setScanning] = useState(false);
  const [results, setResults] = useState<any[]>([]);

  const handleScan = async () => {
    setScanning(true);
    try {
      const res = await discoverCameras();
      setResults(res.cameras_found || []);
    } catch (e) {
      showToast('Discovery failed', 'error');
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="form-modal" onClick={(e) => e.stopPropagation()}>
        <div className="form-modal-header">
          <h2>Discover cameras on LAN</h2>
          <button onClick={onClose} className="modal-close"><X size={18} /></button>
        </div>
        <div className="form-modal-body" style={{ display: 'block' }}>
          <button className="primary-button" onClick={handleScan} disabled={scanning}>
            {scanning ? <Loader2 size={16} className="spin" /> : <ScanLine size={16} />} 
            {scanning ? 'Scanning LAN...' : 'Start scan'}
          </button>
          
          {results.map((r, i) => (
            <div key={i} className="discover-result">
              <div className="discover-info">
                <strong>{r.ip}</strong>
                <small>{r.hostname} · Port {r.open_port}</small>
              </div>
              <div className="discover-rtsp">
                {r.rtsp_guesses?.map((url: string, j: number) => (
                  <div key={j} className="rtsp-guess">{url}</div>
                ))}
              </div>
              <button 
                className="primary-button small" 
                onClick={() => { 
                  onAdd({ name: r.hostname, rtsp_url: r.rtsp_guesses?.[0] || '', floor: 'ground', status: 'online' }); 
                  showToast('Camera added from discovery', 'success'); 
                  onClose(); 
                }}
              >
                <Plus size={14} /> Add Camera
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
