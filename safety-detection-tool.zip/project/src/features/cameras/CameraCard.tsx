import { Edit3, RotateCw, Trash2, Crosshair } from 'lucide-react';
import type { Camera } from '@/lib/db';

function maskRtsp(url: string): string {
  if (!url) return '—';
  return url.replace(/\/\/([^:]+):([^@]+)@/, '//$1:****@');
}

interface CameraCardProps {
  cam: Camera;
  onEdit: (cam: Camera) => void;
  onRestart: (id: string) => void;
  onDeleteTarget: (cam: Camera) => void;
  onOpenZonePainter?: (cameraId: string) => void;
}

export function CameraCard({ cam, onEdit, onRestart, onDeleteTarget, onOpenZonePainter }: CameraCardProps) {
  return (
    <div className="camera-card">
      <div className="camera-card-top">
        <div className={`camera-status-dot ${cam.status}`} />
        <strong>{cam.name}</strong>
        <span className={`status-badge ${cam.status}`}>{cam.status}</span>
      </div>
      <div className="camera-card-body">
        <div className="camera-info-row"><small>Floor</small><span>{cam.floor}</span></div>
        <div className="camera-info-row"><small>Zone</small><span>{cam.zone_type}</span></div>
        <div className="camera-info-row"><small>Code</small><span>{cam.camera_code || '—'}</span></div>
        <div className="camera-info-row"><small>Department</small><span>{cam.department || '—'}</span></div>
        <div className="camera-info-row"><small>FPS</small><span>{cam.fps}</span></div>
        <div className="camera-info-row"><small>RTSP</small><span className="rtsp-mask">{maskRtsp(cam.rtsp_url)}</span></div>
      </div>
      <div className="camera-card-actions">
        <button className="card-action" onClick={() => onEdit(cam)}><Edit3 size={14} /> Edit</button>
        <button className="card-action" onClick={() => onRestart(cam.id)}><RotateCw size={14} /> Restart</button>
        <button className="card-action" onClick={() => onOpenZonePainter?.(cam.id)}><Crosshair size={14} /> Zones</button>
        <button className="card-action danger" onClick={() => onDeleteTarget(cam)}><Trash2 size={14} /> Delete</button>
      </div>
    </div>
  );
}
