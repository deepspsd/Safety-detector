import { useState, useEffect, useCallback } from 'react';
import { Plus, ScanLine } from 'lucide-react';
import { listCameras, createCamera, updateCamera, deleteCamera, restartCamera } from '@/api/cameras.api';
import { useToast } from '@/providers/ToastProvider';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { LoadingRow } from '@/components/Spinner';
import type { Camera } from '@/lib/db';

import { CameraCard } from './CameraCard';
import { CameraFormModal } from './CameraFormModal';
import { CameraDiscoverModal } from './CameraDiscoverModal';

export function CamerasPage({ onOpenZonePainter }: { onOpenZonePainter?: (cameraId: string) => void }) {
  const { showToast } = useToast();
  const [cameras, setCameras] = useState<Camera[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingCamera, setEditingCamera] = useState<Camera | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Camera | null>(null);
  const [showDiscover, setShowDiscover] = useState(false);

  const refresh = useCallback(async () => {
    const cams = await listCameras();
    setCameras(cams);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const handleSave = async (cam: Partial<Camera>) => {
    if (editingCamera) { 
      await updateCamera(editingCamera.id, cam); 
      showToast('Camera updated', 'success'); 
    } else { 
      await createCamera(cam); 
      showToast('Camera added', 'success'); 
    }
    refresh(); 
    setShowForm(false); 
    setEditingCamera(null);
  };

  const handleRestart = async (id: string) => {
    await restartCamera(id);
    showToast('Camera restarted', 'info');
  };

  const handleDelete = async (id: string) => {
    await deleteCamera(id);
    refresh(); 
    setDeleteTarget(null);
    showToast('Camera deleted', 'success');
  };

  return (
    <div className="cameras-page">
      <div className="cameras-toolbar">
        <div className="cameras-count"><strong>{cameras.length}</strong> cameras registered</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="secondary-button" onClick={() => setShowDiscover(true)}>
            <ScanLine size={16} /> Discover
          </button>
          <button className="primary-button" onClick={() => { setEditingCamera(null); setShowForm(true); }}>
            <Plus size={16} /> Add camera
          </button>
        </div>
      </div>
      <div className="cameras-grid">
        {loading ? <LoadingRow /> :
         cameras.map((cam) => (
           <CameraCard 
             key={cam.id} 
             cam={cam} 
             onEdit={(cam) => { setEditingCamera(cam); setShowForm(true); }}
             onRestart={handleRestart}
             onDeleteTarget={setDeleteTarget}
             onOpenZonePainter={onOpenZonePainter}
           />
         ))}
      </div>
      {showForm && (
        <CameraFormModal 
          camera={editingCamera} 
          onSave={handleSave} 
          onClose={() => { setShowForm(false); setEditingCamera(null); }} 
        />
      )}
      {deleteTarget && (
        <ConfirmDialog 
          title="Delete camera?" 
          message={`Remove "${deleteTarget.name}"?`} 
          onConfirm={() => handleDelete(deleteTarget.id)} 
          onCancel={() => setDeleteTarget(null)} 
        />
      )}
      {showDiscover && (
        <CameraDiscoverModal 
          onClose={() => setShowDiscover(false)} 
          onAdd={handleSave} 
        />
      )}
    </div>
  );
}
