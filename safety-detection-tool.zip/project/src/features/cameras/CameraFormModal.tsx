import { useState } from 'react';
import { Check, X } from 'lucide-react';
import type { Camera } from '@/lib/db';

interface CameraFormModalProps {
  camera: Camera | null;
  onSave: (c: Partial<Camera>) => void;
  onClose: () => void;
}

export function CameraFormModal({ camera, onSave, onClose }: CameraFormModalProps) {
  const [form, setForm] = useState({
    name: camera?.name || '', 
    floor: camera?.floor || 'ground', 
    zone_type: camera?.zone_type || 'entrance',
    rtsp_url: camera?.rtsp_url || '', 
    status: camera?.status || 'online', 
    camera_code: camera?.camera_code || '',
    department: camera?.department || '', 
    fps: camera?.fps || 15,
  });

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="form-modal" onClick={(e) => e.stopPropagation()}>
        <div className="form-modal-header">
          <h2>{camera ? 'Edit camera' : 'Add camera'}</h2>
          <button onClick={onClose} className="modal-close"><X size={18} /></button>
        </div>
        <div className="form-modal-body">
          <label className="form-field">
            <span>Name</span>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Oven Line Camera" />
          </label>
          <label className="form-field">
            <span>Floor</span>
            <select value={form.floor} onChange={(e) => setForm({ ...form, floor: e.target.value })}>
              <option value="ground">Ground</option>
              <option value="first">First</option>
              <option value="second">Second</option>
              <option value="shop">Shop</option>
            </select>
          </label>
          <label className="form-field">
            <span>Zone type</span>
            <input value={form.zone_type} onChange={(e) => setForm({ ...form, zone_type: e.target.value })} placeholder="entrance, oven, packing" />
          </label>
          <label className="form-field">
            <span>RTSP URL</span>
            <input value={form.rtsp_url} onChange={(e) => setForm({ ...form, rtsp_url: e.target.value })} placeholder="rtsp://admin:****@192.168.1.64/..." />
          </label>
          <label className="form-field">
            <span>Camera code</span>
            <input value={form.camera_code} onChange={(e) => setForm({ ...form, camera_code: e.target.value })} placeholder="CAM-01" />
          </label>
          <label className="form-field">
            <span>Department</span>
            <input value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} placeholder="Production" />
          </label>
          <label className="form-field">
            <span>Status</span>
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
              <option value="online">Online</option>
              <option value="offline">Offline</option>
              <option value="warning">Warning</option>
            </select>
          </label>
          <label className="form-field">
            <span>FPS</span>
            <input type="number" value={form.fps} onChange={(e) => setForm({ ...form, fps: Number(e.target.value) })} />
          </label>
        </div>
        <div className="form-modal-footer">
          <button className="secondary-button" onClick={onClose}>Cancel</button>
          <button className="primary-button" onClick={() => onSave(form)} disabled={!form.name}>
            <Check size={16} /> Save
          </button>
        </div>
      </div>
    </div>
  );
}
