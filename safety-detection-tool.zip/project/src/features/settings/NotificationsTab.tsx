import { ToggleRow } from './ToggleRow';

interface NotificationsTabProps {
  settings: any[];
  onSave: (key: string, val: string) => Promise<void>;
}

export function NotificationsTab({ settings, onSave }: NotificationsTabProps) {
  return (
    <div className="panel settings-panel">
      <div className="panel-header">
        <div>
          <h2>Notification Preferences</h2>
          <p>Control how and when you receive alerts</p>
        </div>
      </div>
      <div className="settings-list">
        {settings.filter((s) => s.key.startsWith('notify_')).map((s) => (
          <ToggleRow 
            key={s.key} 
            setting={s} 
            onSave={(val) => onSave(s.key, val)} 
          />
        ))}
      </div>
    </div>
  );
}
