import { Camera } from 'lucide-react';
import type { Camera as CameraType } from '@/lib/db';

interface BaselinesTabProps {
  cameras: CameraType[];
  onUpload: (cameraId: string) => void;
}

export function BaselinesTab({ cameras, onUpload }: BaselinesTabProps) {
  return (
    <div className="panel settings-panel">
      <div className="panel-header">
        <div>
          <h2>Dirty Floor Baselines</h2>
          <p>Per-camera baseline image management</p>
        </div>
      </div>
      <div className="settings-list">
        {cameras.map((c) => (
          <div key={c.id} className="threshold-row">
            <div className="threshold-info">
              <strong>{c.name}</strong>
              <small>{c.floor} · {c.zone_type}</small>
            </div>
            <button className="secondary-button" onClick={() => onUpload(c.id)}>
              <Camera size={14} /> Upload
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
