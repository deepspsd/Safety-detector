import { Send, Check, Loader2 } from 'lucide-react';

interface TelegramTabProps {
  botToken: string;
  setBotToken: (val: string) => void;
  chatId: string;
  setChatId: (val: string) => void;
  testing: boolean;
  onSave: () => void;
  onTest: () => void;
}

export function TelegramTab({ botToken, setBotToken, chatId, setChatId, testing, onSave, onTest }: TelegramTabProps) {
  return (
    <div className="panel settings-panel">
      <div className="panel-header">
        <div>
          <h2>Telegram Bot Configuration</h2>
          <p>Send push notifications when safety alerts are confirmed</p>
        </div>
      </div>
      <div className="telegram-guide">
        <div className="telegram-step">
          <div className="step-num">1</div>
          <div>
            <strong>Create a bot</strong>
            <p>Open <code>@BotFather</code> on Telegram, send <code>/newbot</code>, follow prompts to get your bot token.</p>
          </div>
        </div>
        <div className="telegram-step">
          <div className="step-num">2</div>
          <div>
            <strong>Get your chat ID</strong>
            <p>Send a message to your bot, then open <code>https://api.telegram.org/bot&lt;TOKEN&gt;/getUpdates</code> to find your chat ID.</p>
          </div>
        </div>
        <div className="telegram-step">
          <div className="step-num">3</div>
          <div>
            <strong>Enter credentials</strong>
            <p>Paste your bot token and chat ID below, then test the connection.</p>
          </div>
        </div>
      </div>
      <div className="telegram-form">
        <label className="form-field">
          <span>Bot Token</span>
          <input value={botToken} onChange={(e) => setBotToken(e.target.value)} placeholder="123456789:ABCdef..." type="password" />
        </label>
        <label className="form-field">
          <span>Chat ID</span>
          <input value={chatId} onChange={(e) => setChatId(e.target.value)} placeholder="123456789" />
        </label>
      </div>
      <div className="telegram-actions">
        <button className="primary-button" onClick={onSave} disabled={!botToken || !chatId}>
          <Check size={16} /> Save
        </button>
        <button className="secondary-button" onClick={onTest} disabled={!botToken || !chatId || testing}>
          {testing ? <Loader2 size={16} className="spin" /> : <Send size={16} />} {testing ? 'Sending...' : 'Test'}
        </button>
      </div>
      <div className="telegram-status">
        <div className={`telegram-status-indicator ${botToken && chatId ? 'configured' : 'not-configured'}`} />
        <span>{botToken && chatId ? 'Telegram configured' : 'Not configured'}</span>
      </div>
    </div>
  );
}
