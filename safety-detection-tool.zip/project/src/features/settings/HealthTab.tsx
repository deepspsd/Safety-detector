export function HealthTab() {
  return (
    <div className="panel settings-panel">
      <div className="panel-header">
        <div>
          <h2>Platform Health</h2>
          <p>System health logs and analytics</p>
        </div>
      </div>
      <div className="settings-list">
        <div className="threshold-row">
          <div className="threshold-info">
            <strong>AI Inference Engine</strong>
            <small>Healthy · 18ms avg latency</small>
          </div>
          <span className="status-badge confirmed">Healthy</span>
        </div>
        <div className="threshold-row">
          <div className="threshold-info">
            <strong>Camera Stream Manager</strong>
            <small>21/23 cameras connected</small>
          </div>
          <span className="status-badge confirmed">Healthy</span>
        </div>
        <div className="threshold-row">
          <div className="threshold-info">
            <strong>Telegram Gateway</strong>
            <small>Bot API reachable</small>
          </div>
          <span className="status-badge confirmed">Healthy</span>
        </div>
      </div>
    </div>
  );
}
