import { useState, useEffect } from 'react';
import { Send, SlidersHorizontal, Bell, Camera, Package, Settings, Gauge } from 'lucide-react';
import { useSettings, updateSetting, useCameras, useCylinderLogs } from '@/lib/hooks';
import { testTelegram } from '@/api/alerts.api';
import { useToast } from '@/providers/ToastProvider';

import { TelegramTab } from './TelegramTab';
import { ThresholdsTab } from './ThresholdsTab';
import { NotificationsTab } from './NotificationsTab';
import { BaselinesTab } from './BaselinesTab';
import { CylindersTab } from './CylindersTab';
import { ModelsTab } from './ModelsTab';
import { HealthTab } from './HealthTab';

type Tab = 'thresholds' | 'notifications' | 'telegram' | 'baselines' | 'cylinders' | 'models' | 'health';

export function SettingsPage() {
  const { showToast } = useToast();
  const [tab, setTab] = useState<Tab>('telegram');
  const { settings, loading, refresh } = useSettings();
  const { cameras } = useCameras();
  const { logs, loading: logsLoading } = useCylinderLogs();
  
  const [botToken, setBotToken] = useState('');
  const [chatId, setChatId] = useState('');
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    if (!loading) {
      setBotToken(settings.find(s => s.key === 'telegram_bot_token')?.value || '');
      setChatId(settings.find(s => s.key === 'telegram_chat_id')?.value || '');
    }
  }, [settings, loading]);

  const handleSaveTelegram = async () => {
    await updateSetting('telegram_bot_token', botToken);
    await updateSetting('telegram_chat_id', chatId);
    refresh();
    showToast('Telegram configuration saved', 'success');
  };

  const handleTestTelegram = async () => {
    setTesting(true);
    await updateSetting('telegram_bot_token', botToken);
    await updateSetting('telegram_chat_id', chatId);
    try {
      await testTelegram();
      showToast('Test message sent', 'success');
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Failed to send test message', 'error');
    }
    setTesting(false);
  };

  const handleSaveSetting = async (key: string, val: string) => {
    await updateSetting(key, val); 
    refresh(); 
    showToast(`${key} updated`, 'success');
  };

  return (
    <div className="settings-page">
      <div className="settings-tabs">
        <button className={`tab-item ${tab === 'telegram' ? 'active' : ''}`} onClick={() => setTab('telegram')}><Send size={15} /> Telegram</button>
        <button className={`tab-item ${tab === 'thresholds' ? 'active' : ''}`} onClick={() => setTab('thresholds')}><SlidersHorizontal size={15} /> Thresholds</button>
        <button className={`tab-item ${tab === 'notifications' ? 'active' : ''}`} onClick={() => setTab('notifications')}><Bell size={15} /> Notifications</button>
        <button className={`tab-item ${tab === 'baselines' ? 'active' : ''}`} onClick={() => setTab('baselines')}><Camera size={15} /> Baselines</button>
        <button className={`tab-item ${tab === 'cylinders' ? 'active' : ''}`} onClick={() => setTab('cylinders')}><Package size={15} /> Cylinders</button>
        <button className={`tab-item ${tab === 'models' ? 'active' : ''}`} onClick={() => setTab('models')}><Settings size={15} /> AI Models</button>
        <button className={`tab-item ${tab === 'health' ? 'active' : ''}`} onClick={() => setTab('health')}><Gauge size={15} /> Health</button>
      </div>

      {tab === 'telegram' && (
        <TelegramTab 
          botToken={botToken} setBotToken={setBotToken}
          chatId={chatId} setChatId={setChatId}
          testing={testing} onSave={handleSaveTelegram} onTest={handleTestTelegram}
        />
      )}

      {tab === 'thresholds' && (
        <ThresholdsTab settings={settings} loading={loading} onSave={handleSaveSetting} />
      )}

      {tab === 'notifications' && (
        <NotificationsTab settings={settings} onSave={handleSaveSetting} />
      )}

      {tab === 'baselines' && (
        <BaselinesTab cameras={cameras} onUpload={() => showToast('Baseline upload (demo)', 'info')} />
      )}

      {tab === 'cylinders' && (
        <CylindersTab logs={logs} loading={logsLoading} />
      )}

      {tab === 'models' && <ModelsTab />}
      
      {tab === 'health' && <HealthTab />}
    </div>
  );
}
