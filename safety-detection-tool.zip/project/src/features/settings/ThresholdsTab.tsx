import { Loader2 } from 'lucide-react';
import { ThresholdRow } from './ThresholdRow';

interface ThresholdsTabProps {
  settings: any[];
  loading: boolean;
  onSave: (key: string, val: string) => Promise<void>;
}

export function ThresholdsTab({ settings, loading, onSave }: ThresholdsTabProps) {
  const thresholdSettings = settings.filter((s) => !s.key.startsWith('telegram_') && !s.key.startsWith('notify_'));

  return (
    <div className="panel settings-panel">
      <div className="panel-header">
        <div>
          <h2>Detection Thresholds</h2>
          <p>Adjust AI detection sensitivity and timing</p>
        </div>
      </div>
      {loading ? (
        <div className="loading-row"><Loader2 size={18} className="spin" /> Loading...</div>
      ) : (
        <div className="settings-list">
          {thresholdSettings.map((s) => (
            <ThresholdRow 
              key={s.key} 
              setting={s} 
              onSave={(val) => onSave(s.key, val)} 
            />
          ))}
        </div>
      )}
    </div>
  );
}
