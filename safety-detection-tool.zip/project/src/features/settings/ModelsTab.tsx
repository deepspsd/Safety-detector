export function ModelsTab() {
  return (
    <div className="panel settings-panel">
      <div className="panel-header">
        <div>
          <h2>AI Models & Rules</h2>
          <p>Model registry, rule profiles, and workflow profiles</p>
        </div>
      </div>
      <div className="settings-list">
        <div className="threshold-row">
          <div className="threshold-info">
            <strong>PPE Detection Model</strong>
            <small>YOLOv8 · v1.0 · Active</small>
          </div>
          <span className="status-badge confirmed">Active</span>
        </div>
        <div className="threshold-row">
          <div className="threshold-info">
            <strong>Face Recognition</strong>
            <small>FaceNet · v0.9 · Active</small>
          </div>
          <span className="status-badge confirmed">Active</span>
        </div>
        <div className="threshold-row">
          <div className="threshold-info">
            <strong>Pose Estimation</strong>
            <small>MediaPipe · v0.8 · Standby</small>
          </div>
          <span className="status-badge pending_review">Standby</span>
        </div>
      </div>
    </div>
  );
}
