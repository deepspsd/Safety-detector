import { useState } from 'react';
import { Check, Edit3 } from 'lucide-react';

interface ThresholdRowProps {
  setting: any;
  onSave: (v: string) => void;
}

export function ThresholdRow({ setting, onSave }: ThresholdRowProps) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(setting.value);

  return (
    <div className="threshold-row">
      <div className="threshold-info">
        <strong>{setting.key.replace(/_/g, ' ')}</strong>
        <small>{setting.description}</small>
      </div>
      {editing ? (
        <div className="threshold-edit">
          <input value={value} onChange={(e) => setValue(e.target.value)} autoFocus />
          <button className="primary-button small" onClick={() => { onSave(value); setEditing(false); }}>
            <Check size={14} />
          </button>
          <button className="secondary-button small" onClick={() => { setEditing(false); setValue(setting.value); }}>
            Cancel
          </button>
        </div>
      ) : (
        <div className="threshold-display">
          <span>{setting.value}</span>
          <button className="card-action" onClick={() => setEditing(true)}>
            <Edit3 size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
