interface ToggleRowProps {
  setting: any;
  onSave: (v: string) => void;
}

export function ToggleRow({ setting, onSave }: ToggleRowProps) {
  const enabled = setting.value === 'true';

  return (
    <div className="threshold-row">
      <div className="threshold-info">
        <strong>{setting.key.replace(/_/g, ' ')}</strong>
        <small>{setting.description}</small>
      </div>
      <button 
        className={`monitor-toggle ${enabled ? 'enabled' : ''}`} 
        onClick={() => onSave(enabled ? 'false' : 'true')}
      >
        <span /> {enabled ? 'On' : 'Off'}
      </button>
    </div>
  );
}
