import { Loader2 } from 'lucide-react';

interface CylindersTabProps {
  logs: any[];
  loading: boolean;
}

export function CylindersTab({ logs, loading }: CylindersTabProps) {
  return (
    <div className="panel settings-panel">
      <div className="panel-header">
        <div>
          <h2>Cylinder Usage Logs</h2>
          <p>Gas cylinder detection and swap history</p>
        </div>
      </div>
      {loading ? (
        <div className="loading-row"><Loader2 size={18} className="spin" /> Loading...</div>
      ) : (
        <div className="alerts-table">
          {logs.map((l) => (
            <div className="alert-card" key={l.id}>
              <div className="alert-card-body">
                <strong>{l.camera_name}</strong>
                <small>{l.event_type} · {l.usage_day_count} days · {l.created_at}</small>
              </div>
              <span className="status-badge confirmed">{l.event_type}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
