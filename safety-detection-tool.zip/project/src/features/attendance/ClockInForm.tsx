import { Check } from 'lucide-react';
import type { Employee } from '@/lib/db';

interface ClockInFormProps {
  employees: Employee[];
  clockInForm: any;
  setClockInForm: (val: any) => void;
  onCancel: () => void;
  onSubmit: () => void;
}

export function ClockInForm({ employees, clockInForm, setClockInForm, onCancel, onSubmit }: ClockInFormProps) {
  return (
    <div className="panel clockin-form">
      <div className="form-modal-body">
        <label className="form-field">
          <span>Employee</span>
          <select value={clockInForm.employee_name} onChange={(e) => setClockInForm({ ...clockInForm, employee_name: e.target.value })}>
            <option value="">Select employee</option>
            {employees.map((emp) => <option key={emp.id} value={emp.name}>{emp.name}</option>)}
          </select>
        </label>
        <label className="form-field">
          <span>Camera</span>
          <input value={clockInForm.camera_name} onChange={(e) => setClockInForm({ ...clockInForm, camera_name: e.target.value })} placeholder="Optional" />
        </label>
        <label className="form-field">
          <span>Method</span>
          <select value={clockInForm.method} onChange={(e) => setClockInForm({ ...clockInForm, method: e.target.value })}>
            <option value="manual">Manual</option>
            <option value="face">Face</option>
            <option value="qr">QR</option>
          </select>
        </label>
        <label className="form-field">
          <span>Notes</span>
          <input value={clockInForm.notes} onChange={(e) => setClockInForm({ ...clockInForm, notes: e.target.value })} placeholder="Optional notes" />
        </label>
      </div>
      <div className="form-modal-footer">
        <button className="secondary-button" onClick={onCancel}>Cancel</button>
        <button className="primary-button" onClick={onSubmit}><Check size={15} /> Clock In</button>
      </div>
    </div>
  );
}
