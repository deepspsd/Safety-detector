import { Loader2 } from 'lucide-react';
import type { AttendanceRecord } from '@/lib/db';

interface AttendanceTableProps {
  records: AttendanceRecord[];
  loading: boolean;
  onClockOut: (id: string) => void;
}

export function AttendanceTable({ records, loading, onClockOut }: AttendanceTableProps) {
  return (
    <div className="alerts-table-wrap">
      {loading ? (
        <div className="loading-row"><Loader2 size={18} className="spin" /> Loading...</div>
      ) : (
        <div className="alerts-table">
          {records.map((r) => (
            <div className="alert-card" key={r.id}>
              <div className="alert-card-body">
                <strong>{r.employee_name}</strong>
                <small>{r.camera_name} · {r.method} · {r.clock_in}</small>
              </div>
              <span className={`status-badge ${r.clock_out ? 'confirmed' : 'pending_review'}`}>
                {r.clock_out ? r.clock_out : 'Active'}
              </span>
              {!r.clock_out && (
                <button className="primary-button small" onClick={() => onClockOut(r.id)}>
                  Clock Out
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
