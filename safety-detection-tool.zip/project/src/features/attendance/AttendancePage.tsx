import { useState } from 'react';
import { Download, LogIn } from 'lucide-react';
import { useAttendance, useEmployees, clockInEmployee, clockOutEmployee } from '@/lib/hooks';
import { useToast } from '@/providers/ToastProvider';
import { AttendanceStatsRow } from './AttendanceStatsRow';
import { ClockInForm } from './ClockInForm';
import { AttendanceTable } from './AttendanceTable';

export function AttendancePage() {
  const { showToast } = useToast();
  const { records, loading, refresh } = useAttendance();
  const { employees } = useEmployees();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [showClockIn, setShowClockIn] = useState(false);
  const [clockInForm, setClockInForm] = useState({ employee_name: '', camera_name: '', method: 'manual', notes: '' });

  const present = new Set(records.filter((r) => r.clock_in && !r.clock_out).map((r) => r.employee_name)).size;
  const total = employees.length;
  const absent = Math.max(0, total - present);
  const late = records.filter((r) => (r.notes || '').toLowerCase().includes('late')).length;

  const handleClockIn = async () => {
    if (!clockInForm.employee_name) { showToast('Please select an employee', 'error'); return; }
    await clockInEmployee(clockInForm);
    refresh(); setShowClockIn(false);
    setClockInForm({ employee_name: '', camera_name: '', method: 'manual', notes: '' });
    showToast('Employee clocked in', 'success');
  };

  const handleClockOut = async (id: string) => { await clockOutEmployee(id); refresh(); showToast('Employee clocked out', 'success'); };

  const handleExport = () => {
    const csv = ['ID,Employee,Camera,Method,Clock In,Clock Out,Notes'];
    records.forEach((r) => { csv.push(`${r.id},${r.employee_name},${r.camera_name},${r.method},${r.clock_in},${r.clock_out || ''},${r.notes}`); });
    const blob = new Blob([csv.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `attendance-${date}.csv`; a.click();
    URL.revokeObjectURL(url);
    showToast('CSV downloaded', 'success');
  };

  return (
    <div className="attendance-page">
      <AttendanceStatsRow present={present} absent={absent} late={late} total={total} />
      <div className="attendance-toolbar">
        <div className="filter-group">
          <div className="filter-select"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
        </div>
        <div className="attendance-actions">
          <button className="secondary-button" onClick={handleExport}><Download size={15} /> Export CSV</button>
          <button className="primary-button" onClick={() => setShowClockIn(!showClockIn)}><LogIn size={15} /> Manual Clock-In</button>
        </div>
      </div>
      {showClockIn && (
        <ClockInForm 
          employees={employees} 
          clockInForm={clockInForm} 
          setClockInForm={setClockInForm} 
          onCancel={() => setShowClockIn(false)} 
          onSubmit={handleClockIn} 
        />
      )}
      <AttendanceTable records={records} loading={loading} onClockOut={handleClockOut} />
    </div>
  );
}
