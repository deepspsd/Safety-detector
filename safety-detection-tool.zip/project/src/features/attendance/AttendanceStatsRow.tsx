import { Users, Clock } from 'lucide-react';

export function AttendanceStatsRow({ present, absent, late, total }: { present: number; absent: number; late: number; total: number }) {
  return (
    <div className="stats-grid">
      <div className="stat-card">
        <div className="stat-icon green"><Users size={19} /></div>
        <div className="stat-label">Present</div>
        <strong className="stat-value">{present}</strong>
      </div>
      <div className="stat-card">
        <div className="stat-icon orange"><Users size={19} /></div>
        <div className="stat-label">Absent</div>
        <strong className="stat-value">{absent}</strong>
      </div>
      <div className="stat-card">
        <div className="stat-icon yellow"><Clock size={19} /></div>
        <div className="stat-label">Late</div>
        <strong className="stat-value">{late}</strong>
      </div>
      <div className="stat-card">
        <div className="stat-icon blue"><Users size={19} /></div>
        <div className="stat-label">Total</div>
        <strong className="stat-value">{total}</strong>
      </div>
    </div>
  );
}
