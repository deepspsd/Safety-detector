import { useState, useEffect } from 'react';
import { ShieldCheck, AlertTriangle, Maximize2, X } from 'lucide-react';
import type { Camera } from '../../lib/db';

const images = [
  'https://images.pexels.com/photos/5953714/pexels-photo-5953714.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/34718930/pexels-photo-34718930.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/11515346/pexels-photo-11515346.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
];

export function TVDisplayPage({ cameras = [] }: { cameras?: Camera[] }) {
  const [cycleIdx, setCycleIdx] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [alertBanner, setAlertBanner] = useState<string | null>(null);
  const [clock, setClock] = useState(new Date());
  const onlineCameras = cameras.filter((c) => c.status === 'online');

  useEffect(() => {
    const interval = setInterval(() => { setCycleIdx((prev) => (prev + 1) % Math.max(1, onlineCameras.length)); }, 30000);
    return () => clearInterval(interval);
  }, [onlineCameras.length]);

  useEffect(() => {
    const clockInterval = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(clockInterval);
  }, []);

  useEffect(() => {
    const alerts = ['ALERT: No safety helmet detected — Oven Line', 'ALERT: Unauthorized cashbox access — Shop Counter', 'ALERT: Phone usage in no-phone zone — Work Table A'];
    const interval = setInterval(() => { setAlertBanner(alerts[Math.floor(Math.random() * alerts.length)]); setTimeout(() => setAlertBanner(null), 5000); }, 15000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  const toggleFullscreen = () => {
    if (document.fullscreenElement) { document.exitFullscreen?.(); }
    else { document.documentElement.requestFullscreen?.(); }
  };

  return (
    <div className="tv-page">
      <div className="tv-header">
        <div className="tv-brand"><ShieldCheck size={22} /> OccuSafe Monitoring Wall</div>
        <div className="tv-clock">{clock.toLocaleTimeString()}</div>
        <button className="tv-exit" onClick={toggleFullscreen}>{isFullscreen ? <X size={18} /> : <Maximize2 size={18} />}</button>
      </div>
      <div className="tv-grid">
        {onlineCameras.slice(0, 4).map((cam, i) => (
          <div className="tv-tile" key={cam.id}>
            <img src={images[i % 3]} alt={cam.name} />
            <div className="tile-overlay" />
            <div className="tile-top"><span><i /> LIVE</span><small>{cam.fps} FPS</small></div>
            <div className="tile-bottom"><div><strong>{cam.name}</strong><small>{cam.floor} · {cam.zone_type}</small></div></div>
          </div>
        ))}
      </div>
      {alertBanner && <div className="tv-alert-banner"><AlertTriangle size={20} /> {alertBanner}</div>}
    </div>
  );
}
