import { useState } from 'react';
import { Save } from 'lucide-react';
import { useToast } from '@/providers/ToastProvider';

export function ProfilePage() {
  const { showToast } = useToast();
  const [name, setName] = useState('Alex Morgan');
  const [email] = useState('admin@occusafe.local');
  const [role, setRole] = useState('Administrator');
  const [cameraType, setCameraType] = useState('rtsp');
  const [rtspUrl, setRtspUrl] = useState('');
  const [sensitivity, setSensitivity] = useState(75);
  const [ppeItems, setPpeItems] = useState<string[]>(['NO-Hardhat', 'NO-Safety Vest']);
  const [noPhoneZone, setNoPhoneZone] = useState(true);
  const [notifySound, setNotifySound] = useState(true);
  const [notifyUi, setNotifyUi] = useState(true);

  const allPpe = ['NO-Hardhat', 'NO-Safety Vest', 'NO-Gloves', 'NO-Goggles', 'NO-Mask'];

  const handleSave = () => { showToast('Profile saved successfully', 'success'); };

  return (
    <div className="profile-page">
      <div className="panel profile-header-card">
        <div className="profile-avatar-lg">AM</div>
        <div className="profile-info"><h1>Alex Morgan</h1><p>{email} · {role}</p><small>Account created: January 2024</small></div>
      </div>
      <div className="profile-grid">
        <div className="panel">
          <div className="panel-header"><div><h2>Account information</h2><p>Update your personal details</p></div></div>
          <div className="form-modal-body" style={{ display: 'block' }}>
            <label className="form-field"><span>Name</span><input value={name} onChange={(e) => setName(e.target.value)} /></label>
            <label className="form-field"><span>Email (read-only)</span><input value={email} readOnly style={{ opacity: 0.6 }} /></label>
            <label className="form-field"><span>Role</span><select value={role} onChange={(e) => setRole(e.target.value)}><option>Administrator</option><option>Bakery Worker</option><option>Supervisor</option><option>None</option></select></label>
          </div>
        </div>
        <div className="panel">
          <div className="panel-header"><div><h2>Detection configuration</h2><p>Personal camera and AI settings</p></div></div>
          <div className="form-modal-body" style={{ display: 'block' }}>
            <label className="form-field"><span>Camera type</span><select value={cameraType} onChange={(e) => setCameraType(e.target.value)}><option value="webcam">Webcam</option><option value="rtsp">RTSP</option><option value="upload">Upload</option></select></label>
            {cameraType === 'rtsp' && <label className="form-field"><span>RTSP URL</span><input value={rtspUrl} onChange={(e) => setRtspUrl(e.target.value)} placeholder="rtsp://..." /></label>}
            <div className="form-field"><span>Detection sensitivity: {sensitivity}%</span><input type="range" min="0" max="100" value={sensitivity} onChange={(e) => setSensitivity(Number(e.target.value))} className="slider" /></div>
          </div>
        </div>
        <div className="panel">
          <div className="panel-header"><div><h2>PPE monitoring</h2><p>Select which violations to monitor</p></div></div>
          <div className="ppe-list">{allPpe.map((item) => <label key={item} className={`ppe-chip ${ppeItems.includes(item) ? 'selected' : ''}`}><input type="checkbox" checked={ppeItems.includes(item)} onChange={() => setPpeItems((prev) => prev.includes(item) ? prev.filter((p) => p !== item) : [...prev, item])} /> {item}</label>)}</div>
        </div>
        <div className="panel">
          <div className="panel-header"><div><h2>Notification preferences</h2><p>Control alert delivery</p></div></div>
          <div className="settings-list">
            <div className="threshold-row"><div className="threshold-info"><strong>No-phone zone</strong><small>Flag phone usage in monitored areas</small></div><button className={`monitor-toggle ${noPhoneZone ? 'enabled' : ''}`} onClick={() => setNoPhoneZone(!noPhoneZone)}><span /> {noPhoneZone ? 'On' : 'Off'}</button></div>
            <div className="threshold-row"><div className="threshold-info"><strong>Sound alerts</strong><small>Play audio on critical alerts</small></div><button className={`monitor-toggle ${notifySound ? 'enabled' : ''}`} onClick={() => setNotifySound(!notifySound)}><span /> {notifySound ? 'On' : 'Off'}</button></div>
            <div className="threshold-row"><div className="threshold-info"><strong>UI notifications</strong><small>Show toast popups in app</small></div><button className={`monitor-toggle ${notifyUi ? 'enabled' : ''}`} onClick={() => setNotifyUi(!notifyUi)}><span /> {notifyUi ? 'On' : 'Off'}</button></div>
          </div>
        </div>
      </div>
      <div className="profile-save-bar"><button className="primary-button" onClick={handleSave}><Save size={16} /> Save changes</button></div>
    </div>
  );
}
