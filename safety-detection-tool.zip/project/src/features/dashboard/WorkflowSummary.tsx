import { useNavigate } from 'react-router-dom';
import { ArrowUpDown, Box, ChevronRight, DollarSign, Package } from 'lucide-react';

export function WorkflowSummary({ workflow }: { workflow: any }) {
  const navigate = useNavigate();

  const wfItems = [
    {
      key: 'cash',
      label: 'Cash events',
      icon: DollarSign,
      tone: 'orange' as const,
      value: workflow?.cash_events_today ?? 0,
    },
    {
      key: 'stock',
      label: 'Stock events',
      icon: Package,
      tone: 'blue' as const,
      value: workflow?.stock_events_today ?? 0,
    },
    {
      key: 'lift',
      label: 'Lift events',
      icon: ArrowUpDown,
      tone: 'green' as const,
      value: workflow?.lift_events_today ?? 0,
    },
    {
      key: 'packing',
      label: 'Packing events',
      icon: Box,
      tone: 'yellow' as const,
      value: workflow?.packing_events_today ?? 0,
    },
  ];

  return (
    <div className="panel">
      <div className="panel-header">
        <div>
          <h2>Workflow Summary</h2>
          <p>Today's operational events</p>
        </div>
        <button className="text-button" onClick={() => navigate('/workflow')}>
          View all <ChevronRight size={12} />
        </button>
      </div>
      <div className="workflow-summary-grid">
        {wfItems.map((item) => (
          <div className="wf-stat" key={item.key}>
            <div className={`wf-icon ${item.tone}`}>
              <item.icon size={18} />
            </div>
            <div>
              <strong>{item.value}</strong>
              <small>{item.label}</small>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
