import { AlertTriangle } from 'lucide-react';

/** Seven-bar sparkline used inside each stat card. */
export function StatChart() {
  return (
    <div className="stat-chart">
      {Array.from({ length: 7 }).map((_, i) => (
        <span key={i} />
      ))}
    </div>
  );
}

/** A single stat card following the project's established pattern. */
export function StatCard({
  tone,
  icon: Icon,
  label,
  trend,
  value,
}: {
  tone: 'orange' | 'green' | 'blue' | 'yellow';
  icon: typeof AlertTriangle;
  label: string;
  trend?: string;
  value: string | number;
}) {
  return (
    <div className="stat-card">
      <div className={`stat-icon ${tone}`}>
        <Icon size={19} />
      </div>
      <div className="stat-label">
        {label}
        {trend && <span className="trend-up">{trend}</span>}
      </div>
      <strong className="stat-value">{value}</strong>
      <StatChart />
    </div>
  );
}
