import { useNavigate } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

export function FloorSummaryCard({ floorStats }: { floorStats: any[] }) {
  const navigate = useNavigate();

  return (
    <div className="panel">
      <div className="panel-header">
        <div>
          <h2>Floor Performance</h2>
          <p>Cameras, alerts and compliance per floor</p>
        </div>
        <button className="text-button" onClick={() => navigate('/floors/ground')}>
          Details <ChevronRight size={12} />
        </button>
      </div>
      <div className="floor-list">
        {floorStats.map((floor) => (
          <div className="floor-row" key={floor.id}>
            <div className="floor-badge" style={{ background: floor.color }}>
              {floor.short}
            </div>
            <div className="floor-name">
              <strong>{floor.name}</strong>
              <small>
                {floor.cameraCount} cameras · {floor.alertCount} alerts
              </small>
            </div>
            <div className="floor-progress">
              <div>
                <span style={{ width: `${floor.compliance}%`, background: floor.color }} />
              </div>
              <strong>{floor.compliance}%</strong>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
