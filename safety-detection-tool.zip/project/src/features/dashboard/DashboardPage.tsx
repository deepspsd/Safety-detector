import { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle, ShieldCheck, Camera as CameraIcon, Users, FileText, ChevronRight,
  Play, CalendarDays, ChevronDown, Gauge,
} from 'lucide-react';
import {
  PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { listAlerts, getAlertStats } from '@/api/alerts.api';
import { listCameras } from '@/api/cameras.api';
import { getWorkflowSummary } from '@/api/workflow.api';
import { usePolling } from '@/hooks/usePolling';
import type { Alert, Camera } from '@/lib/db';

import { StatCard } from './StatCard';
import { AlertsTimeline } from './AlertsTimeline';
import { FloorSummaryCard } from './FloorSummaryCard';
import { CameraHealthGrid } from './CameraHealthGrid';
import { WorkflowSummary } from './WorkflowSummary';

const floorMeta = [
  { name: 'Ground Floor', id: 'ground', short: 'GF', color: '#ffb866' },
  { name: 'First Floor', id: 'first', short: '1F', color: '#63b6a5' },
  { name: 'Second Floor', id: 'second', short: '2F', color: '#ef8c73' },
  { name: 'Shop Floor', id: 'shop', short: 'SF', color: '#7e9cdb' },
];

const SEVERITY_COLORS: Record<string, string> = {
  critical: '#df785e',
  high: '#e9a93e',
  medium: '#7695ce',
  low: '#73c499',
};

export function DashboardPage() {
  const navigate = useNavigate();

  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [cameras, setCameras] = useState<Camera[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [workflow, setWorkflow] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const [alertRows, cameraRows, alertStats, wfSummary] = await Promise.all([
        listAlerts(),
        listCameras(),
        getAlertStats(),
        getWorkflowSummary(),
      ]);
      setAlerts(alertRows);
      setCameras(cameraRows);
      setStats(alertStats);
      setWorkflow(wfSummary);
    } catch (e) {
      console.error('Failed to load dashboard data:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Auto-refresh every 30 seconds.
  usePolling(refresh, 30_000);

  // ── Derived camera metrics ──────────────────────────────────────────────
  const cameraMetrics = useMemo(() => {
    const online = cameras.filter((c) => c.status === 'online').length;
    const warning = cameras.filter((c) => c.status === 'warning').length;
    const offline = cameras.filter((c) => c.status === 'offline').length;
    const avgFps =
      cameras.length > 0
        ? Math.round(
            cameras.reduce((sum, c) => sum + (c.fps || 0), 0) / cameras.length,
          )
        : 0;
    return { online, warning, offline, avgFps, total: cameras.length };
  }, [cameras]);

  // ── Compliance / safety score ────────────────────────────────────────────
  const compliance =
    stats?.compliance_percentage != null ? stats.compliance_percentage : 100;
  const complianceDeg = `${Math.min(Math.max(compliance, 0), 100)}%`;

  // ── Alerts by severity (donut data) ──────────────────────────────────────
  const severityData = useMemo(() => {
    const counts: Record<string, number> = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
    };
    for (const a of alerts) {
      counts[a.severity] = (counts[a.severity] || 0) + 1;
    }
    return (Object.keys(counts) as (keyof typeof counts)[]).map((key) => ({
      name: key,
      value: counts[key],
      color: SEVERITY_COLORS[key],
    }));
  }, [alerts]);

  // ── Alerts over time (last 7 days, line chart) ───────────────────────────
  const timeData = useMemo(() => {
    const days: { label: string; count: number }[] = [];
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      d.setHours(0, 0, 0, 0);
      const next = new Date(d);
      next.setDate(d.getDate() + 1);
      const count = alerts.filter((a) => {
        const t = new Date(a.detected_at).getTime();
        return t >= d.getTime() && t < next.getTime();
      }).length;
      days.push({
        label: d.toLocaleDateString('en-US', { weekday: 'short' }),
        count,
      });
    }
    return days;
  }, [alerts]);

  // ── Top violation types (horizontal bar chart) ───────────────────────────
  const violationData = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const a of alerts) {
      counts[a.title] = (counts[a.title] || 0) + 1;
    }
    return Object.entries(counts)
      .map(([name, count]) => ({ name, count }))
      .sort((x, y) => y.count - x.count)
      .slice(0, 5);
  }, [alerts]);

  // ── Floor performance ───────────────────────────────────────────────────
  const floorStats = useMemo(() => {
    return floorMeta.map((floor) => {
      const floorCams = cameras.filter((c) => c.floor === floor.id);
      const floorAlerts = alerts.filter((a) => a.floor === floor.id);
      const critical = floorAlerts.filter((a) => a.severity === 'critical').length;
      const compliance =
        floorAlerts.length > 0
          ? Math.round(((floorAlerts.length - critical) / floorAlerts.length) * 100)
          : 100;
      return {
        ...floor,
        cameraCount: floorCams.length,
        alertCount: floorAlerts.length,
        compliance,
      };
    });
  }, [cameras, alerts]);

  if (loading) {
    return (
      <div className="loading-row">
        <div className="spinner" /> Loading dashboard…
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      {/* ── Page heading ─────────────────────────────────────────────── */}
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            <span className="live-dot" /> DASHBOARD
          </div>
          <h1>Good morning, Admin</h1>
          <p>Here's what's happening across your facility today.</p>
        </div>
        <div className="heading-actions">
          <button className="secondary-button">
            <CalendarDays size={16} /> Today <ChevronDown size={14} />
          </button>
          <button
            className="primary-button"
            onClick={() => navigate('/monitor')}
          >
            <Play size={15} fill="currentColor" /> Open monitor
          </button>
        </div>
      </div>

      {/* ── Stat cards ───────────────────────────────────────────────── */}
      <div className="stats-grid">
        <StatCard
          tone="orange"
          icon={AlertTriangle}
          label="Total Alerts Today"
          trend="+12%"
          value={stats?.total_alerts ?? 0}
        />
        <StatCard
          tone="green"
          icon={ShieldCheck}
          label="Critical Alerts"
          trend="-4%"
          value={stats?.critical_alerts ?? 0}
        />
        <StatCard
          tone="blue"
          icon={Gauge}
          label="Compliance %"
          value={`${compliance}%`}
        />
        <StatCard
          tone="yellow"
          icon={CameraIcon}
          label="Active Cameras"
          value={`${cameraMetrics.online}/${cameraMetrics.total}`}
        />
        <StatCard
          tone="green"
          icon={Users}
          label="Employees Present"
          value={84}
        />
        <StatCard
          tone="blue"
          icon={FileText}
          label="Document Scans Today"
          value={24}
        />
      </div>

      {/* ── Camera overview + safety score ───────────────────────────── */}
      <div className="dashboard-grid">
        <CameraHealthGrid cameraMetrics={cameraMetrics} />

        {/* Safety score */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Safety Score</h2>
              <p>Overall facility compliance</p>
            </div>
          </div>
          <div className="score-wrap">
            <div className="score-ring-svg-container" style={{ position: 'relative', width: 136, height: 136, flex: '0 0 136px' }}>
              <svg width="136" height="136" viewBox="0 0 136 136" style={{ transform: 'rotate(-90deg)' }}>
                <circle
                  cx="68" cy="68" r="60"
                  fill="none"
                  stroke="var(--bg-tertiary, #edf1ee)"
                  strokeWidth="12"
                />
                <circle
                  cx="68" cy="68" r="60"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={2 * Math.PI * 60}
                  strokeDashoffset={2 * Math.PI * 60 * (1 - (Math.min(Math.max(compliance, 0), 100) / 100))}
                  style={{ transition: 'stroke-dashoffset 1.5s ease-out' }}
                />
              </svg>
              <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <strong style={{ fontSize: 28, letterSpacing: -1, color: 'var(--text-primary, #26372f)', lineHeight: 1 }}>{compliance}%</strong>
                <span style={{ fontSize: 9, color: 'var(--text-muted, #9ba7a1)', marginTop: 4 }}>compliance</span>
              </div>
            </div>
            <div className="score-copy">
              Your facility is performing{' '}
              {compliance >= 90
                ? 'well'
                : compliance >= 75
                  ? 'acceptably'
                  : 'below target'}
              . Keep monitoring to maintain safety standards.
              <p>
                {stats?.total_alerts ?? 0} total alerts ·{' '}
                {stats?.critical_alerts ?? 0} critical today
              </p>
            </div>
          </div>
          <div className="score-legend">
            <div>
              <span className="legend-bar green-bar" />
              <strong>{compliance}%</strong> compliant
            </div>
            <div>
              <span className="legend-bar orange-bar" />
              <strong>{100 - compliance}%</strong> violations
            </div>
          </div>
        </div>
      </div>

      {/* ── Charts row ──────────────────────────────────────────────── */}
      <div className="dashboard-grid">
        {/* Alerts by severity (donut) */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Alerts by Severity</h2>
              <p>Distribution of current alerts</p>
            </div>
          </div>
          <div style={{ height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={severityData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={2}
                >
                  {severityData.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    borderRadius: 8,
                    border: '1px solid #e3e9e5',
                    fontSize: 11,
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="chart-legend">
            {severityData.map((entry) => (
              <div key={entry.name}>
                <span
                  className="legend-bar"
                  style={{ background: entry.color }}
                />
                <strong>{entry.value}</strong> {entry.name}
              </div>
            ))}
          </div>
        </div>

        {/* Alerts over time (line chart) */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Alerts Over Time</h2>
              <p>Last 7 days</p>
            </div>
          </div>
          <div style={{ height: 220 }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={timeData}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: 'var(--text-muted, #829089)' }}
                  axisLine={{ stroke: '#eef1ef' }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: 'var(--text-muted, #829089)' }}
                  axisLine={false}
                  tickLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: 8,
                    border: '1px solid var(--border, #e3e9e5)',
                    fontSize: 11,
                    backgroundColor: 'var(--bg-primary, #fff)',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="count"
                  stroke="#10b981"
                  fillOpacity={1}
                  fill="url(#colorCount)"
                  strokeWidth={2.5}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* ── Lower grid: floor performance + recent alerts ────────────── */}
      <div className="lower-grid">
        <FloorSummaryCard floorStats={floorStats} />
        <AlertsTimeline alerts={alerts} />
      </div>

      <WorkflowSummary workflow={workflow} />

      {/* ── Top violation types (bar chart) ──────────────────────────── */}
      <div className="panel">
        <div className="panel-header">
          <div>
            <h2>Top Violation Types</h2>
            <p>Most frequent safety violations</p>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: '0 5px' }}>
          {violationData.length === 0 ? (
            <p style={{ fontSize: 12, color: 'var(--text-muted, #94a3b8)', textAlign: 'center', marginTop: 20 }}>No violations found.</p>
          ) : (
            violationData.map(({ name, count }, i) => {
              const max = violationData[0].count;
              const barColor = i === 0 ? '#ef4444' : i === 1 ? '#f59e0b' : '#10b981';
              return (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 20, fontSize: '0.75rem', color: 'var(--text-muted, #829089)', fontWeight: 700 }}>
                    #{i + 1}
                  </div>
                  <div style={{ width: 140, fontSize: '0.82rem', color: 'var(--text-secondary, #475569)', flexShrink: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {name}
                  </div>
                  <div style={{ flex: 1, background: 'var(--bg-tertiary, #e2e8f0)', borderRadius: 4, overflow: 'hidden', height: 8 }}>
                    <div style={{
                      width: `${(count / max) * 100}%`, height: '100%',
                      background: barColor, borderRadius: 4, transition: 'width 0.4s'
                    }} />
                  </div>
                  <div style={{ width: 28, fontSize: '0.78rem', color: 'var(--text-muted, #829089)', textAlign: 'right' }}>{count}×</div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
