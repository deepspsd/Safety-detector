import { useNavigate } from 'react-router-dom';
import { AlertTriangle, ChevronRight, ShieldCheck } from 'lucide-react';
import type { Alert } from '@/lib/db';

export function AlertsTimeline({ alerts }: { alerts: Alert[] }) {
  const navigate = useNavigate();
  const recentAlerts = alerts.slice(0, 6);

  return (
    <div className="panel">
      <div className="panel-header">
        <div>
          <h2>Recent Alerts</h2>
          <p>Latest safety events detected</p>
        </div>
        <button className="text-button" onClick={() => navigate('/alerts')}>
          View all <ChevronRight size={12} />
        </button>
      </div>
      <div className="alert-list">
        {recentAlerts.length === 0 ? (
          <div className="loading-row">No alerts detected.</div>
        ) : (
          recentAlerts.map((alert) => (
            <button
              className="alert-row"
              key={alert.id}
              onClick={() => navigate('/alerts')}
            >
              <div className={`severity-icon ${alert.severity}`}>
                {alert.severity === 'critical' || alert.severity === 'high' ? (
                  <AlertTriangle size={15} />
                ) : (
                  <ShieldCheck size={15} />
                )}
              </div>
              <div className="alert-copy">
                <strong>{alert.title}</strong>
                <small>
                  {alert.camera_name} · {alert.detected_at}
                </small>
              </div>
              <span className={`severity-text ${alert.severity}`}>
                {alert.severity}
              </span>
              <ChevronRight size={14} className="muted-icon" />
            </button>
          ))
        )}
      </div>
    </div>
  );
}
