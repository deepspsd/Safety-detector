import { useNavigate } from 'react-router-dom';
import { ChevronRight, Play } from 'lucide-react';

const HERO_IMAGE = 'https://images.pexels.com/photos/34718930/pexels-photo-34718930.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

export function CameraHealthGrid({ cameraMetrics }: { cameraMetrics: any }) {
  const navigate = useNavigate();

  return (
    <div className="panel">
      <div className="panel-header">
        <div>
          <h2>Camera Overview</h2>
          <p>Live status across all monitored zones</p>
        </div>
        <button className="text-button" onClick={() => navigate('/monitor')}>
          View all <ChevronRight size={12} />
        </button>
      </div>
      <div className="camera-hero">
        <img src={HERO_IMAGE} alt="Factory floor camera feed" />
        <div className="camera-gradient" />
        <div className="camera-hero-copy">
          <div className="camera-live">
            <span /> LIVE
          </div>
          <strong>{cameraMetrics.online} cameras streaming</strong>
          <small>Real-time monitoring across {cameraMetrics.total} feeds</small>
        </div>
        <button
          className="hero-play"
          onClick={() => navigate('/monitor')}
          aria-label="Open live monitor"
        >
          <Play size={16} fill="currentColor" />
        </button>
      </div>
      <div className="camera-metrics">
        <div>
          <span className="metric-dot online" />
          <strong>{cameraMetrics.online}</strong> online
        </div>
        <div>
          <span className="metric-dot warning" />
          <strong>{cameraMetrics.warning}</strong> warning
        </div>
        <div>
          <span className="metric-dot offline" />
          <strong>{cameraMetrics.offline}</strong> offline
        </div>
        <div className="fps">{cameraMetrics.avgFps} avg FPS</div>
      </div>
    </div>
  );
}
