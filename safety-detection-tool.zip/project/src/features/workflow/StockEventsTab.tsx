import { Package } from 'lucide-react';
import type { WorkflowEvent } from '@/lib/db';

export function StockEventsTab({ events }: { events: WorkflowEvent[] }) {
  return (
    <div className="alerts-table">
      {events.map((e) => (
        <div className="alert-card" key={e.id}>
          <div className={`severity-icon ${e.severity}`}><Package size={15} /></div>
          <div className="alert-card-body">
            <strong>{e.message}</strong>
            <small>
              {e.camera_name} · {e.created_at}
              {e.duration ? ` · ${e.duration}s` : ''}
              {e.track_id ? ` · Track: ${e.track_id}` : ''}
            </small>
          </div>
          <span className={`severity-text ${e.severity}`}>{e.severity}</span>
        </div>
      ))}
    </div>
  );
}
