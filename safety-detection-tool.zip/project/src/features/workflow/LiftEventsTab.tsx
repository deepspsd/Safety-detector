import { ArrowUpDown } from 'lucide-react';
import type { WorkflowEvent } from '@/lib/db';

export function LiftEventsTab({ events }: { events: WorkflowEvent[] }) {
  return (
    <div className="alerts-table">
      {events.map((e) => (
        <div className="alert-card" key={e.id}>
          <div className={`severity-icon ${e.severity}`}><ArrowUpDown size={15} /></div>
          <div className="alert-card-body">
            <strong>{e.message}</strong>
            <small>
              {e.camera_name} · {e.created_at}
              {e.duration ? ` · ${e.duration}s` : ''}
              {e.floor_from ? ` · ${e.floor_from} → ${e.floor_to}` : ''}
            </small>
          </div>
          <span className={`severity-text ${e.severity}`}>{e.severity}</span>
        </div>
      ))}
    </div>
  );
}
