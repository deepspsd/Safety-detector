import { useState } from 'react';
import { DollarSign, Package, ArrowUpDown, Box, Loader2 } from 'lucide-react';
import { useWorkflowEvents } from '@/lib/hooks';

import { CashEventsTab } from './CashEventsTab';
import { StockEventsTab } from './StockEventsTab';
import { LiftEventsTab } from './LiftEventsTab';
import { PackingEventsTab } from './PackingEventsTab';

type Tab = 'cash' | 'stock' | 'lift' | 'packing';

const tabConfig: { key: Tab; label: string; icon: typeof DollarSign; rule: string }[] = [
  { key: 'cash', label: 'Cash', icon: DollarSign, rule: 'Monitor if cash goes to cashbox — employees should not pocket cash' },
  { key: 'stock', label: 'Stock', icon: Package, rule: 'Items should not be kept openly — monitor inward/outward goods' },
  { key: 'lift', label: 'Lift', icon: ArrowUpDown, rule: 'Lift monitoring for all 3 floors' },
  { key: 'packing', label: 'Packing', icon: Box, rule: 'For packing section, employee can be idle in position but hands should be moving' },
];

export function WorkflowPage() {
  const { events, loading } = useWorkflowEvents();
  const [tab, setTab] = useState<Tab>('cash');
  const cfg = tabConfig.find((c) => c.key === tab)!;
  const tabEvents = events.filter((e) => e.event_type === tab);

  const counts = {
    cash: events.filter((e) => e.event_type === 'cash').length,
    stock: events.filter((e) => e.event_type === 'stock').length,
    lift: events.filter((e) => e.event_type === 'lift').length,
    packing: events.filter((e) => e.event_type === 'packing').length,
  };

  return (
    <div className="workflow-page">
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon orange"><DollarSign size={19} /></div>
          <div className="stat-label">Cash events</div>
          <strong className="stat-value">{counts.cash}</strong>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue"><Package size={19} /></div>
          <div className="stat-label">Stock events</div>
          <strong className="stat-value">{counts.stock}</strong>
        </div>
        <div className="stat-card">
          <div className="stat-icon green"><ArrowUpDown size={19} /></div>
          <div className="stat-label">Lift events</div>
          <strong className="stat-value">{counts.lift}</strong>
        </div>
        <div className="stat-card">
          <div className="stat-icon yellow"><Box size={19} /></div>
          <div className="stat-label">Packing events</div>
          <strong className="stat-value">{counts.packing}</strong>
        </div>
      </div>
      <div className="settings-tabs">
        {tabConfig.map((c) => (
          <button 
            key={c.key} 
            className={`tab-item ${tab === c.key ? 'active' : ''}`} 
            onClick={() => setTab(c.key)}
          >
            <c.icon size={15} /> {c.label}
          </button>
        ))}
      </div>
      <div className="panel">
        <div className="panel-header">
          <div>
            <h2>{cfg.label} monitoring</h2>
            <p>{cfg.rule}</p>
          </div>
        </div>
        {loading ? (
          <div className="loading-row"><Loader2 size={18} className="spin" /> Loading...</div>
        ) : tabEvents.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon"><cfg.icon size={28} /></div>
            <h3>No {cfg.label.toLowerCase()} events</h3>
            <p>No events recorded today.</p>
          </div>
        ) : (
          <>
            {tab === 'cash' && <CashEventsTab events={tabEvents} />}
            {tab === 'stock' && <StockEventsTab events={tabEvents} />}
            {tab === 'lift' && <LiftEventsTab events={tabEvents} />}
            {tab === 'packing' && <PackingEventsTab events={tabEvents} />}
          </>
        )}
      </div>
    </div>
  );
}
