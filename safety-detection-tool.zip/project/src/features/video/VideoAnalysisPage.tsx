import { useState, useRef } from 'react';
import { useVideoJobs } from '@/lib/hooks';
import { useToast } from '@/providers/ToastProvider';
import { uploadVideo, getVideoStatus } from '@/api/video.api';

import { VideoUploadPanel } from './VideoUploadPanel';
import { ActiveJobView } from './ActiveJobView';
import { PreviousJobsList } from './PreviousJobsList';
import { LiveVideoStream } from './LiveVideoStream';
import { Video, MonitorPlay, Upload } from 'lucide-react';

export function VideoAnalysisPage() {
  const { showToast } = useToast();
  const { jobs, loading, refresh } = useVideoJobs();
  const [mode, setMode] = useState<'webcam' | 'rtsp' | 'upload'>('webcam');
  const [rtspUrl, setRtspUrl] = useState('');
  
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeJob, setActiveJob] = useState<any>(null);
  const pollRef = useRef<any>(null);

  const handleUpload = async (file: File) => {
    setUploading(true); 
    setProgress(0);
    setActiveJob(null);
    
    try {
      const jobId = await uploadVideo(file, (e) => {
        if (e.total) {
          setProgress((e.loaded / e.total) * 20); // First 20% for file upload
        }
      });
      
      showToast('Video uploaded. AI scanning started...', 'info');

      pollRef.current = setInterval(async () => {
        const statusData = await getVideoStatus(jobId);
        if (statusData) {
          if (statusData.status === 'processing') {
            setProgress(20 + (statusData.progress * 0.8)); // Remaining 80% for AI processing
          }
          if (statusData.status === 'complete' || statusData.status === 'error') {
            clearInterval(pollRef.current);
            setUploading(false);
            
            if (statusData.status === 'complete') {
              setActiveJob({ 
                id: jobId, 
                filename: file.name, 
                status: 'completed', 
                total_violations: statusData.total_violations, 
                video_duration_sec: statusData.video_duration_sec,
                alerts: statusData.alerts,
                ppe_summary: statusData.ppe_summary
              });
              showToast(`Video processed. Found ${statusData.total_alerts || 0} alerts.`, 'success');
              refresh();
            } else {
              showToast('Error processing video', 'error');
            }
          }
        }
      }, 1500);
      
    } catch (err: any) {
      setUploading(false);
      showToast('Upload failed: ' + (err.response?.data?.detail || err.message), 'error');
    }
  };

  return (
    <div className="video-page">
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', background: 'var(--bg-card)', padding: '10px', borderRadius: '12px', border: '1px solid var(--border)', width: 'fit-content' }}>
        <button 
          className={`btn ${mode === 'webcam' ? 'btn-primary' : 'btn-ghost'}`} 
          onClick={() => setMode('webcam')}
          style={{ display: 'flex', gap: '8px', alignItems: 'center' }}
        >
          <Video size={18} /> Webcam
        </button>
        <button 
          className={`btn ${mode === 'rtsp' ? 'btn-primary' : 'btn-ghost'}`} 
          onClick={() => setMode('rtsp')}
          style={{ display: 'flex', gap: '8px', alignItems: 'center' }}
        >
          <MonitorPlay size={18} /> CCTV / RTSP
        </button>
        <button 
          className={`btn ${mode === 'upload' ? 'btn-primary' : 'btn-ghost'}`} 
          onClick={() => setMode('upload')}
          style={{ display: 'flex', gap: '8px', alignItems: 'center' }}
        >
          <Upload size={18} /> Upload Video
        </button>
      </div>

      {mode === 'rtsp' && (
        <div style={{ marginBottom: '20px', background: 'var(--bg-card)', padding: '15px', borderRadius: '12px', border: '1px solid var(--border)' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', color: 'var(--text-muted)' }}>IP Camera Stream URL (RTSP/HTTP)</label>
          <input 
            type="text" 
            className="input-field" 
            placeholder="rtsp://admin:password@192.168.1.100:554/stream" 
            value={rtspUrl}
            onChange={(e) => setRtspUrl(e.target.value)}
            style={{ width: '100%', maxWidth: '500px' }}
          />
        </div>
      )}

      {mode !== 'upload' ? (
        <LiveVideoStream mode={mode} rtspUrl={rtspUrl} />
      ) : (
        <>
          <VideoUploadPanel 
            uploading={uploading} 
            progress={progress} 
            onUpload={handleUpload} 
          />
          
          {activeJob && (
            <ActiveJobView 
              job={activeJob} 
              mockPpeData={
                activeJob.ppe_summary 
                  ? Object.entries(activeJob.ppe_summary).map(([name, count]) => ({ name, count: count as number }))
                  : []
              } 
            />
          )}
          
          <PreviousJobsList 
            jobs={jobs} 
            loading={loading} 
          />
        </>
      )}
    </div>
  );
}
