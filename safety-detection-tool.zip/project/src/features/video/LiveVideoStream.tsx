import { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '@/providers/AuthProvider';
import { useToast } from '@/providers/ToastProvider';
import { getWsURL, getCctvWsURL } from '@/api/client';
import { AlertTriangle, CheckCircle, VideoOff } from 'lucide-react';

const FRAME_INTERVAL = 80;

export function LiveVideoStream({
  mode,
  rtspUrl,
}: {
  mode: 'webcam' | 'rtsp';
  rtspUrl: string;
}) {
  const { user } = useAuth();
  const { showToast } = useToast();
  
  const [streaming, setStreaming] = useState(false);
  const [connected, setConnected] = useState(false);
  const [currentAlert, setCurrentAlert] = useState<{message: string, severity: string} | null>(null);
  const [detectionInfo, setDetectionInfo] = useState<any>(null);
  const [camFps, setCamFps] = useState(0);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const captureRef = useRef<HTMLCanvasElement>(null);
  const cctvImgRef = useRef<HTMLImageElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<any>(null);
  
  const token = localStorage.getItem('token');

  // Basic filters mapped for Bakery Worker, matching old frontend
  const activeFilters = ['NO-Bakery-Head-Cap', 'Bangles', 'NO-Mask'];
  const activeFiltersRef = useRef(activeFilters);
  const noPhoneZoneRef = useRef(true);
  const enableFaceRef = useRef(true);

  const connectWs = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    const ws = new WebSocket(getWsURL());
    wsRef.current = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({
        token,
        filters: activeFiltersRef.current,
        no_phone_zone: noPhoneZoneRef.current,
      }));
    };

    ws.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.status === 'connected') { setConnected(true); return; }
      if (data.status === 'filters_updated') return;
      if (data.error) return;
      if (data.annotated_frame === undefined && data.is_compliant === undefined) return;

      setDetectionInfo({
        isCompliant: data.is_compliant,
        violationsCount: data.violations_count ?? 0,
        personsCount: data.persons_count ?? 0,
      });

      if (data.annotated_frame && canvasRef.current) {
        const img = new Image();
        img.onload = () => {
          const cv = canvasRef.current;
          if (!cv) return;
          if (img.width > 0 && cv.width !== img.width) {
            cv.width = img.width;
            cv.height = img.height;
          }
          const ctx = cv.getContext('2d');
          if (ctx) ctx.drawImage(img, 0, 0, cv.width, cv.height);
        };
        img.src = data.annotated_frame;
      }

      if (!data.is_compliant && data.alert_message) {
        setCurrentAlert({ message: data.alert_message, severity: data.severity });
        if (data.alert_saved) {
          showToast('Alert Saved!', 'error');
        }
      } else {
        setCurrentAlert(null);
      }
    };
    ws.onclose = () => setConnected(false);
    ws.onerror = () => setConnected(false);
  }, [token, showToast]);

  const startWebcam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      connectWs();
      setStreaming(true);

      intervalRef.current = setInterval(() => {
        if (!videoRef.current || !captureRef.current || !wsRef.current) return;
        if (wsRef.current.readyState !== WebSocket.OPEN) return;
        const vw = videoRef.current.videoWidth || 640;
        const vh = videoRef.current.videoHeight || 480;
        captureRef.current.width = vw;
        captureRef.current.height = vh;
        const ctx = captureRef.current.getContext('2d');
        if (ctx) {
          ctx.drawImage(videoRef.current, 0, 0, vw, vh);
          const b64 = captureRef.current.toDataURL('image/jpeg', 0.65);
          wsRef.current.send(JSON.stringify({
            frame: b64,
            filters: activeFiltersRef.current,
            no_phone_zone: noPhoneZoneRef.current,
          }));
        }
      }, FRAME_INTERVAL);
    } catch (err: any) {
      showToast('Camera error: ' + (err.message || ''), 'error');
    }
  };

  const startCctv = useCallback(() => {
    const url = rtspUrl.trim();
    if (!url) {
      showToast('Enter an RTSP/CCTV URL first', 'error');
      return;
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    setCamFps(0);
    const ws = new WebSocket(getCctvWsURL());
    wsRef.current = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({
        token,
        camera_url: rtspUrl.trim(),
        filters: activeFiltersRef.current,
        no_phone_zone: noPhoneZoneRef.current,
        enable_face: enableFaceRef.current,
      }));
    };

    ws.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.status === 'connected') { setConnected(true); setStreaming(true); return; }
      if (data.error) {
        showToast(data.error, 'error');
        ws.close(); setStreaming(false); setConnected(false);
        return;
      }
      if (data.annotated_frame === undefined && data.is_compliant === undefined) return;

      if (data.cam_fps !== undefined) setCamFps(data.cam_fps);

      setDetectionInfo({
        isCompliant: data.is_compliant,
        violationsCount: data.violations_count ?? 0,
        personsCount: data.persons_count ?? 0,
      });

      if (data.annotated_frame && canvasRef.current) {
        const img = new Image();
        img.onload = () => {
          const cv = canvasRef.current;
          if (!cv) return;
          if (img.width > 0 && cv.width !== img.width) { cv.width = img.width; cv.height = img.height; }
          const ctx = cv.getContext('2d');
          if (ctx) ctx.drawImage(img, 0, 0, cv.width, cv.height);
        };
        img.src = data.annotated_frame;
      }

      if (!data.is_compliant && data.alert_message) {
        setCurrentAlert({ message: data.alert_message, severity: data.severity });
        if (data.alert_saved || data.face_alert_saved) {
          showToast('Alert Saved!', 'error');
        }
      } else {
        setCurrentAlert(null);
      }
    };

    ws.onclose = () => { setConnected(false); setStreaming(false); setCamFps(0); };
    ws.onerror = () => { setConnected(false); setStreaming(false); };

    intervalRef.current = setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          filters: activeFiltersRef.current,
          no_phone_zone: noPhoneZoneRef.current,
          enable_face: enableFaceRef.current,
        }));
      }
    }, 2000);
  }, [token, showToast, rtspUrl]);

  const stopStream = useCallback(() => {
    clearInterval(intervalRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
    wsRef.current?.close();
    setStreaming(false);
    setConnected(false);
    setCurrentAlert(null);
    setDetectionInfo(null);
    setCamFps(0);
    if (canvasRef.current) {
      canvasRef.current.getContext('2d')?.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    }
  }, []);

  useEffect(() => () => stopStream(), [stopStream]);

  return (
    <div style={{ background: 'var(--bg-card)', borderRadius: '12px', padding: '20px', border: '1px solid var(--border)', marginTop: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px', alignItems: 'center' }}>
        <div>
          <h3 style={{ margin: 0, color: 'var(--text-primary)' }}>{mode === 'webcam' ? 'Webcam Feed' : 'CCTV / RTSP Feed'}</h3>
          <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-muted)' }}>Real-time violation detection streaming directly from backend</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          {streaming ? (
            <button className="btn btn-danger" onClick={stopStream}>Stop Stream</button>
          ) : (
            <button className="btn btn-primary" onClick={mode === 'webcam' ? startWebcam : startCctv}>
              Start {mode === 'webcam' ? 'Webcam' : 'Stream'}
            </button>
          )}
        </div>
      </div>

      <div style={{ position: 'relative', width: '100%', height: '450px', background: '#000', borderRadius: '8px', overflow: 'hidden' }}>
        <canvas ref={captureRef} style={{ display: 'none' }} />

        {mode === 'rtsp' && streaming && (
          <img
            ref={cctvImgRef}
            src={rtspUrl}
            alt="CCTV feed"
            style={{
              display: 'block',
              position: 'absolute', top: 0, left: 0,
              width: '100%', height: '100%', objectFit: 'cover',
            }}
          />
        )}

        <video ref={videoRef} muted playsInline
          style={{
            display: (streaming && mode === 'webcam') ? 'block' : 'none',
            position: 'absolute', top: 0, left: 0,
            width: '100%', height: '100%', objectFit: 'cover',
          }}
        />

        <canvas ref={canvasRef}
          style={{
            display: streaming ? 'block' : 'none',
            position: 'absolute', top: 0, left: 0,
            width: '100%', height: '100%',
          }}
        />

        {!streaming && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--text-muted)' }}>
            <VideoOff size={40} style={{ opacity: 0.3, marginBottom: '10px' }} />
            <div>No feed active</div>
          </div>
        )}

        {streaming && currentAlert && (
          <div style={{ position: 'absolute', bottom: '20px', left: '20px', background: 'rgba(220,38,38,0.9)', color: '#fff', padding: '10px 16px', borderRadius: '8px', display: 'flex', alignItems: 'center', gap: '10px', fontWeight: 'bold' }}>
            <AlertTriangle size={20} />
            {currentAlert.message}
          </div>
        )}

        {streaming && !currentAlert && detectionInfo && (
          <div style={{ position: 'absolute', bottom: '20px', left: '20px', background: 'rgba(16,185,129,0.9)', color: '#fff', padding: '8px 14px', borderRadius: '8px', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 'bold' }}>
            <CheckCircle size={16} />
            All Compliant
          </div>
        )}

        {streaming && detectionInfo && detectionInfo.violationsCount > 0 && (
          <div style={{
            position: 'absolute', top: '12px', left: '12px',
            background: 'rgba(220,38,38,0.85)', color: '#fff',
            padding: '4px 12px', borderRadius: '99px',
            fontSize: '0.85rem', fontWeight: 700,
          }}>
            {detectionInfo.violationsCount}/{detectionInfo.personsCount} violating
          </div>
        )}

        {streaming && mode === 'rtsp' && camFps > 0 && (
          <div style={{
            position: 'absolute', top: '12px', right: '12px',
            background: 'rgba(99,102,241,0.75)', padding: '4px 10px',
            borderRadius: '99px', fontSize: '0.85rem', color: '#fff', fontWeight: 700,
          }}>
            {camFps} fps
          </div>
        )}
      </div>
    </div>
  );
}
