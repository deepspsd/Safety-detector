import { useRef } from 'react';
import { FileVideo } from 'lucide-react';

interface VideoUploadPanelProps {
  uploading: boolean;
  progress: number;
  onUpload: (file: File) => void;
}

export function VideoUploadPanel({ uploading, progress, onUpload }: VideoUploadPanelProps) {
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="panel upload-panel">
      <div className="panel-header">
        <div>
          <h2>Upload video for analysis</h2>
          <p>Upload a recorded video for offline AI safety analysis</p>
        </div>
      </div>
      <div className="upload-zone" onClick={() => fileRef.current?.click()}>
        <FileVideo size={32} />
        <strong>Drop a video here or click to browse</strong>
        <small>Supports MP4, AVI, MOV, MKV, WebM</small>
        <input 
          ref={fileRef} 
          type="file" 
          accept="video/*" 
          style={{ display: 'none' }} 
          onChange={(e) => { 
            if (e.target.files?.[0]) onUpload(e.target.files[0]); 
          }} 
        />
      </div>
      {uploading && (
        <div className="progress-wrap">
          <div className="progress-bar">
            <span style={{ width: `${progress}%` }} />
          </div>
          <span className="progress-label">{Math.floor(progress)}% — Analyzing frames...</span>
        </div>
      )}
    </div>
  );
}
