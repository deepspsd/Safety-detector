import { Play, Download } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { useToast } from '@/providers/ToastProvider';

interface ActiveJobViewProps {
  job: any;
  mockPpeData: any[];
}

export function ActiveJobView({ job, mockPpeData }: ActiveJobViewProps) {
  const { showToast } = useToast();

  return (
    <>
      <div className="panel">
        <div className="panel-header">
          <div>
            <h2>Annotated video</h2>
            <p>{job.filename} · {job.total_violations} violations detected</p>
          </div>
          <button className="primary-button"><Download size={15} /> Download</button>
        </div>
        <div className="video-player-area">
          <Play size={48} fill="currentColor" />
        </div>
      </div>
      <div className="dashboard-grid">
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>PPE violation summary</h2>
              <p>Breakdown by violation type</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={mockPpeData} layout="vertical" margin={{ left: 20 }}>
              <XAxis type="number" />
              <YAxis type="category" dataKey="name" width={80} />
              <Tooltip />
              <Bar dataKey="count" fill="#72c99e" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Violation timeline</h2>
              <p>Click a timestamp to seek</p>
            </div>
          </div>
          <div className="violation-timeline">
            {[10, 25, 42, 58, 73, 89, 95, 110, 135, 160].map((t) => (
              <button 
                key={t} 
                className="timeline-marker" 
                style={{ left: `${(t / 180) * 100}%` }} 
                onClick={() => showToast(`Seeking to ${t}s`, 'info')} 
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
