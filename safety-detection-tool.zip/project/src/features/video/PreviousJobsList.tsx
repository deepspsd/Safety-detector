import { Loader2, FileVideo } from 'lucide-react';
import type { VideoJob } from '@/lib/db';

interface PreviousJobsListProps {
  jobs: VideoJob[];
  loading: boolean;
}

export function PreviousJobsList({ jobs, loading }: PreviousJobsListProps) {
  return (
    <div className="panel">
      <div className="panel-header">
        <div>
          <h2>Previous uploads</h2>
          <p>Recent video analysis jobs</p>
        </div>
      </div>
      {loading ? (
        <div className="loading-row"><Loader2 size={18} className="spin" /> Loading...</div>
      ) : jobs.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><FileVideo size={28} /></div>
          <h3>No uploads yet</h3>
          <p>Upload a video to get started.</p>
        </div>
      ) : (
        <div className="alerts-table">
          {jobs.map((job) => (
            <div className="alert-card" key={job.id}>
              <div className="alert-card-body">
                <strong>{job.filename}</strong>
                <small>{job.status} · {job.created_at}</small>
              </div>
              <span className={`status-badge ${job.status === 'completed' ? 'confirmed' : 'pending_review'}`}>
                {job.status}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
