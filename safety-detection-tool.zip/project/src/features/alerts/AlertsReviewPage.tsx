// Canonical feature-module entry point for the pending-review queue.
export { ReviewQueuePage as AlertsReviewPage } from './ReviewQueuePage';
