import { Filter, Search, Trash2 } from 'lucide-react';

interface AlertFiltersBarProps {
  filterStatus: string; setFilterStatus: (val: string) => void;
  filterSeverity: string; setFilterSeverity: (val: string) => void;
  filterFloor: string; setFilterFloor: (val: string) => void;
  searchText: string; setSearchText: (val: string) => void;
  onClearAll: () => void;
}

export function AlertFiltersBar({
  filterStatus, setFilterStatus, filterSeverity, setFilterSeverity,
  filterFloor, setFilterFloor, searchText, setSearchText, onClearAll
}: AlertFiltersBarProps) {
  return (
    <div className="alerts-toolbar">
      <div className="filter-group">
        <div className="filter-select">
          <Filter size={14} />
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
            <option value="all">All status</option>
            <option value="pending_review">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="dismissed">Dismissed</option>
          </select>
        </div>
        <div className="filter-select">
          <select value={filterSeverity} onChange={(e) => setFilterSeverity(e.target.value)}>
            <option value="all">All severity</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
        <div className="filter-select">
          <select value={filterFloor} onChange={(e) => setFilterFloor(e.target.value)}>
            <option value="all">All floors</option>
            <option value="ground">Ground</option>
            <option value="first">First</option>
            <option value="second">Second</option>
            <option value="shop">Shop</option>
          </select>
        </div>
        <div className="filter-select">
          <Search size={14} />
          <input value={searchText} onChange={(e) => setSearchText(e.target.value)} placeholder="Search alerts..." />
        </div>
      </div>
      <button className="danger-button" onClick={onClearAll}>
        <Trash2 size={15} /> Clear all
      </button>
    </div>
  );
}
