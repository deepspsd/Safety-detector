import { AlertTriangle, Clock3, Zap, Trash2 } from 'lucide-react';
import { deleteAlert } from '@/lib/hooks';
import { useToast } from '@/providers/ToastProvider';
import type { Alert } from '@/lib/db';

function formatTime(dateStr: string): string {
  const d = new Date(dateStr + (dateStr.includes('Z') ? '' : 'Z'));
  if (isNaN(d.getTime())) return dateStr;
  const now = new Date();
  const diff = (now.getTime() - d.getTime()) / 60000;
  if (diff < 1) return 'Just now';
  if (diff < 60) return `${Math.floor(diff)}m ago`;
  if (diff < 1440) return `${Math.floor(diff / 60)}h ago`;
  return d.toLocaleDateString();
}

export function AlertCard({ alert, onClick, onRefresh }: { alert: Alert; onClick: () => void; onRefresh: () => void }) {
  const { showToast } = useToast();

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    await deleteAlert(alert.id);
    onRefresh();
    showToast('Alert deleted', 'success');
  };

  return (
    <div className="alert-card" onClick={onClick}>
      <div className={`severity-icon ${alert.severity}`}>
        {alert.severity === 'critical' ? (
          <AlertTriangle size={15} />
        ) : alert.severity === 'high' ? (
          <Zap size={15} />
        ) : (
          <Clock3 size={15} />
        )}
      </div>
      <div className="alert-card-body">
        <strong>{alert.title}</strong>
        <small>{alert.camera_name} · {alert.floor} · {formatTime(alert.detected_at)}</small>
      </div>
      <span className={`severity-text ${alert.severity}`}>{alert.severity}</span>
      <span className={`status-badge ${alert.status}`}>{alert.status.replace('_', ' ')}</span>
      <span className="confidence-text">{alert.confidence}%</span>
      <button className="row-delete" onClick={handleDelete}>
        <Trash2 size={14} />
      </button>
    </div>
  );
}
