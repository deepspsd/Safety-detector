import { useState, useEffect, useCallback } from 'react';
import { Check, X, Loader2 } from 'lucide-react';
import type { Alert } from '@/lib/db';
import { getPendingAlerts, confirmAlert, dismissAlert } from '@/api/alerts.api';
import { useToast } from '@/providers/ToastProvider';
import { EmptyState } from '@/components/EmptyState';
import { AlertModal } from '@/components/AlertModal';

export function ReviewQueuePage() {
  const { showToast } = useToast();
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [actioning, setActioning] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const pending = await getPendingAlerts();
    setAlerts(pending);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const pending = alerts;


  const handleConfirm = async (alert: Alert) => {
    setActioning(alert.id);
    await confirmAlert(alert.id);
    showToast('Alert confirmed', 'success');
    refresh(); setActioning(null);
  };

  const handleDismiss = async (id: string) => {
    setActioning(id);
    await dismissAlert(id);
    showToast('Alert dismissed', 'info');
    refresh(); setActioning(null);
  };

  return (
    <div className="review-page">
      <div className="review-header">
        <h2>{pending.length} alerts pending review</h2>
        <p>Review low-confidence AI detections and confirm or dismiss them</p>
      </div>
      {pending.length === 0 ? (
        <EmptyState icon={Check} title="No alerts pending review" message="All clear! Every detection has been reviewed." />
      ) : (
        <div className="review-grid">
          {pending.map((alert) => (
            <div className="review-card" key={alert.id}>
              <div className="review-thumb" onClick={() => setSelectedAlert(alert)}>
                <img src="https://images.pexels.com/photos/5953714/pexels-photo-5953714.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Alert snapshot" />
                <span className={`review-severity ${alert.severity}`}>{alert.severity.toUpperCase()}</span>
              </div>
              <div className="review-body">
                <strong>{alert.title}</strong>
                <small>{alert.camera_name} · {alert.floor} · {alert.detected_at}</small>
                <div className="confidence-bar-wrap"><div className="confidence-bar"><span style={{ width: `${alert.confidence}%` }} /></div><span className="confidence-label">{alert.confidence}% confidence</span></div>
              </div>
              <div className="review-actions">
                <button className="primary-button" onClick={() => handleConfirm(alert)} disabled={actioning === alert.id}>{actioning === alert.id ? <Loader2 size={15} className="spin" /> : <Check size={15} />} Confirm</button>
                <button className="danger-button" onClick={() => handleDismiss(alert.id)} disabled={actioning === alert.id}><X size={15} /> Dismiss</button>
              </div>
            </div>
          ))}
        </div>
      )}
      {selectedAlert && <AlertModal alert={selectedAlert} onClose={() => setSelectedAlert(null)} />}
    </div>
  );
}
