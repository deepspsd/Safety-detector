import { useState } from 'react';
import { Bell, Loader2 } from 'lucide-react';
import { useAlerts, deleteAllAlerts } from '@/lib/hooks';
import { useToast } from '@/providers/ToastProvider';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { EmptyState } from '@/components/EmptyState';
import { AlertModal } from '@/components/AlertModal';
import type { Alert } from '@/lib/db';
import { AlertFiltersBar } from './AlertFiltersBar';
import { AlertCard } from './AlertCard';

export function AlertsPage() {
  const { showToast } = useToast();
  const { alerts, loading, refresh } = useAlerts();
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterSeverity, setFilterSeverity] = useState('all');
  const [filterFloor, setFilterFloor] = useState('all');
  const [searchText, setSearchText] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);

  const filtered = alerts.filter((a) =>
    (filterStatus === 'all' || a.status === filterStatus) &&
    (filterSeverity === 'all' || a.severity === filterSeverity) &&
    (filterFloor === 'all' || a.floor === filterFloor) &&
    (searchText === '' || a.title.toLowerCase().includes(searchText.toLowerCase()) || a.camera_name.toLowerCase().includes(searchText.toLowerCase()))
  );

  return (
    <div className="alerts-page">
      <AlertFiltersBar
        filterStatus={filterStatus} setFilterStatus={setFilterStatus}
        filterSeverity={filterSeverity} setFilterSeverity={setFilterSeverity}
        filterFloor={filterFloor} setFilterFloor={setFilterFloor}
        searchText={searchText} setSearchText={setSearchText}
        onClearAll={() => setShowClearConfirm(true)}
      />
      <div className="alerts-table-wrap">
        {loading ? (
          <div className="loading-row"><Loader2 size={18} className="spin" /> Loading...</div>
        ) : filtered.length === 0 ? (
          <EmptyState icon={Bell} title="No alerts found" message="No alerts match your current filters." />
        ) : (
          <div className="alerts-table">
            {filtered.map((alert) => (
              <AlertCard
                key={alert.id}
                alert={alert}
                onClick={() => setSelectedAlert(alert)}
                onRefresh={refresh}
              />
            ))}
          </div>
        )}
      </div>
      {showClearConfirm && (
        <ConfirmDialog
          title="Clear all alerts?"
          message="This will permanently delete all alerts."
          onConfirm={async () => {
            await deleteAllAlerts();
            refresh();
            setShowClearConfirm(false);
            showToast('All alerts cleared', 'success');
          }}
          onCancel={() => setShowClearConfirm(false)}
        />
      )}
      {selectedAlert && <AlertModal alert={selectedAlert} onClose={() => setSelectedAlert(null)} />}
    </div>
  );
}
