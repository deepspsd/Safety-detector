import { useRef } from 'react';
import { Upload, Loader2 } from 'lucide-react';

interface DocumentScanUploadProps {
  direction: 'inward' | 'outward';
  setDirection: (val: 'inward' | 'outward') => void;
  uploadText: string;
  setUploadText: (val: string) => void;
  uploading: boolean;
  onUpload: () => void;
}

export function DocumentScanUpload({
  direction, setDirection, uploadText, setUploadText, uploading, onUpload
}: DocumentScanUploadProps) {
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="panel upload-panel">
      <div className="panel-header">
        <div>
          <h2>Scan new document</h2>
          <p>Upload an invoice or order form for OCR processing</p>
        </div>
      </div>
      <div className="upload-zone" onClick={() => fileRef.current?.click()}>
        <Upload size={28} />
        <strong>Drop a file here or click to browse</strong>
        <small>Supports JPG, PNG, PDF</small>
        <input 
          ref={fileRef} 
          type="file" 
          accept="image/*,application/pdf" 
          style={{ display: 'none' }} 
          onChange={(e) => { 
            if (e.target.files?.[0]) {
              setUploadText(`Scanned: ${e.target.files[0].name}`); 
            }
          }} 
        />
      </div>
      <div className="upload-controls">
        <div className="filter-select">
          <select value={direction} onChange={(e) => setDirection(e.target.value as any)}>
            <option value="inward">Inward</option>
            <option value="outward">Outward</option>
          </select>
        </div>
        <input 
          className="ocr-input" 
          value={uploadText} 
          onChange={(e) => setUploadText(e.target.value)} 
          placeholder="OCR text will appear here..." 
        />
        <button className="primary-button" onClick={onUpload} disabled={uploading}>
          {uploading ? <Loader2 size={15} className="spin" /> : <Upload size={15} />} Scan
        </button>
      </div>
    </div>
  );
}
