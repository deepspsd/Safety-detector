import { X } from 'lucide-react';

interface DocumentDetailModalProps {
  selectedDoc: any;
  onClose: () => void;
}

export function DocumentDetailModal({ selectedDoc, onClose }: DocumentDetailModalProps) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="form-modal" onClick={(e) => e.stopPropagation()}>
        <div className="form-modal-header">
          <h2>Document detail</h2>
          <button onClick={onClose} className="modal-close"><X size={18} /></button>
        </div>
        <div className="form-modal-body" style={{ display: 'block' }}>
          <div className="detail-grid">
            <div><small>DIRECTION</small><strong>{selectedDoc.direction}</strong></div>
            <div><small>STATUS</small><strong>{selectedDoc.approved ? 'Approved' : selectedDoc.rejected ? 'Rejected' : 'Pending'}</strong></div>
            <div><small>CAMERA</small><strong>{selectedDoc.camera_name}</strong></div>
            <div><small>DATE</small><strong>{selectedDoc.created_at}</strong></div>
          </div>
          <pre className="ocr-full-text">{selectedDoc.ocr_text}</pre>
        </div>
      </div>
    </div>
  );
}
