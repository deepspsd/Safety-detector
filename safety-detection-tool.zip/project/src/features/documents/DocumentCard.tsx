import { Check, X, Trash2 } from 'lucide-react';

interface DocumentCardProps {
  doc: any;
  onClick: () => void;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  onDelete: (id: string) => void;
}

export function DocumentCard({ doc, onClick, onApprove, onReject, onDelete }: DocumentCardProps) {
  return (
    <div className="alert-card" onClick={onClick}>
      <span className={`direction-badge ${doc.direction}`}>{doc.direction}</span>
      <div className="alert-card-body">
        <strong>{doc.ocr_text.split('\n')[0]}</strong>
        <small>{doc.ocr_text.slice(0, 80)}...</small>
      </div>
      <span className={`status-badge ${doc.approved ? 'confirmed' : doc.rejected ? 'dismissed' : 'pending_review'}`}>
        {doc.approved ? 'Approved' : doc.rejected ? 'Rejected' : 'Pending'}
      </span>
      <div className="doc-actions">
        <button className="card-action" onClick={(e) => { e.stopPropagation(); onApprove(doc.id); }}>
          <Check size={14} />
        </button>
        <button className="card-action" onClick={(e) => { e.stopPropagation(); onReject(doc.id); }}>
          <X size={14} />
        </button>
        <button className="card-action danger" onClick={(e) => { e.stopPropagation(); onDelete(doc.id); }}>
          <Trash2 size={14} />
        </button>
      </div>
    </div>
  );
}
