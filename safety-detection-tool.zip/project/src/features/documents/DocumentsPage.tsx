import { useState } from 'react';
import { FileText, Check, Loader2 } from 'lucide-react';
import { useDocuments, addDocument, approveDocument, rejectDocument, deleteDocument } from '@/lib/hooks';
import { useToast } from '@/providers/ToastProvider';
import { DocumentScanUpload } from './DocumentScanUpload';
import { DocumentCard } from './DocumentCard';
import { DocumentDetailModal } from './DocumentDetailModal';

export function DocumentsPage() {
  const { showToast } = useToast();
  const { documents, loading, refresh } = useDocuments();
  const [tab, setTab] = useState<'all' | 'inward' | 'outward'>('all');
  const [direction, setDirection] = useState<'inward' | 'outward'>('inward');
  const [uploadText, setUploadText] = useState('');
  const [uploading, setUploading] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<any>(null);

  const filtered = documents.filter((d) => tab === 'all' || d.direction === tab);

  const handleUpload = async () => {
    setUploading(true);
    await addDocument({ direction, ocr_text: uploadText || 'OCR scan pending...', camera_name: 'Document Scanner' });
    refresh(); setUploading(false); setUploadText('');
    showToast('Document scanned and added', 'success');
  };

  const handleApprove = async (id: string) => { await approveDocument(id); refresh(); showToast('Document approved', 'success'); };
  const handleReject = async (id: string) => { await rejectDocument(id); refresh(); showToast('Document rejected', 'info'); };
  const handleDelete = async (id: string) => { await deleteDocument(id); refresh(); showToast('Document deleted', 'success'); };

  return (
    <div className="documents-page">
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon blue"><FileText size={19} /></div>
          <div className="stat-label">Today's scans</div>
          <strong className="stat-value">{documents.length}</strong>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue"><FileText size={19} /></div>
          <div className="stat-label">Inward</div>
          <strong className="stat-value">{documents.filter((d) => d.direction === 'inward').length}</strong>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange"><FileText size={19} /></div>
          <div className="stat-label">Outward</div>
          <strong className="stat-value">{documents.filter((d) => d.direction === 'outward').length}</strong>
        </div>
        <div className="stat-card">
          <div className="stat-icon green"><Check size={19} /></div>
          <div className="stat-label">Approved</div>
          <strong className="stat-value">{documents.filter((d) => d.approved).length}</strong>
        </div>
      </div>
      
      <DocumentScanUpload 
        direction={direction}
        setDirection={setDirection}
        uploadText={uploadText}
        setUploadText={setUploadText}
        uploading={uploading}
        onUpload={handleUpload}
      />

      <div className="settings-tabs">
        <button className={`tab-item ${tab === 'all' ? 'active' : ''}`} onClick={() => setTab('all')}>All</button>
        <button className={`tab-item ${tab === 'inward' ? 'active' : ''}`} onClick={() => setTab('inward')}>Inward</button>
        <button className={`tab-item ${tab === 'outward' ? 'active' : ''}`} onClick={() => setTab('outward')}>Outward</button>
      </div>

      <div className="alerts-table-wrap">
        {loading ? (
          <div className="loading-row"><Loader2 size={18} className="spin" /> Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon"><FileText size={28} /></div>
            <h3>No documents</h3>
            <p>Upload a document to get started.</p>
          </div>
        ) : (
          <div className="alerts-table">
            {filtered.map((doc) => (
              <DocumentCard 
                key={doc.id} 
                doc={doc} 
                onClick={() => setSelectedDoc(doc)}
                onApprove={handleApprove}
                onReject={handleReject}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </div>

      {selectedDoc && (
        <DocumentDetailModal selectedDoc={selectedDoc} onClose={() => setSelectedDoc(null)} />
      )}
    </div>
  );
}
