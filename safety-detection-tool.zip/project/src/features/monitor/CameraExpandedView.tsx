import { useState } from 'react';
import { Maximize2, RotateCw, Settings, X } from 'lucide-react';
import { useCameraStream } from '@/hooks/useCameraStream';
import { useToast } from '@/providers/ToastProvider';
import { restartCamera } from '@/api/cameras.api';
import type { Camera } from '@/lib/db';

const bakeryFilters = ['Head cap', 'Uniform', 'Gloves', 'Mask', 'Phone use', 'Face recognition'];

export function CameraExpandedView({ camera, onClose, onZones }: { camera: Camera; onClose: () => void; onZones: () => void }) {
  const { frame, status, sendConfig } = useCameraStream(camera.id);
  const { showToast } = useToast();
  const [enabled, setEnabled] = useState<Record<string, boolean>>({
    'Head cap': true, Uniform: true, Gloves: true, Mask: false, 'Phone use': true, 'Face recognition': true
  });

  const update = (name: string) => {
    const next = { ...enabled, [name]: !enabled[name] };
    setEnabled(next);
    sendConfig({
      filters: Object.entries(next).filter(([, active]) => active).map(([name]) => name),
      no_phone_zone: next['Phone use'],
      enable_face: next['Face recognition']
    });
  };

  return (
    <div className="expanded-view">
      <div className="expanded-feed">
        {frame?.annotated_frame ? (
          <img src={frame.annotated_frame} alt={`${camera.name} live feed`} />
        ) : (
          <div className="camera-unavailable">
            {status === 'connecting' ? 'Connecting to camera…' : 'No live frame available'}
          </div>
        )}
        <div className="tile-overlay" />
        <div className="tile-top">
          <span><i /> {status.toUpperCase()}</span>
          <small>{Math.round(frame?.cam_fps ?? camera.fps ?? 0)} FPS</small>
        </div>
        <button className="expanded-close" onClick={onClose}><X size={18} /></button>
      </div>
      <aside className="expanded-panel">
        <div className="expanded-info">
          <h2>{camera.name}</h2>
          <small>{camera.floor} · {camera.zone_type}</small>
          <p>{frame?.persons_count ?? 0} persons · {frame?.violations_count ?? 0} violations</p>
        </div>
        <div className="filter-section">
          <strong>Detection rules</strong>
          {bakeryFilters.map((name) => (
            <label key={name} className="filter-toggle-row">
              <span>{name}</span>
              <button className={`monitor-toggle ${enabled[name] ? 'enabled' : ''}`} onClick={() => update(name)}>
                <span /> {enabled[name] ? 'On' : 'Off'}
              </button>
            </label>
          ))}
        </div>
        {frame?.alert_message && <div className="auth-error">{frame.alert_message}</div>}
        <div className="expanded-actions">
          <button className="secondary-button" onClick={async () => {
            await restartCamera(camera.id);
            showToast('Camera restart requested', 'info');
          }}>
            <RotateCw size={15} /> Restart stream
          </button>
          <button className="secondary-button" onClick={onZones}>
            <Settings size={15} /> Zones
          </button>
          <button className="secondary-button" onClick={() => document.documentElement.requestFullscreen?.()}>
            <Maximize2 size={15} /> Fullscreen
          </button>
        </div>
      </aside>
    </div>
  );
}
