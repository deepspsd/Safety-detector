import { Check } from 'lucide-react';
import { useCameraStream } from '@/hooks/useCameraStream';
import type { Camera } from '@/lib/db';

export function CameraTile({ camera, onOpen }: { camera: Camera; onOpen: () => void }) {
  const { frame, status } = useCameraStream(camera.id, camera.status === 'online');
  const live = status === 'connected' && Boolean(frame?.annotated_frame);
  
  return (
    <button type="button" className={`monitor-tile ${live ? 'safe' : 'danger'}`} onClick={onOpen}>
      {frame?.annotated_frame ? (
        <img src={frame.annotated_frame} alt={`${camera.name} live feed`} />
      ) : (
        <div className="camera-unavailable">
          {status === 'connecting' ? 'Connecting…' : camera.status === 'offline' ? 'Camera offline' : 'Waiting for live stream'}
        </div>
      )}
      <div className="tile-overlay" />
      <div className="tile-top">
        <span><i /> {live ? 'LIVE' : status.toUpperCase()}</span>
        <small>{Math.round(frame?.cam_fps ?? camera.fps ?? 0)} FPS</small>
      </div>
      <div className="tile-bottom">
        <div>
          <strong>{camera.name}</strong>
          <small>{camera.floor} · {camera.zone_type}</small>
        </div>
        <span className={`tile-status ${live ? 'safe' : 'danger'}`}>
          <Check size={13} /> {frame?.persons_count ?? 0} people
        </span>
      </div>
    </button>
  );
}
