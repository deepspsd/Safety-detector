// Canonical feature-module entry point. The implementation remains in
// MonitorPage while the redesign is being decomposed into its grid/tile parts.
export { MonitorPage as LiveMonitorPage } from './MonitorPage';
