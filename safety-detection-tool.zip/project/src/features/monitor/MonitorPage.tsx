import { useMemo, useState } from 'react';
import { ChevronDown, Filter, Grid2X2, Loader2, ScanLine } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useCameras } from '@/lib/hooks';
import type { Camera } from '@/lib/db';
import { CameraTile } from './CameraTile';
import { CameraExpandedView } from './CameraExpandedView';
import { DiscoverCamerasModal } from './DiscoverCamerasModal';

const floors = [
  { name: 'Ground Floor', id: 'ground' }, { name: 'First Floor', id: 'first' },
  { name: 'Second Floor', id: 'second' }, { name: 'Shop Floor', id: 'shop' },
];

export function MonitorPage() {
  const navigate = useNavigate();
  const { cameras, loading, refresh } = useCameras();
  const [floor, setFloor] = useState('all');
  const [gridSize, setGridSize] = useState(2);
  const [expanded, setExpanded] = useState<Camera | null>(null);
  const [discoverOpen, setDiscoverOpen] = useState(false);
  
  const visible = useMemo(() => floor === 'all' ? cameras : cameras.filter((camera) => camera.floor === floor), [cameras, floor]);
  const gridClass = gridSize === 1 ? 'monitor-grid-1' : gridSize === 3 ? 'monitor-grid-3' : gridSize === 4 ? 'monitor-grid-4' : 'monitor-grid';
  
  return (
    <div className="monitor-page">
      <div className="monitor-toolbar">
        <div className="monitor-select">
          <Filter size={15} />
          <select value={floor} onChange={(event) => setFloor(event.target.value)}>
            <option value="all">All floors</option>
            {floors.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
          </select>
        </div>
        <div className="monitor-info">
          <span className="live-dot" /> {visible.filter((camera) => camera.status === 'online').length} of {visible.length} cameras online
        </div>
        <div className="monitor-tools">
          <button className="secondary-button" onClick={() => setGridSize(gridSize === 2 ? 1 : gridSize === 1 ? 3 : gridSize === 3 ? 4 : 2)}>
            <Grid2X2 size={16} /> {gridSize}×{gridSize}<ChevronDown size={14} />
          </button>
          <button className="secondary-button" onClick={() => setDiscoverOpen(true)}>
            <ScanLine size={16} /> Discover cameras
          </button>
          <button className="primary-button" onClick={() => navigate('/video')}>
            <ScanLine size={16} /> Video analysis
          </button>
        </div>
      </div>
      
      {expanded ? (
        <CameraExpandedView camera={expanded} onClose={() => setExpanded(null)} onZones={() => navigate(`/settings/cameras/${expanded.id}/calibration`)} />
      ) : (
        <div className={gridClass}>
          {loading ? (
            <div className="loading-row"><Loader2 size={18} className="spin" /> Loading cameras…</div>
          ) : (
            visible.map((camera) => <CameraTile key={camera.id} camera={camera} onOpen={() => setExpanded(camera)} />)
          )}
        </div>
      )}
      
      {discoverOpen && <DiscoverCamerasModal onClose={() => setDiscoverOpen(false)} onRegistered={() => { refresh(); setDiscoverOpen(false); }} />}
    </div>
  );
}
