import { useState } from 'react';
import { Loader2, ScanLine, X } from 'lucide-react';
import { useToast } from '@/providers/ToastProvider';
import { discoverCameras, registerCamera } from '@/api/cameras.api';

export function DiscoverCamerasModal({ onClose, onRegistered }: { onClose: () => void; onRegistered: () => void }) {
  const { showToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [devices, setDevices] = useState<Array<Record<string, unknown>>>([]);
  const [selected, setSelected] = useState<Record<string, unknown> | null>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const scan = async () => {
    setLoading(true);
    try {
      setDevices((await discoverCameras()).devices);
    } catch {
      showToast('Camera discovery failed. Check the private LAN connection.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const connect = async () => {
    if (!selected || !username || !password) return;
    setLoading(true);
    try {
      await registerCamera({
        name: String(selected.model || selected.ip_address || 'ONVIF camera'),
        floor: 'ground',
        onvif_endpoint: String(selected.onvif_endpoint),
        username,
        password
      });
      showToast('Camera registered securely', 'success');
      onRegistered();
    } catch (error: any) {
      showToast(error.response?.data?.detail || 'Camera registration failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="form-modal" onClick={(event) => event.stopPropagation()}>
        <div className="form-modal-header">
          <h2>Discover ONVIF cameras</h2>
          <button className="modal-close" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="form-modal-body" style={{ display: 'block' }}>
          <p>Discovery uses ONVIF WS-Discovery on the private LAN. Candidate devices must authenticate before they are registered.</p>
          <button className="primary-button" disabled={loading} onClick={scan}>
            {loading ? <Loader2 size={16} className="spin" /> : <ScanLine size={16} />} Start discovery
          </button>
          
          {devices.map((device) => (
            <button className="discover-result" key={String(device.device_id)} onClick={() => setSelected(device)}>
              <div className="discover-info">
                <strong>{String(device.manufacturer || 'ONVIF device')} {String(device.model || '')}</strong>
                <small>{String(device.ip_address)} · {String(device.status)}</small>
              </div>
            </button>
          ))}
          
          {selected && (
            <div className="form-modal-body">
              <h3>Connect {String(selected.ip_address)}</h3>
              <label className="form-field">
                <span>Username</span>
                <input value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" />
              </label>
              <label className="form-field">
                <span>Password</span>
                <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" />
              </label>
              <button className="primary-button" disabled={loading || !username || !password} onClick={connect}>
                Authenticate and register
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
