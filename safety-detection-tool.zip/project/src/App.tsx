import { Navigate, Route, Routes, useNavigate, useParams } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/providers/AuthProvider';
import { ThemeProvider } from '@/providers/ThemeProvider';
import { ToastProvider } from '@/providers/ToastProvider';
import { AppLayout } from '@/layout/AppLayout';
import { ProtectedRoute } from '@/layout/ProtectedRoute';
import { LoginPage, SignupPage } from '@/features/auth/AuthPages';
import { DashboardPage } from '@/features/dashboard/DashboardPage';
import { LiveMonitorPage } from '@/features/monitor/LiveMonitorPage';
import { FloorOverviewPage } from '@/features/floors/FloorOverviewPage';
import { AlertsPage } from '@/features/alerts/AlertsPage';
import { AlertsReviewPage } from '@/features/alerts/AlertsReviewPage';
import { AttendancePage } from '@/features/attendance/AttendancePage';
import { DocumentsPage } from '@/features/documents/DocumentsPage';
import { WorkflowPage } from '@/features/workflow/WorkflowPage';
import { CamerasPage } from '@/features/cameras/CamerasPage';
import { ZoneCalibrationPage } from '@/features/cameras/zone-calibration/ZoneCalibrationPage';
import { EmployeesPage } from '@/features/employees/EmployeesPage';
import { SettingsPage } from '@/features/settings/SettingsPage';
import { VideoAnalysisPage } from '@/features/video/VideoAnalysisPage';
import { ProfilePage } from '@/features/profile/ProfilePage';
import { TVDisplayPage } from '@/features/tv/TVDisplayPage';
import { useAlerts, useCameras } from '@/lib/hooks';

function HomeRedirect() {
  const { user, loading } = useAuth();
  if (loading) return null;
  return <Navigate to={user ? '/dashboard' : '/login'} replace />;
}

function ProtectedLayout() {
  return (
    <ProtectedRoute>
      <AppLayout />
    </ProtectedRoute>
  );
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/signup" element={<SignupPage />} />
      <Route path="/tv" element={<TVDisplayPage />} />
      <Route path="/" element={<HomeRedirect />} />
      <Route element={<ProtectedLayout />}>
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/monitor" element={<LiveMonitorPage />} />
        <Route path="/floors/:floorId" element={<FloorOverviewRoute />} />
        <Route path="/alerts" element={<AlertsPage />} />
        <Route path="/alerts/review" element={<AlertsReviewPage />} />
        <Route path="/attendance" element={<AttendancePage />} />
        <Route path="/documents" element={<DocumentsPage />} />
        <Route path="/workflow" element={<WorkflowPage />} />
        <Route path="/video" element={<VideoAnalysisPage />} />
        <Route path="/settings/cameras" element={<CamerasPage />} />
        <Route path="/settings/cameras/:cameraId/calibration" element={<ZoneCalibrationPageRoute />} />
        <Route path="/settings/employees" element={<EmployeesPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/profile" element={<ProfilePage />} />
      </Route>
      <Route path="*" element={<HomeRedirect />} />
    </Routes>
  );
}

function ZoneCalibrationPageRoute() {
  const { cameraId = '' } = useParams();
  const navigate = useNavigate();
  return <ZoneCalibrationPage cameraId={cameraId} onBack={() => navigate('/settings/cameras')} />;
}

function FloorOverviewRoute() {
  const { floorId = 'ground' } = useParams();
  const navigate = useNavigate();
  const { cameras } = useCameras();
  const { alerts } = useAlerts();
  return <FloorOverviewPage floorId={floorId} cameras={cameras} alerts={alerts} onOpenMonitor={() => navigate('/monitor')} />;
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <ToastProvider>
          <AppRoutes />
        </ToastProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
