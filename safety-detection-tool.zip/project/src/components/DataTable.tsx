import type { ReactNode } from 'react';

export function DataTable<T extends { id: string | number }>({ rows, columns, empty }: {
  rows: T[];
  columns: Array<{ key: string; header: string; render: (row: T) => ReactNode }>;
  empty?: ReactNode;
}) {
  if (!rows.length) return <>{empty ?? <div className="empty-state">No records found.</div>}</>;
  return <div className="data-table-wrap"><table className="data-table"><thead><tr>{columns.map((column) => <th key={column.key}>{column.header}</th>)}</tr></thead><tbody>{rows.map((row) => <tr key={row.id}>{columns.map((column) => <td key={column.key}>{column.render(row)}</td>)}</tr>)}</tbody></table></div>;
}
