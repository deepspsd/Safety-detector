import { Bell, CheckCircle2, XCircle } from 'lucide-react';

export function Toast({ message, type = 'info' }: { message: string; type?: 'success' | 'error' | 'info' | 'warning' }) {
  const Icon = type === 'success' ? CheckCircle2 : type === 'error' ? XCircle : Bell;
  return <div className={`toast ${type}`} role="status"><Icon size={18} /><span>{message}</span></div>;
}
