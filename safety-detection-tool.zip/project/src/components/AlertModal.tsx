import { useState } from 'react';
import { AlertTriangle, X, Check, Loader2, Clock3, Zap } from 'lucide-react';
import type { Alert } from '@/lib/db';
import { confirmAlert, dismissAlert } from '@/lib/hooks';
import { useToast } from '@/providers/ToastProvider';

const workerImage = 'https://images.pexels.com/photos/5953714/pexels-photo-5953714.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

function formatTime(dateStr: string): string {
  const d = new Date(dateStr + (dateStr.includes('Z') ? '' : 'Z'));
  if (isNaN(d.getTime())) return dateStr;
  const now = new Date();
  const diff = (now.getTime() - d.getTime()) / 60000;
  if (diff < 1) return 'Just now';
  if (diff < 60) return `${Math.floor(diff)}m ago`;
  if (diff < 1440) return `${Math.floor(diff / 60)}h ago`;
  return d.toLocaleDateString();
}

export function AlertModal({ alert, onClose }: { alert: Alert; onClose: () => void }) {
  const { showToast } = useToast();
  const [sending, setSending] = useState(false);

  const handleConfirm = async () => {
    setSending(true);
    await confirmAlert(alert.id);
    setSending(false);
    showToast('Alert confirmed', 'success');
    onClose();
  };

  const handleDismiss = async () => {
    await dismissAlert(alert.id);
    showToast('Alert dismissed', 'info');
    onClose();
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="alert-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-image">
          <img src={workerImage} alt="Alert" />
          <button onClick={onClose} className="modal-close"><X size={18} /></button>
          <span className={`modal-severity ${alert.severity}`}>{alert.severity.toUpperCase()} ALERT</span>
        </div>
        <div className="modal-content">
          <div className="eyebrow"><span className="live-dot" /> DETECTED {formatTime(alert.detected_at).toUpperCase()}</div>
          <h2>{alert.title}</h2>
          <p>{alert.message || 'AI inference identified a safety issue. Please review and confirm.'}</p>
          <div className="detail-grid">
            <div><small>CAMERA</small><strong>{alert.camera_name}</strong></div>
            <div><small>CONFIDENCE</small><strong>{alert.confidence}%</strong></div>
            <div><small>FLOOR</small><strong>{alert.floor}</strong></div>
            <div><small>STATUS</small><strong className={`severity-text ${alert.severity}`}>{alert.status.replace('_', ' ')}</strong></div>
          </div>
          <div className="modal-actions">
            <button className="secondary-button" onClick={handleDismiss}>Dismiss</button>
            <button className="primary-button" onClick={handleConfirm} disabled={sending}>{sending ? <Loader2 size={16} className="spin" /> : <Check size={16} />} {sending ? 'Sending...' : 'Confirm & notify'}</button>
          </div>
        </div>
      </div>
    </div>
  );
}
