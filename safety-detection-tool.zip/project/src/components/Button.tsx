import type { ButtonHTMLAttributes, ReactNode } from 'react';

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
};

export function Button({ children, variant = 'primary', className = '', ...props }: ButtonProps) {
  const classes = { primary: 'primary-button', secondary: 'secondary-button', danger: 'danger-button', ghost: 'text-button' };
  return <button className={`${classes[variant]} ${className}`.trim()} {...props}>{children}</button>;
}
