import { Loader2 } from 'lucide-react';

export function Spinner({ size = 18 }: { size?: number }) {
  return <Loader2 size={size} className="spin" />;
}

export function LoadingRow({ label = 'Loading...' }: { label?: string }) {
  return (
    <div className="loading-row">
      <Loader2 size={18} className="spin" /> {label}
    </div>
  );
}
