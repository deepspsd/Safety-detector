type Status = 'online' | 'offline' | 'warning' | 'error';

export function StatusDot({ status, size = 8 }: { status: Status; size?: number }) {
  return <span className={`camera-status-dot ${status}`} style={{ width: size, height: size }} />;
}
