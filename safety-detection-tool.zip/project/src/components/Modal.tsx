import { X } from 'lucide-react';
import { ReactNode } from 'react';

export function Modal({ title, onClose, children, width }: { title?: string; onClose: () => void; children: ReactNode; width?: string }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="form-modal" style={width ? { width } : undefined} onClick={(e) => e.stopPropagation()}>
        {title && (
          <div className="form-modal-header">
            <h2>{title}</h2>
            <button onClick={onClose} className="modal-close"><X size={18} /></button>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}
