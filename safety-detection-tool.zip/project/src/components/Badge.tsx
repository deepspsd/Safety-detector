type BadgeVariant = 'confirmed' | 'pending_review' | 'dismissed' | 'active' | 'standby' | 'healthy' | 'inward' | 'outward';

export function Badge({ variant, children }: { variant: BadgeVariant; children: React.ReactNode }) {
  return <span className={`status-badge ${variant}`}>{children}</span>;
}

export function DirectionBadge({ direction }: { direction: 'inward' | 'outward' }) {
  return <span className={`direction-badge ${direction}`}>{direction}</span>;
}
