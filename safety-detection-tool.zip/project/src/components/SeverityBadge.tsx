type Severity = 'critical' | 'high' | 'medium' | 'low';

export function SeverityBadge({ severity }: { severity: Severity }) {
  return <span className={`severity-text ${severity}`}>{severity}</span>;
}

export function SeverityIcon({ severity, size = 15 }: { severity: Severity; size?: number }) {
  return <span className={`severity-icon ${severity}`}>{severity === 'critical' ? '!' : severity === 'high' ? '!' : '·'}</span>;
}
