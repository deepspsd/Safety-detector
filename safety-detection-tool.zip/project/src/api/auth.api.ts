import client from './client';

export type AuthUser = {
  id: string;
  email: string;
  name: string;
  role: string;
  created_at: string;
};

const USER_KEY = 'occusafe_user';

export async function login(email: string, password: string): Promise<AuthUser> {
  const form = new URLSearchParams({ username: email, password });
  const { data } = await client.post('/auth/login', form, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  localStorage.setItem('token', data.access_token);
  return getMeOrStored();
}

export async function signup(data: { email: string; password: string; name: string; role: string }): Promise<AuthUser> {
  await client.post('/auth/signup', data);
  return login(data.email, data.password);
}

export function getStoredUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) as AuthUser : null;
  } catch {
    return null;
  }
}

export function isAuthenticated(): boolean {
  return Boolean(localStorage.getItem('token'));
}

export function logout(): void {
  localStorage.removeItem('token');
  localStorage.removeItem(USER_KEY);
}

export async function getMe(): Promise<AuthUser> {
  const { data } = await client.get<AuthUser>('/auth/me');
  localStorage.setItem(USER_KEY, JSON.stringify(data));
  return data;
}

async function getMeOrStored(): Promise<AuthUser> {
  try {
    return await getMe();
  } catch (error) {
    logout();
    throw error;
  }
}

export async function updateProfile(updates: { name?: string; role?: string }): Promise<AuthUser> {
  const { data } = await client.put<AuthUser>('/users/me', updates);
  localStorage.setItem(USER_KEY, JSON.stringify(data));
  return data;
}
