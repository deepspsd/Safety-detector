import axios from 'axios';

const configuredBaseUrl = import.meta.env.VITE_API_BASE_URL?.replace(/\/$/, '');

/**
 * All frontend data calls go through this client.  In development Vite proxies
 * /api to FastAPI; deployed builds can use a LAN FastAPI address from .env.
 */
const client = axios.create({
  baseURL: configuredBaseUrl || '/api',
  headers: { 'Content-Type': 'application/json' },
});

client.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

client.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('occusafe_user');
      if (window.location.pathname !== '/login') window.location.assign('/login');
    }
    return Promise.reject(error);
  },
);

export default client;
export const apiBaseUrl = configuredBaseUrl || '/api';



export function getWsURL() {
  const envURL = import.meta.env.VITE_API_BASE_URL;
  if (envURL && !envURL.includes('localhost') && !envURL.includes('127.0.0.1')) {
    return envURL.replace(/^http/, 'ws') + '/ws/detect';
  }
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws';
  return `${proto}://${window.location.host}/ws/detect`;
}

export function getCctvWsURL() {
  const envURL = import.meta.env.VITE_API_BASE_URL;
  if (envURL && !envURL.includes('localhost') && !envURL.includes('127.0.0.1')) {
    return envURL.replace(/^http/, 'ws') + '/ws/detect-cctv';
  }
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws';
  return `${proto}://${window.location.host}/ws/detect-cctv`;
}
