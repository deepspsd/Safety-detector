import client from './client';
import type { AttendanceRecord } from '@/lib/db';

export async function getAttendanceStats(): Promise<{ present: number; absent: number; late: number; total: number }> {
  const { data } = await client.get('/attendance/stats');
  return data;
}

export async function listAttendance(date?: string, employeeId?: string, limit = 200): Promise<AttendanceRecord[]> {
  const { data } = await client.get('/attendance/', { params: { date, employee_id: employeeId, limit } });
  return data.records;
}

export async function clockIn(data: { employee_name: string; camera_name: string; method: string; notes: string }): Promise<void> {
  await client.post('/attendance/clock-in', data);
}

export async function clockOut(recordId: string): Promise<void> {
  await client.patch(`/attendance/${recordId}/clock-out`);
}

export async function exportAttendanceCSV(date?: string): Promise<string> {
  const rows = await listAttendance(date);
  const header = 'ID,Employee,Camera,Method,Clock In,Clock Out,Notes\n';
  const body = rows.map((r) =>
    [r.id, r.employee_name, r.camera_name, r.method, r.clock_in, r.clock_out || '', r.notes].join(',')
  ).join('\n');
  return header + body;
}
