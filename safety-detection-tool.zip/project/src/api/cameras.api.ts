import client from './client';
import type { CalibrationVersion, Camera, Zone } from '@/lib/db';

type ApiCamera = Record<string, unknown>;

function toCamera(value: ApiCamera): Camera {
  const live = value.live as Record<string, unknown> | null;
  const capabilities = value.capabilities as Record<string, boolean> | undefined;
  return {
    id: String(value.id), name: String(value.name ?? ''), floor: String(value.floor ?? 'ground'),
    zone_type: String(value.zone_type ?? ''), rtsp_url: '', status: String(value.status ?? 'offline'),
    camera_code: String(value.camera_code ?? ''), department: String(value.department ?? ''),
    fps: Number(live?.fps ?? value.configured_fps ?? 0), capabilities: Object.entries(capabilities ?? {}).filter(([, enabled]) => enabled).map(([name]) => name),
    created_at: String(value.created_at ?? ''), updated_at: String(value.created_at ?? ''),
  };
}

export async function listCameras(): Promise<Camera[]> {
  const { data } = await client.get<ApiCamera[]>('/cameras/');
  return data.map(toCamera);
}

export async function getCamera(id: string): Promise<Camera | null> {
  try { const { data } = await client.get<ApiCamera>(`/cameras/${id}`); return toCamera(data); }
  catch (error: any) { if (error.response?.status === 404) return null; throw error; }
}

export async function createCamera(camera: Partial<Camera>): Promise<void> {
  await client.post('/cameras/', {
    name: camera.name, floor: camera.floor || 'ground', zone_type: camera.zone_type || 'entrance',
    rtsp_url: camera.rtsp_url || null, status: camera.status === 'offline' ? 'offline' : 'online',
    camera_code: camera.camera_code || null, department: camera.department || null, configured_fps: camera.fps || null,
  });
}

export async function registerCamera(input: { name: string; floor: string; zone_type?: string; onvif_endpoint: string; username: string; password: string; preferred_stream?: 'main' | 'sub'; ai_stream?: 'main' | 'sub' }): Promise<Camera> {
  const { data } = await client.post<ApiCamera>('/cameras/register', input);
  return toCamera(data);
}

export async function updateCamera(id: string, camera: Partial<Camera>): Promise<void> {
  await client.put(`/cameras/${id}`, {
    name: camera.name, floor: camera.floor, zone_type: camera.zone_type, status: camera.status,
    camera_code: camera.camera_code, department: camera.department, configured_fps: camera.fps,
  });
}
export const deleteCamera = (id: string) => client.delete(`/cameras/${id}`).then(() => undefined);
export const restartCamera = (id: string) => client.post(`/cameras/${id}/restart`).then(() => undefined);
export const connectCamera = (id: string) => client.post(`/cameras/${id}/connect`).then((response) => response.data);
export const disconnectCamera = (id: string) => client.post(`/cameras/${id}/disconnect`).then((response) => response.data);
export const selectCameraStream = (id: string, streamType: 'main' | 'sub') => client.post(`/cameras/${id}/streams/select`, null, { params: { stream_type: streamType } }).then((response) => response.data);
export const getCameraHealth = (id: string) => client.get(`/cameras/${id}/health`).then((response) => response.data);
export const getCameraStreams = (id: string) => client.get(`/cameras/${id}/streams`).then((response) => response.data);

export async function discoverCameras(options: { timeout_seconds?: number; interface?: string; retries?: number; fallback_subnet?: string } = {}): Promise<{ devices: Array<Record<string, unknown>> }> {
  const { data } = await client.post('/cameras/discover', options);
  return data;
}

export async function getSnapshot(id: string): Promise<string> {
  const { data } = await client.get(`/cameras/${id}/snapshot`);
  return data.frame_b64 ?? '';
}

export async function getZones(cameraId: string): Promise<Zone[]> {
  const { data } = await client.get(`/cameras/${cameraId}/zones`);
  return data.map((zone: Record<string, unknown>) => ({ ...zone, id: String(zone.id), camera_id: cameraId, active: Boolean(zone.is_active), updated_at: String(zone.created_at ?? '') })) as Zone[];
}
export async function createZone(cameraId: string, zoneName: string, zoneType: string, polygonJson: string, color: string): Promise<void> {
  await client.post(`/cameras/${cameraId}/zones`, { zone_name: zoneName, zone_type: zoneType, polygon_json: polygonJson, color });
}
export async function updateZone(id: string, polygonJson: string, color: string, zoneType?: string): Promise<void> {
  throw new Error('Zone update requires the camera id; use createZone to replace a named zone.');
}
export async function softDeleteZone(id: string): Promise<void> { throw new Error(`Zone ${id} delete requires camera and zone name.`); }
export async function deleteZone(cameraId: string, zoneName: string): Promise<void> { await client.delete(`/cameras/${cameraId}/zones/${encodeURIComponent(zoneName)}`); }
export const deleteZoneById = softDeleteZone;
export async function getCalibrations(cameraId: string): Promise<CalibrationVersion[]> { const { data } = await client.get(`/cameras/${cameraId}/calibrations`); return data; }
export async function saveCalibrationSnapshot(cameraId: string): Promise<void> { await client.post(`/cameras/${cameraId}/calibrations/snapshot`); }
export async function restoreCalibration(cameraId: string, version: number): Promise<void> { await client.post(`/cameras/${cameraId}/calibrations/${version}/restore`, {}); }
