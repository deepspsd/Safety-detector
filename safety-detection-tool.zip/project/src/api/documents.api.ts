import client from './client';
import type { DocumentRecord } from '@/lib/db';

export async function getDocumentStats(): Promise<any> {
  const { data } = await client.get('/documents/stats');
  return data;
}

export async function listDocuments(filters?: { direction?: string; approved?: boolean; limit?: number }): Promise<DocumentRecord[]> {
  const { data } = await client.get('/documents/', { params: filters });
  return data.documents;
}

export async function scanDocument(data: { direction: string; ocr_text: string; camera_name: string }): Promise<void> {
  await client.post('/documents/scan', data);
}

export async function approveDocument(id: string): Promise<void> {
  await client.patch(`/documents/${id}/approve`);
}

export async function rejectDocument(id: string): Promise<void> {
  await client.patch(`/documents/${id}/reject`);
}

export async function deleteDocument(id: string): Promise<void> {
  await client.delete(`/documents/${id}`);
}
