import client from './client';
import type { WorkflowEvent } from '@/lib/db';

export async function getWorkflowSummary(): Promise<any> {
  const { data } = await client.get('/workflow/summary');
  return data;
}

export async function getCashEvents(limit = 50): Promise<WorkflowEvent[]> {
  const { data } = await client.get('/workflow/cash-events', { params: { limit } });
  return data;
}

export async function getStockEvents(limit = 50): Promise<WorkflowEvent[]> {
  const { data } = await client.get('/workflow/stock-events', { params: { limit } });
  return data;
}

export async function getLiftEvents(cameraId?: string, limit = 100): Promise<WorkflowEvent[]> {
  const { data } = await client.get('/workflow/lift-events', { params: { camera_id: cameraId, limit } });
  return data;
}

export async function getPackingEvents(cameraId?: string): Promise<WorkflowEvent[]> {
  const { data } = await client.get('/workflow/packing-events', { params: { camera_id: cameraId } });
  return data;
}
