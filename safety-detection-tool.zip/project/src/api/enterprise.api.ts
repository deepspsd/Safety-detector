import client from './client';

export const listModels = () => client.get('/platform/models').then((response) => response.data);
export const listHealth = (params?: { component_type?: string; limit?: number }) => client.get('/platform/health', { params }).then((response) => response.data);
export const getAnalyticsSummary = (days = 7) => client.get('/platform/analytics/summary', { params: { days } }).then((response) => response.data);
export const listAlertCases = (limit = 100) => client.get('/platform/alert-cases', { params: { limit } }).then((response) => response.data);
export const actionAlertCase = (id: string | number, action: 'acknowledge' | 'dismiss') => client.post(`/platform/alert-cases/${id}/${action}`).then((response) => response.data);
export const listRuleProfiles = () => client.get('/platform/rule-profiles').then((response) => response.data);
export const listRules = () => client.get('/platform/rules').then((response) => response.data);
export const listWorkflowProfiles = () => client.get('/platform/workflow-profiles').then((response) => response.data);
