import client from './client';
import type { Employee } from '@/lib/db';

export async function listFaces(): Promise<Employee[]> {
  const { data } = await client.get('/faces/');
  return data;
}

export async function registerFace(data: { label: string; image_b64: string }): Promise<void> {
  await client.post('/faces/register', data);
}

export async function renameFace(id: string, label: string): Promise<void> {
  await client.put(`/faces/${id}/rename`, { label });
}

export async function deleteFace(id: string): Promise<void> {
  await client.delete(`/faces/${id}`);
}
