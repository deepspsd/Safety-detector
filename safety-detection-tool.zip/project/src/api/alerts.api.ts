import client from './client';
import type { Alert } from '@/lib/db';

export async function listAlerts(filters?: {
  status?: string; severity?: string; floor?: string; camera_id?: string;
  date_from?: string; date_to?: string; limit?: number;
}): Promise<Alert[]> {
  const { data } = await client.get('/alerts/', { params: filters });
  return data.alerts;
}

export async function getAlert(id: string): Promise<Alert | null> {
  try {
    const { data } = await client.get(`/alerts/${id}`);
    return data;
  } catch (error: any) {
    if (error.response?.status === 404) return null;
    throw error;
  }
}

export async function deleteAlert(id: string): Promise<void> {
  await client.delete(`/alerts/${id}`);
}

export async function deleteAllAlerts(): Promise<void> {
  await client.delete('/alerts/');
}

export async function getAlertStats(): Promise<any> {
  const { data } = await client.get('/alerts/stats');
  return data;
}

export async function getPendingAlerts(limit = 20): Promise<Alert[]> {
  const { data } = await client.get('/alerts/pending', { params: { limit } });
  return data.alerts;
}

export async function confirmAlert(id: string): Promise<void> {
  await client.patch(`/alerts/${id}/confirm`);
}

export async function dismissAlert(id: string): Promise<void> {
  await client.patch(`/alerts/${id}/dismiss`);
}

export async function testTelegram(): Promise<{ ok: boolean; error?: string }> {
  try {
    await client.post('/alerts/test-telegram');
    return { ok: true };
  } catch (err: any) {
    return { ok: false, error: err.response?.data?.detail || 'Telegram test failed' };
  }
}
