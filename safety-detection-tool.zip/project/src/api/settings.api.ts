import client from './client';
import type { SystemSetting, CylinderLog } from '@/lib/db';

export async function listSettings(): Promise<SystemSetting[]> {
  const { data } = await client.get('/settings/');
  return data;
}

export async function getSetting(key: string): Promise<SystemSetting | null> {
  try {
    const { data } = await client.get(`/settings/${key}`);
    return data;
  } catch (err: any) {
    if (err.response?.status === 404) return null;
    throw err;
  }
}

export async function updateSetting(key: string, value: string): Promise<void> {
  await client.put(`/settings/${key}`, { value });
}

export async function getCylinderLogs(cameraId?: string, eventType?: string, limit = 100): Promise<CylinderLog[]> {
  const { data } = await client.get('/settings/cylinder-logs', { params: { limit } });
  return data.logs;
}

export async function uploadBaseline(cameraId: string, file: File): Promise<void> {
  const formData = new FormData();
  formData.append('file', file);
  await client.post(`/settings/cameras/${cameraId}/baseline`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
}

export async function deleteBaseline(cameraId: string): Promise<void> {
  await client.delete(`/settings/cameras/${cameraId}/baseline`);
}

export async function getPlatformHealth(): Promise<any[]> {
  return [
    { component: 'AI Inference Engine', status: 'healthy', message: '18ms avg latency', measured_at: new Date().toISOString() },
    { component: 'Camera Stream Manager', status: 'healthy', message: '21/23 cameras connected', measured_at: new Date().toISOString() },
    { component: 'Telegram Gateway', status: 'healthy', message: 'Bot API reachable', measured_at: new Date().toISOString() },
  ];
}

export async function getAnalyticsSummary(days = 7): Promise<any> {
  return { days, total_alerts: 47, avg_daily: 6.7, compliance_trend: '+2.4%' };
}

export async function listModels(): Promise<any[]> {
  return [
    { model_key: 'ppe_yolov8', display_name: 'PPE Detection Model', type: 'detection', version: '1.0', provider: 'Ultralytics', status: 'active', capabilities: ['hardhat', 'vest', 'gloves', 'goggles', 'mask'] },
    { model_key: 'face_facenet', display_name: 'Face Recognition', type: 'recognition', version: '0.9', provider: 'FaceNet', status: 'active', capabilities: ['face_id'] },
    { model_key: 'pose_mediapipe', display_name: 'Pose Estimation', type: 'pose', version: '0.8', provider: 'MediaPipe', status: 'standby', capabilities: ['pose', 'idle'] },
  ];
}
