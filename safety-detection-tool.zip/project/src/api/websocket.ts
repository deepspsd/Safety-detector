// Reconnecting WebSocket transport for the FastAPI detection stream.
// No synthetic frames are generated: callers can clearly distinguish an
// unavailable camera/backend from a real inference result.

export type DetectionFrame = {
  annotated_frame: string;
  detections: unknown[];
  is_compliant: boolean;
  missing_items: string[];
  violations_count: number;
  persons_count: number;
  alert_message: string | null;
  severity: string | null;
  face_result: unknown;
  cam_fps: number;
  phone_status: string;
};

export type StreamHandlers = {
  onFrame: (frame: DetectionFrame) => void;
  onStatus: (status: 'connecting' | 'connected' | 'disconnected' | 'error') => void;
};

function getWebSocketBase(): string {
  const configured = import.meta.env.VITE_WS_BASE_URL;
  if (configured) return configured.replace(/\/$/, '');
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${protocol}//${window.location.host}`;
}

export class CameraStream {
  private socket: WebSocket | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private closed = false;
  private attempts = 0;

  constructor(private readonly handlers: StreamHandlers, private readonly cameraId: string, private readonly path = '/ws/detect-cctv') {}

  connect() {
    if (this.closed || this.socket?.readyState === WebSocket.OPEN) return;
    this.handlers.onStatus('connecting');
    this.socket = new WebSocket(`${getWebSocketBase()}${this.path}`);
    this.socket.onopen = () => {
      this.attempts = 0;
      this.socket?.send(JSON.stringify({ token: localStorage.getItem('token'), camera_id: Number(this.cameraId), filters: [], no_phone_zone: true, enable_face: true }));
      this.handlers.onStatus('connected');
    };
    this.socket.onmessage = (event) => {
      try { this.handlers.onFrame(JSON.parse(event.data) as DetectionFrame); }
      catch { this.handlers.onStatus('error'); }
    };
    this.socket.onerror = () => this.handlers.onStatus('error');
    this.socket.onclose = () => {
      this.socket = null;
      this.handlers.onStatus('disconnected');
      this.scheduleReconnect();
    };
  }

  sendConfig(config: { filters: string[]; no_phone_zone: boolean; enable_face: boolean }) {
    if (this.socket?.readyState === WebSocket.OPEN) this.socket.send(JSON.stringify(config));
  }

  close() {
    this.closed = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.socket?.close();
    this.socket = null;
    this.handlers.onStatus('disconnected');
  }

  private scheduleReconnect() {
    if (this.closed) return;
    const delay = Math.min(30_000, 1_000 * 2 ** this.attempts++);
    this.reconnectTimer = setTimeout(() => this.connect(), delay);
  }
}
