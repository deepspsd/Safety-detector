import client from './client';

export interface VideoJob {
  status: string;
  progress: number;
  total_alerts?: number;
  total_violations?: number;
  alerts?: any[];
  violation_timestamps?: any[];
  ppe_summary?: Record<string, number>;
  annotated_video_url?: string;
  video_duration_sec?: number;
  error?: string;
}

export async function uploadVideo(
  file: File, 
  onUploadProgress?: (progressEvent: any) => void
): Promise<string> {
  const formData = new FormData();
  formData.append('file', file);
  
  const response = await client.post('/video/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    onUploadProgress
  });
  
  return response.data.job_id;
}

export async function getVideoStatus(jobId: string): Promise<VideoJob | null> {
  try {
    const response = await client.get(`/video/status/${jobId}`);
    return response.data;
  } catch (error) {
    return null;
  }
}
