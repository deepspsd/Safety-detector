import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { MobileHeader } from './MobileHeader';

const titleMap: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/monitor': 'Live Monitor',
  '/alerts': 'Alerts',
  '/alerts/review': 'Review Queue',
  '/attendance': 'Attendance',
  '/documents': 'Documents',
  '/workflow': 'Workflow Monitor',
  '/video': 'Video Analysis',
  '/settings/cameras': 'Camera Management',
  '/settings/employees': 'Employee Management',
  '/settings': 'Settings',
  '/profile': 'My Profile',
};

export function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth > 800);
  const location = useLocation();
  const title = titleMap[location.pathname] || 'OccuSafe';

  return (
    <div className="app-shell">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <main className={`main-content ${sidebarOpen ? '' : 'sidebar-closed'}`}>
        <MobileHeader onMenuToggle={() => setSidebarOpen(!sidebarOpen)} title={title} />
        <div className="content-wrap">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
