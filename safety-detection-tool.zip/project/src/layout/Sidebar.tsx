import { useState, useEffect, useCallback } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  ShieldCheck, Bell, Clock3, LayoutDashboard, Users, FileText, PackageCheck,
  Camera, UserCog, Settings, LogOut, Tv, Video, Building2, ChevronDown, Sun, Moon, X,
} from 'lucide-react';
import { useTheme } from '@/providers/ThemeProvider';
import { useAuth } from '@/providers/AuthProvider';
import { usePolling } from '@/hooks/usePolling';
import { getPendingAlerts } from '@/api/alerts.api';

const floorMeta = [
  { name: 'Ground Floor', id: 'ground', short: 'GF', color: '#ffb866' },
  { name: 'First Floor', id: 'first', short: '1F', color: '#63b6a5' },
  { name: 'Second Floor', id: 'second', short: '2F', color: '#ef8c73' },
  { name: 'Shop Floor', id: 'shop', short: 'SF', color: '#7e9cdb' },
];

export function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { theme, toggle } = useTheme();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [floorsExpanded, setFloorsExpanded] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);

  const refreshPending = useCallback(async () => {
    try {
      const pending = await getPendingAlerts();
      setPendingCount(pending.length);
    } catch {}
  }, []);
  usePolling(refreshPending, 30000);

  useEffect(() => { refreshPending(); }, [refreshPending]);

  const initials = user?.name?.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase() || 'AD';

  const handleSignOut = () => { logout(); navigate('/login'); };

  const handleNavClick = () => {
    if (window.innerWidth <= 800) {
      onClose();
    }
  };

  const navClass = ({ isActive }: { isActive: boolean }) => `nav-item ${isActive ? 'active' : ''}`;
  const subNavClass = (active: boolean) => `sub-nav-item ${active ? 'active' : ''}`;

  return (
    <aside className={`sidebar ${open ? 'sidebar-open' : ''}`}>
      <div className="brand-row">
        <div className="brand-mark"><ShieldCheck size={19} strokeWidth={2.5} /></div>
        <span>Occu<span>Safe</span></span>
        <button className="theme-toggle" onClick={toggle}>{theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}</button>
        <button className="sidebar-close" onClick={onClose} aria-label="Close navigation"><X size={18} /></button>
      </div>
      <div className="role-banner">BAKERY FOOD SAFETY</div>

      <div className="nav-label">MONITORING</div>
      <nav>
        <button className={`nav-item ${floorsExpanded ? 'expanded' : ''}`} onClick={() => setFloorsExpanded(!floorsExpanded)}>
          <Building2 size={18} /><span>Floors</span><ChevronDown size={14} className={`expand-arrow ${floorsExpanded ? 'rotated' : ''}`} />
        </button>
        {floorsExpanded && (
          <div className="sub-nav">
            {floorMeta.map((f) => (
              <NavLink key={f.id} to={`/floors/${f.id}`} className={() => subNavClass(false)} onClick={handleNavClick}>
                <span className="sub-nav-dot" style={{ background: f.color }} /> {f.name}
              </NavLink>
            ))}
          </div>
        )}
        <NavLink to="/monitor" className={navClass} onClick={handleNavClick}><Video size={18} /><span>Live Monitor</span></NavLink>
        <NavLink to="/alerts" className={navClass} onClick={handleNavClick}><Bell size={18} /><span>Alerts</span></NavLink>
        <NavLink to="/alerts/review" className={navClass} onClick={handleNavClick}><Clock3 size={18} /><span>Review Queue</span>{pendingCount > 0 && <b className="nav-count">{pendingCount}</b>}</NavLink>
        <NavLink to="/dashboard" className={navClass} onClick={handleNavClick}><LayoutDashboard size={18} /><span>Dashboard</span></NavLink>
        <NavLink to="/attendance" className={navClass} onClick={handleNavClick}><Users size={18} /><span>Attendance</span></NavLink>
        <NavLink to="/documents" className={navClass} onClick={handleNavClick}><FileText size={18} /><span>Documents</span></NavLink>
        <NavLink to="/workflow" className={navClass} onClick={handleNavClick}><PackageCheck size={18} /><span>Workflow</span></NavLink>
        <NavLink to="/video" className={navClass} onClick={handleNavClick}><Video size={18} /><span>Video Analysis</span></NavLink>
      </nav>

      <div className="nav-label settings-label">SETTINGS</div>
      <nav>
        <NavLink to="/settings/cameras" className={navClass} onClick={handleNavClick}><Camera size={18} /><span>Cameras</span></NavLink>
        <NavLink to="/settings/employees" className={navClass} onClick={handleNavClick}><UserCog size={18} /><span>Employees</span></NavLink>
        <NavLink to="/settings" className={navClass} onClick={handleNavClick}><Settings size={18} /><span>Settings</span></NavLink>
      </nav>

      <div className="nav-label settings-label">ACCOUNT</div>
      <nav>
        <NavLink to="/profile" className={navClass} onClick={handleNavClick}><Users size={18} /><span>Profile</span></NavLink>
        <NavLink to="/tv" className={navClass} onClick={handleNavClick}><Tv size={18} /><span>TV Display</span></NavLink>
        <button className="nav-item" onClick={handleSignOut}><LogOut size={18} /><span>Sign Out</span></button>
      </nav>

      <div className="sidebar-bottom">
        <div className="user-row">
          <div className="user-avatar">{initials}</div>
          <div><strong>{user?.name || 'Admin'}</strong><small>{user?.role || 'Administrator'}</small></div>
        </div>
      </div>
    </aside>
  );
}
