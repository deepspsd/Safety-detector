import { Menu, Search, Bell, ChevronRight } from 'lucide-react';
import { useAuth } from '@/providers/AuthProvider';

export function MobileHeader({ onMenuToggle, title }: { onMenuToggle: () => void; title: string }) {
  const { user } = useAuth();
  const initials = user?.name?.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase() || 'AD';
  return (
    <header className="topbar">
      <button className="menu-button" onClick={onMenuToggle} aria-label="Toggle navigation"><Menu size={21} /></button>
      <div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14} /><strong>{title}</strong></div>
      <div className="topbar-actions">
        <div className="search-box"><Search size={16} /><input placeholder="Search anything..." /></div>
        <button className="icon-button"><Bell size={18} /><i /></button>
        <div className="top-avatar">{initials}</div>
      </div>
    </header>
  );
}
