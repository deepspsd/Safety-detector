import { useEffect, useRef, useState } from 'react';
import { CameraStream, type DetectionFrame } from '@/api/websocket';

export function useCameraStream(cameraId: string | null, enabled = true) {
  const [frame, setFrame] = useState<DetectionFrame | null>(null);
  const [status, setStatus] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('disconnected');
  const streamRef = useRef<CameraStream | null>(null);

  useEffect(() => {
    if (!cameraId || !enabled) return;
    const stream = new CameraStream({
      onFrame: setFrame,
      onStatus: setStatus,
    }, cameraId);
    streamRef.current = stream;
    stream.connect();
    return () => stream.close();
  }, [cameraId, enabled]);

  const sendConfig = (config: { filters: string[]; no_phone_zone: boolean; enable_face: boolean }) => {
    streamRef.current?.sendConfig(config);
  };

  return { frame, status, sendConfig };
}
