# 🏭 OccuSafe — 2-Month Training Master Plan
### Biscuit Factory Safety Detection System

---

## ⚠️ Golden Rules (Read First)

| Rule | Detail |
|---|---|
| **Never delete `ppe.pt`** | Original 10-class model — permanent backup forever |
| **Never rush annotation** | Bad labels = bad model. 100 good images > 1000 bad ones |
| **2 months = enough time** | Plan is laid out weekly — follow the sequence |
| **Client footage > public data** | Public data only seeds the model. Final accuracy comes from client footage |
| **Chewing = NOT YOLO** | MediaPipe Face Mesh only. Do not waste annotation time on this |

---

## 📁 Folder Structure

```
training/
│
├── README.md                            ← THIS FILE — master plan
│
├── phase0_public_seed/                  ← TODAY — public data, head cap only
│   └── phase0_kaggle_seed.ipynb
│
├── phase1_core_ppe/                     ← Week 1–4 — 4 priority classes
│   ├── frame_extraction.ipynb           ← Step 1: run locally on client footage
│   └── phase1_kaggle_training.ipynb     ← Step 2: train on Kaggle
│
├── phase2_rule_engine/                  ← Week 3–6 — NO model training
│   └── README.md                        ← Engineering tasks (idle, OCR, shift checks)
│
├── phase3_object_classes/               ← Week 6–8 — 3 remaining object classes
│   └── phase3_kaggle_training.ipynb
│
├── phase4_hard_problems/                ← Week 7–9 — R&D (chewing, flame, floor)
│   └── README.md
│
├── models/                              ← Drop ALL model .pt files here as backup
│   ├── ppe.pt                           ← ORIGINAL (never delete)
│   ├── ppe_factory_v1.pt                ← Phase 1 output
│   └── ppe_factory_v2.pt                ← Phase 3 output
│
└── phase1_public_only/                  ← OLD FOLDER — maps to Phase 0 above
    └── phase1_kaggle_training.ipynb     ← Same notebook as phase0/
```

> **Note on old folders:** `phase1_public_only` = Phase 0 (public seed), `phase2_client_footage` = Phase 1 inputs. New naming reflects the correct sequence.

---

## 🗓️ 2-Month Timeline

```
Week 1    Week 2    Week 3    Week 4    Week 5    Week 6    Week 7    Week 8
  │         │         │         │         │         │         │         │
Phase 0   Phase 1   Phase 1   Phase 1   Phase 2   Phase 2   Phase 3   Phase 3
(today)   annotate  train v1  deploy    rule eng  rule eng  annotate  train v2
          +extract  + OCR     + test    idle/     OCR gate  +phase3   + deploy
                              gates     shifts    live      classes
                                                            │
                                                          Phase 4
                                                          (chewing,
                                                           flame, floor)
                                                          runs in parallel
                                                          as R&D
```

---

## 📊 Complete Class Plan — All 17 Classes

> Classes 0–9 are locked. They come from `ppe.pt` and are protected by `freeze=10`.
> Never re-annotate or override them.

| ID | Class | Type | Phase Added | Data Source |
|---|---|---|---|---|
| 0 | Hardhat | ✅ Compliant | Original | ppe.pt |
| 1 | Mask | ✅ Compliant | Original | ppe.pt |
| 2 | NO-Hardhat | ❌ Violation | Original | ppe.pt |
| 3 | NO-Mask | ❌ Violation | Original | ppe.pt |
| 4 | NO-Safety Vest | ❌ Violation | Original | ppe.pt |
| 5 | Person | 👤 Neutral | Original | ppe.pt |
| 6 | Safety Cone | 🟠 Neutral | Original | ppe.pt |
| 7 | Safety Vest | ✅ Compliant | Original | ppe.pt |
| 8 | machinery | 🔵 Neutral | Original | ppe.pt |
| 9 | vehicle | 🔵 Neutral | Original | ppe.pt |
| **10** | **Bakery-Head-Cap** | ✅ Compliant | **Phase 0 → 1** | Public seed → client footage |
| **11** | **NO-Bakery-Head-Cap** | ❌ Violation | **Phase 0 → 1** | Public seed → client footage |
| **12** | **Bangles** | ❌ Violation | **Phase 1** | Client footage only |
| **13** | **Document-in-hand** | 🔵 Neutral | **Phase 1** | Client footage only |
| **14** | **Cylinder** | 🔵 Neutral | **Phase 3** | Client footage only |
| **15** | **Exposed-Item** | ❌ Violation | **Phase 3** | Client footage only |
| **16** | **Cashbox** | 🔵 Neutral | **Phase 3** | Client footage only |

---
---

# PHASE 0 — Today (Public Data Seed)
## `phase0_public_seed/phase0_kaggle_seed.ipynb`

**Goal:** Get a working 12-class model TODAY using only public Roboflow datasets.
No client footage needed. This is a seed — not a final model.

### What gets trained today

| Class | Public Dataset Available | Expected Quality |
|---|---|---|
| Bakery-Head-Cap (10) | ✅ 4 Roboflow datasets, ~17K images | Good seed |
| NO-Bakery-Head-Cap (11) | ✅ Same datasets (violation class) | Good seed |
| Bangles (12) | ⚠️ Very limited (~200–400 images) | Weak — Phase 1 will fix |
| Document-in-hand (13) | ⚠️ Limited (~300 images) | Weak — Phase 1 will fix |

### Output
`ppe_factory_v0.pt` — **Do NOT deploy to production.** Use for testing only.
The real production model comes from Phase 1 with client footage.

### Before running
1. Kaggle account + GPU T4 x2 enabled
2. Roboflow API key (free at roboflow.com → Account → Settings)
3. Upload `ppe.pt` to Kaggle as Dataset named `ppe-base-weights`

### Model replacement rule
```
ppe.pt (backup, never touch)
  └→ ppe_factory_v0.pt (seed, dev/test only — today's output)
       └→ ppe_factory_v1.pt (production v1 — Phase 1 output)
            └→ ppe_factory_v2.pt (production v2 — Phase 3 output)
```

---
---

# PHASE 1 — Weeks 1–4 (Priority 4 Classes + OCR Gate)
## `phase1_core_ppe/`

**Goal:** Fine-tune with client footage on the 4 most critical classes:
`Bakery-Head-Cap`, `NO-Bakery-Head-Cap`, `Bangles`, `Document-in-hand`

**+ Build the invoice entry-gate system using OCR.**

### Why these 4 first
- Head cap is the **#1 PPE requirement** for all 3 floors
- Bangles are an absolute violation in food production — zero tolerance
- Document-in-hand enables the **inward/outward invoice gate** the client explicitly asked for — "they need to show the invoice to the camera"
- These 4 have the clearest visual signal and the most client footage available

### Step 1 — Frame Extraction (Run Locally)
`frame_extraction.ipynb` — run on your machine when client footage arrives

```
Footage arrives → extract_frames.ipynb → organized frames/
                                          ├── entrance/     ← document + person
                                          ├── dough_table/  ← head cap focus
                                          ├── packing/      ← bangles + head cap
                                          └── shop/         ← document + cashbox
```

**Extraction rates (per zone):**
| Zone | Every N frames | Effective FPS |
|---|---|---|
| Entrance | 8 | ~3 fps — document events are brief |
| Shop counter | 8 | ~3 fps — fast hand movements |
| Packing | 15 | ~2 fps — hand detail needed |
| Dough/Oven | 25 | ~1 fps — slow activity |
| All others | 25 | ~1 fps |

### Step 2 — Annotation (Roboflow or CVAT)

**Minimum counts before training:**

| Class | Minimum | Notes |
|---|---|---|
| Bakery-Head-Cap | 300+ | Combine public seed + client footage |
| NO-Bakery-Head-Cap | 300+ | **Critical paired class** — annotate same sessions |
| Bangles | 150+ | Rare event — augment heavily (flip, brightness, crop) |
| Document-in-hand | 250+ | High pose variance — annotate different angles/holds |

**Annotation tool choice:**
- **Roboflow** (recommended) — free tier, browser, exports YOLOv8, built-in augmentation
- **CVAT** (if on-premise required) — self-hostable, footage stays local

**Key annotation rule:**
> Annotate `Bakery-Head-Cap` AND `NO-Bakery-Head-Cap` in the SAME session from the SAME footage.
> Without the NO- class the model learns what a cap looks like but has nothing to compare against — it will never fire a cap-missing alert.

### Step 3 — Train on Kaggle
`phase1_kaggle_training.ipynb`

- Base: `ppe_factory_v0.pt` (today's seed, or `ppe.pt` if seed wasn't good)
- Freeze: first 10 layers (protects original classes)
- Epochs: 100 with early stopping at patience=25
- Output: **`ppe_factory_v1.pt`** → deploy to backend

### OCR Invoice Gate (Built in parallel — no model training needed)

When `Document-in-hand` (class 13) is detected at the **entrance zone**:

```
Person enters → shows invoice to camera
     ↓
YOLO detects Document-in-hand (class 13)
     ↓
EasyOCR extracts text from bounding box crop
     ↓
Rule engine checks:
  - Is text present? (len > 10 chars = basic check)
  - Does it match known invoice patterns? (invoice no, date, vendor)
     ↓
APPROVED → log + let person through
DENIED   → alert + sound alarm + snapshot saved
```

**Inward flow:** Person shows invoice → OCR reads it → stores invoice number + goods count + weight (if visible) → APPROVED entry

**Outward flow:** Person shows order form → OCR reads it → stores form info + photo of person → APPROVED exit

**OCR limitation to tell client:**
- Works well with printed/typed documents
- Handwritten forms = lower accuracy → recommend Phase 2 upgrade
- Document must be held still for at least 2 seconds for clean OCR
- Poor lighting (pre-shift 5 AM on 2nd floor) = OCR accuracy drops → add a ring light at entrance if possible

### Phase 1 — What gets deployed
- ✅ `ppe_factory_v1.pt` in backend (head cap + bangles + document detection)
- ✅ OCR entry gate live at entrance camera
- ✅ Dress code alerts (NO-Bakery-Head-Cap = immediate alert)
- ✅ Bangles violation alerts
- ✅ Document-in-hand logging with text extraction

---
---

# PHASE 2 — Weeks 3–6 (Rule Engine — No Model Training)
## `phase2_rule_engine/`

**Goal:** Build all behavioral and temporal monitoring using the existing model output + ByteTrack tracking. Zero model training needed here — this is pure engineering.

> This phase runs IN PARALLEL with Phase 1 annotation. While you're collecting and labeling footage, Phase 2 can be fully built and tested.

### What gets built

| Feature | How | Zone |
|---|---|---|
| **Idle > 5 min alert** | ByteTrack centroid timer | All floors |
| **Idle > 1 min in shop** | Zone occupancy check (Person count = 0) | Shop |
| **Standing in front of camera > 1 min** | BBox overlap with camera polygon + timer | All |
| **Shift-start time checks** | Clock check (8 AM ground, 6 AM first, 5 AM second) | All |
| **Packing section — hands must move** | Optical flow on wrist keypoints (YOLOv8-Pose) or frame diff | Ground (packing) |
| **Dough section — must move after job** | Track centroid → if stationary after machinery stops = alert | Ground (dough) |
| **Biscuit cutting — must start when machine starts** | Machinery detection + Person presence timer | Ground (biscuit) |
| **Camera down alert** | Frame-diff near-zero or RTSP timeout check | All |
| **Loading/unloading gate** | `vehicle` + `Person` classes already in ppe.pt | Ground entrance |
| **Employee absent from shop > 1 min** | Zone occupancy = 0 for > 60s | Shop |

### Idle timer rule engine

```python
IDLE_LIMIT_SEC = {
    "default":         300,   # 5 min — all floors general rule
    "camera_standing":  60,   # 1 min — blocking camera
    "shop_counter":     60,   # 1 min — absent from shop
    "gas_idle":        600,   # 10 min — stove/oil idle (Phase 4)
}
```

### Shift-start checks (zero ML)

```python
SHIFT_START = {
    "ground_floor":  "08:00",   # Work starts 8 AM
    "first_floor":   "06:00",   # Dough mixing starts 6 AM
    "second_floor":  "05:00",   # Starts 5 AM
}
```

---
---

# PHASE 3 — Weeks 6–8 (Remaining Object Classes)
## `phase3_object_classes/phase3_kaggle_training.ipynb`

**Goal:** Add the 3 remaining object classes to `ppe_factory_v1.pt` → produce `ppe_factory_v2.pt`.

### Classes added in this phase

| Class | Min Images Needed | Where to Find in Footage |
|---|---|---|
| Cylinder (14) | 100+ | First floor — near stove/storage |
| Exposed-Item (15) | 150+ | All floors — stock kept on open shelves |
| Cashbox (16) | 100+ | Shop counter only |

### Why these 3 are Phase 3 (not Phase 1)
- No public data exists for any of these
- All 3 are **zone-specific** objects with low visual variance — easier to annotate but need your own footage
- The client cares more about head caps + bangles + OCR gate first
- Phase 1 must prove value before spending annotation time on these

### Stock monitoring logic (built alongside Phase 3 model)
- `Exposed-Item` detected → log zone + timestamp → alert if persistent > 2 hours
- `Cylinder` detected → increment usage counter per day → alert if daily count exceeds threshold
- `Cashbox` detected near shop zone → anchor for cash-goes-to-pocket detection (Phase 4)

---
---

# PHASE 4 — Weeks 7–9 R&D (Hard Problems)
## `phase4_hard_problems/`

> These are R&D problems. Set honest expectations with client before starting.
> These cannot be promised as "it will work" — they are best-effort.

### Chewing Detection — MediaPipe Face Mesh

**NOT a YOLO problem.** Do NOT annotate bounding boxes for "chewing."

```python
import mediapipe as mp

mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=False, max_num_faces=4, min_detection_confidence=0.5
)

# Mouth aspect ratio (MAR) — same principle as EAR for drowsiness
# Landmarks: upper lip (13), lower lip (14), left corner (61), right corner (291)
# MAR > 0.5 for > 0.5 seconds consecutively = chewing detected → alert

def mouth_aspect_ratio(landmarks, frame_w, frame_h):
    def pt(idx): return (int(landmarks[idx].x * frame_w), int(landmarks[idx].y * frame_h))
    top, bot = pt(13), pt(14)
    left, right = pt(61), pt(291)
    vertical   = ((top[0]-bot[0])**2 + (top[1]-bot[1])**2) ** 0.5
    horizontal = ((left[0]-right[0])**2 + (left[1]-right[1])**2) ** 0.5
    return vertical / (horizontal + 1e-6)
```

**Expected accuracy:** ~70–80% in good lighting, face visible, not masked.
**Limitation:** Will not work with mask on. Will not work > 4 meters from camera.

### Clean-Shave Detection — Face Attribute Classifier

- Phase 4 R&D — requires a face crop + a lightweight CNN classifier (beard vs no-beard)
- Public dataset: CelebA has beard attribute labels — can fine-tune MobileNetV2
- Not a YOLO task

### Dirty Floor — Frame Difference vs Client Baseline

- **Requires client to provide clean-state photos of each zone/camera view**
- One photo per camera angle, taken after morning cleaning
- Code is already designed in `bakery_cv_plan.md` Section 9.6
- No model training needed

### Gas/Flame Idle — D-Fire Pre-Trained Model

- Download: https://github.com/gaiasd/DFireDataset
- Run as **separate inference pass on 2nd floor stove camera only**
- D-Fire model detects fire/smoke — if fire ON + no person for > 10 min → alert
- Expected accuracy: ~85% precision for open flame. Steam/vapor: 40–60% recall only.
- **Recommend IoT gas sensor as hardware backup** for reliable monitoring

### Eating from Store / Theft Detection

- Hand-to-mouth proximity heuristic using YOLOv8-Pose wrist keypoints + Person bbox
- If wrist comes within 30px of mouth region 3+ times in 5 seconds = eating detected
- Object near window + fast trajectory leaving frame = potential throw/pass alert
- Best-effort accuracy: ~55–65%. Not suitable for disciplinary action alone.

---
---

## 🚫 What NOT to train as YOLO classes (ever)

| Requirement | Why NOT YOLO | Real Solution |
|---|---|---|
| Chewing | Requires temporal lip movement, not a static object | MediaPipe Face Mesh MAR |
| Dirty floor | Dirt is not a consistent object — no bounding box | Frame-diff vs baseline (Phase 4) |
| Gas flame | Annotation burden is very high for poor v1 gain | D-Fire pre-trained (Phase 4) |
| Cash in pocket | 3-frame action, not a static object | Hand trajectory (Phase 4, ~55% accuracy) |
| Clean-shaved | Face attribute, not object detection | CNN classifier (Phase 4) |
| Big hair | Extremely subjective | Face attribute (optional) |

---

## 🔑 Model Deployment Chain

```
NEVER DO THIS:
  ppe.pt ← overwrite ← DON'T TOUCH

CORRECT CHAIN:
  ppe.pt
    └─ Phase 0 fine-tune → ppe_factory_v0.pt   (dev/test, not production)
         └─ Phase 1 fine-tune → ppe_factory_v1.pt  ← PRODUCTION after Phase 1
              └─ Phase 3 fine-tune → ppe_factory_v2.pt  ← PRODUCTION after Phase 3
```

**To switch model in backend — edit ONE line only:**
```python
# backend/config.py
YOLO_MODEL: str = "ppe_factory_v1.pt"   # after Phase 1
YOLO_MODEL: str = "ppe_factory_v2.pt"   # after Phase 3
```

---

## 📋 Weekly Checklist

### Week 1 — Today + client footage arrives
- [x] Run `phase0_public_seed/phase0_kaggle_seed.ipynb` → get `ppe_factory_v0.pt`
- [ ] Receive client footage
- [ ] Run `phase1_core_ppe/frame_extraction.ipynb` locally
- [ ] Start Roboflow project for: Bakery-Head-Cap, NO-Bakery-Head-Cap, Bangles, Document-in-hand
- [ ] Start Phase 2 rule engine backend code (idle timers, shift checks)

### Week 2
- [ ] Annotate 100+ images per class (at minimum)
- [ ] Continue Phase 2 rule engine
- [ ] Set up EasyOCR pipeline in backend for entrance gate

### Week 3
- [ ] Hit minimum annotation counts (300 head cap, 150 bangles, 250 document)
- [ ] Run `phase1_core_ppe/phase1_kaggle_training.ipynb` → get `ppe_factory_v1.pt`
- [ ] Deploy v1 to backend

### Week 4
- [ ] Test v1 in live environment
- [ ] Validate per-class mAP (check old classes not degraded)
- [ ] OCR gate live at entrance
- [ ] Phase 2 rule engine deployed (idle/shift/camera alerts)

### Week 5-6
- [ ] Continue collecting footage for Phase 3 classes (cylinder, exposed-item, cashbox)
- [ ] Annotate Phase 3 classes

### Week 7-8
- [ ] Run `phase3_object_classes/phase3_kaggle_training.ipynb` → get `ppe_factory_v2.pt`
- [ ] Deploy v2 to backend
- [ ] Start Phase 4 R&D (chewing MediaPipe, dirty floor detector)

### Week 9+
- [ ] FCM mobile notifications integration
- [ ] Dashboard polish
- [ ] Data security + on-premise hardening
- [ ] Final end-to-end test with client

---

## ❓ FAQs

**Q: Bangles has no public data — what if client footage has very few bangle instances?**
→ Use Roboflow augmentation heavily (8x augmentation: flip, brightness ±40%, rotation ±15°, crop). Also explicitly ask client: "Can someone wear bangles intentionally for 20 minutes of filming so we have training data?" This is standard practice.

**Q: Document-in-hand — what if person doesn't hold document still?**
→ OCR requires at least 2 frames of stillness. Add a "hold still for 2 seconds" instruction near the entrance camera. For v1 this is acceptable.

**Q: What about uniform (dress code) monitoring?**
→ `Safety Vest` class in original ppe.pt is a partial proxy. Full bakery uniform detection (white apron/coat) requires Phase 1 annotation — add it as a stretch goal during head cap annotation since people appear in full uniform anyway.

**Q: What about lift monitoring?**
→ `Person` class (already in ppe.pt) + zone polygon for lift area + entry/exit counter. No new class needed.

**Q: What about vendor payment photo capture (shop)?**
→ Rule engine: when `Person` detected in shop counter zone + cash-area event → auto-capture snapshot → save to DB. No model training needed.
