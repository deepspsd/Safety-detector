# Phase 4 — Hard Problems (R&D)

> These are best-effort features. Set honest client expectations before starting.
> None of these should be promised with a fixed accuracy number.

---

## 1. Chewing Detection — MediaPipe Face Mesh

**NOT YOLO. Do not annotate bounding boxes for this.**

```bash
pip install mediapipe
```

**How it works:**
- Face Mesh gives 468 landmark points per face
- Track lip landmarks over time
- If Mouth Aspect Ratio (MAR) > 0.5 for > 0.5 sec consecutively = chewing alert

**Expected accuracy:** ~70-80% (good lighting, face visible, no mask)
**Fails when:** mask worn, person >4m from camera, low light (5 AM shift)

---

## 2. Dirty Floor Detection — Frame Difference

**NOT YOLO. Uses OpenCV frame-difference vs client baseline photo.**

**What you need from client:**
1. One photo per camera angle taken after morning cleaning
2. One photo per lighting condition (lights-off 5 AM vs lights-on 6 AM)

**Accuracy:** ~75-85% for obvious debris/spills. Misses gradual grime.
**False positive source:** Workers walking through zone → use 5-consecutive-frame streak filter.

---

## 3. Gas/Flame Idle > 10 min — D-Fire Model

**Separate inference pass on 2nd floor stove camera only.**

```bash
# Download D-Fire pre-trained weights
# https://github.com/gaiasd/DFireDataset
```

**Expected accuracy:** ~85% for open flame. Steam/vapor: 40-60% recall.
**Recommendation:** Pair with IoT gas sensor as hardware fallback.

---

## 4. Eating from Store / Dry Fruits

- Wrist keypoint (YOLOv8-Pose) proximity to mouth region
- If wrist < 30px from mouth 3+ times in 5 seconds = eating alert
- Best-effort accuracy: ~55-65%

---

## 5. Cash-in-Pocket Detection (Shop)

- Hand trajectory from cashbox area → toward body/pocket
- 3-5 frame window action recognition
- Best-effort accuracy: ~50-60%
- **Recommend pairing with cashbox-open hardware sensor for reliability**

---

## 6. Throwing Items Through Windows

- Fast object trajectory leaving frame near window polygon
- Motion vector analysis using optical flow
- Alert if object velocity > threshold near window zone

---

## 7. Clean-Shave Detection (Optional)

- Face crop + MobileNetV2 binary classifier (beard vs clean-shaved)
- Public dataset: CelebA (beard attribute label available)
- Not a YOLO task

---

## Timeline for Phase 4

Start Phase 4 in parallel with Phase 3 (Week 7 onwards).
MediaPipe chewing detector and dirty floor detector can be built without any model training.
D-Fire model just needs to be downloaded and plugged in.
