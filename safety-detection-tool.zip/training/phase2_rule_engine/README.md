# Phase 2 — Rule Engine (No Model Training)

## What this phase is

Pure backend engineering. No Kaggle, no annotation, no model.
Can be built WHILE Phase 1 annotation is happening — run in parallel.

## Features to implement

| Feature | File to edit | Status |
|---|---|---|
| Idle > 5 min alert (all floors) | `backend/services/idle_service.py` | ✅ DONE |
| Idle > 1 min in shop | `backend/services/idle_service.py` | ✅ DONE |
| Standing in front of camera > 1 min | `backend/services/idle_service.py` | ✅ DONE |
| Shift-start time checks (8AM/6AM/5AM) | `backend/services/yolo_service.py` | ⬜ TODO |
| Packing hands-in-motion check | `backend/services/yolo_service.py` | ⬜ TODO |
| Camera down / feed lost alert | `backend/services/camera_manager.py` | ✅ DONE |
| OCR entry gate live | `backend/services/ocr_service.py` | ✅ DONE |
| Employee absent from shop > 1 min | `backend/services/idle_service.py` | ✅ DONE |
| Loading/unloading at entrance (vehicle) | already in ppe.pt | ✅ DONE |

## Key constants (edit these per deployment)

```python
# backend/config.py

IDLE_LIMITS = {
    "default":          300,   # 5 min — all floors
    "shop":              60,   # 1 min — absent from shop / shop counter
    "camera_standing":   60,   # 1 min — blocking camera
    "cashbox":          120,   # 2 min — cash box idle
}

IDLE_MOVEMENT_THRESHOLD_PX = 8  # Min centroid shift in px to reset timer
```

## OCR gate — what was built (✅ DONE)

### New files

| File | Purpose |
|---|---|
| `backend/services/ocr_service.py` | Main OCR engine |

### New DB tables (added to `backend/database.py`)

| Table | When populated |
|---|---|
| `invoice_logs` | `direction="inward"` + `approved=True` |
| `order_form_logs` | `direction="outward"` + `approved=True` |

### How the trigger works

```
yolo_service._run_pipeline()
  └─ detects "Document-in-hand" (class 13) in raw detections
       └─ checks centroid is inside "entrance" zone polygon
            └─ calls ocr_service.scan_document_in_frame(frame, bbox, direction)
                 ├─ approved=True  → save InvoiceLog / OrderFormLog to DB
                 └─ approved=False → save high-severity REVIEW alert via alert_service
```

### OCR function signature

```python
from services.ocr_service import scan_document_in_frame

result = scan_document_in_frame(
    frame=frame_numpy,    # BGR numpy array
    bbox=[x1, y1, x2, y2],
    direction="inward",   # "inward" | "outward"
)
# result keys: approved, raw_text, timestamp, direction, snapshot_b64, ocr_available
```

### How to supply entrance-zone context to the pipeline

`_run_pipeline` (and the two public wrappers) accept optional OCR kwargs:

```python
from services.yolo_service import process_frame_numpy

result = process_frame_numpy(
    frame=frame,
    role="Factory Worker",
    # OCR gate kwargs — only needed for entrance cameras
    ocr_zone_config={"entrance": [[10,20],[640,20],[640,480],[10,480]]},
    ocr_direction="inward",          # "inward" | "outward"
    ocr_db_session=db_session,       # SQLAlchemy Session
    ocr_camera_id=camera_id,         # cameras.id FK
    ocr_user_id=current_user.id,     # for alert user_id
)
```

When `ocr_zone_config=None` (the default), the OCR block is skipped entirely
with zero overhead — existing callers are unaffected.

### Approval heuristics (v1 — deliberately lenient)

| Direction | Passes if |
|---|---|
| `inward` | OCR text contains ≥3 consecutive digits, a date pattern, an INR/$ amount, or an INV/PO/ORD/REF prefix |
| `outward` | Same patterns (same heuristic v1; differentiate in v2 after collecting real order-form samples) |

> **Important:** `raw_ocr_text` is **always stored** in the DB log regardless
> of approval outcome. Admins can review misfire cases in `invoice_logs` /
> `order_form_logs`.

### ⚠️ Hardware gate disclaimer (explicit — do not remove)

`approved=True` / `approved=False` is a **logged compliance check result only**.
There is **no hardware actuator** connected to this system.
The "entrance gate" is a software alert + DB log — not a physical lock.
A human operator must review the dashboard alert and take physical action.

### System requirements for OCR

```bash
# Install Tesseract OCR binary FIRST (before pip install)
# Windows: winget install UB-Mannheim.TesseractOCR
# Linux:   sudo apt install tesseract-ocr

# Then install the Python wrapper
pip install pytesseract>=0.3.10

# Optional (for zone polygon check)
pip install shapely>=2.0.0
```

If Tesseract is not installed: `ocr_service` degrades gracefully —
`approved=False`, `raw_text="[OCR_UNAVAILABLE]"`, REVIEW alert fired.
The pipeline never crashes on a missing Tesseract binary.

## ByteTrack & Persistent Idle Tracking — what was built (✅ DONE)

### Architecture overview

```
camera_manager._ManagedCamera._detection_loop()
  │
  ├─ yolo_service.process_frame_numpy_tracked(frame, role, camera_id)
  │     │
  │     ├─ ByteTrack (supervision) per camera_id -> assigns stable track_id
  │     └─ Attach track_id to each Person detection dict
  │
  └─ idle_service.process_frame(camera_id, persons, zone_name)
        │
        ├─ Compute centroid for each track_id
        ├─ Track centroid history & check movement >= IDLE_MOVEMENT_THRESHOLD_PX
        ├─ If idle > IDLE_LIMITS[zone_name]:
        │     ├─ Open/update IdleSession row in DB
        │     └─ Fire system alert via save_alert()
        └─ When person moves or leaves frame -> Close IdleSession DB row
```

### Features & Guarantees

1. **Per-Camera ByteTrack instances**: Trackers are isolated per `camera_id` in `yolo_service._trackers` registry.
2. **Persistent Daemon Execution**: The detection loop runs continuously inside `camera_manager.py` at ~5 fps. Idle monitoring continues even when zero browser tabs are connected.
3. **Automatic IdleSession Lifecycle**:
   - `start_time` set when idle threshold exceeded.
   - `end_time` & `duration_seconds` set when track moves or disappears.
4. **Non-blocking PPE Integration**: `track_id` flows transparently through `_associate_to_persons` without altering existing PPE or violation detection logic.

## No notebook needed for this phase — all Python backend work.

---

## Telegram Notifications — Setup (5 min, completely free)

> No paid API. No cloud infra. Just a free Telegram bot.
> All that leaves the server: alert text + snapshot JPEG (≤100 KB).
> Raw video is **never** transmitted to Telegram.

### Step-by-step

1. Open Telegram on your phone → search **@BotFather** → tap Start
2. Send `/newbot` → follow the name prompts
3. BotFather gives you an API token: `123456:ABCdefGHIjklMNOpqrsTUVwxyz`
4. **Add the bot to your group chat** (the group your staff/admins are in):
   - Open the group → Add members → search your bot's username
5. Send any message in the group (so the bot has a chat to post to)
6. Find your **chat_id** by visiting:
   ```
   https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates
   ```
   Look for `"chat":{"id": -100123456789}` in the response.
   Group chat IDs are **negative numbers**.

7. Add to your `.env` file (in the `backend/` directory):
   ```env
   TELEGRAM_BOT_TOKEN=123456:ABCdefGHIjklMNOpqrsTUVwxyz
   TELEGRAM_CHAT_ID=-100123456789
   ```

8. Restart the server. Test the connection:
   ```bash
   # Requires admin login token (Bearer)
   curl -X POST http://localhost:8000/alerts/test-telegram \
        -H "Authorization: Bearer <token>"
   ```
   You should see the test message appear in your Telegram group instantly.

### What gets sent

| Alert type | Sent to Telegram? |
|---|---|
| PPE violation, head-cap, idle, shift-late, shop-absence, cylinder-swap | ✅ Immediately |
| Dirty floor, gas-idle (Phase 4 heuristics) | ❌ Pending review only |
| After admin confirms a pending alert | ✅ Sent at that point |
| Admin dismissed (false positive) | ❌ Never sent |

---

## Confidence-Tier Routing — Alert Status

Every `Alert` row now has a `status` column:

| Status | Meaning | Telegram |
|---|---|---|
| `confirmed` | High-confidence detector fired | ✅ Sent immediately |
| `pending_review` | Phase 4 heuristic (low confidence) | ❌ In-app only |
| `dismissed` | Admin decided false positive | ❌ Never sent |

### High-confidence detectors (→ `confirmed` automatically)
- PPE: NO-Hardhat, NO-Gloves, NO-Mask, NO-Safety-Vest
- Bakery-Head-Cap / NO-Bakery-Head-Cap *(once model v2 trained)*
- Bangles *(Phase 3)*
- Idle > threshold (ByteTrack + timer)
- Late shift start
- Shop unattended > 60 s
- Cylinder swap detected
- Camera down / feed lost

### Low-confidence detectors (→ `pending_review`)
| Detector | Expected accuracy | Notes |
|---|---|---|
| Dirty floor (frame-diff) | 70-85% | False-positive from shadows, steam |
| Gas/oven idle (motion) | 40-60% | Steam fools frame-diff; Phase 4 |
| Chewing detection *(future)* | 70-80% | MediaPipe-based, Phase 4 |
| Eating at workstation *(future)* | 55-65% | Pose + object, Phase 4 |
| Cash-in-pocket *(future)* | 50-60% | Trajectory heuristic, Phase 4 |

### API endpoints

```
GET  /alerts/?status=confirmed       → main confirmed feed (default)
GET  /alerts/?status=pending_review  → admin review queue
GET  /alerts/pending                 → shortcut for review queue
GET  /alerts/?status=all             → everything

PATCH /alerts/{id}/confirm           → promote pending → confirmed + fire Telegram
PATCH /alerts/{id}/dismiss           → mark as false positive
```

### How to call `save_alert()` with explicit tier

```python
from services.alert_service import save_alert

# High-confidence → confirmed + Telegram (default behaviour)
save_alert(db, user_id=1, message="...", ..., confidence_tier="high")

# Low-confidence → pending_review (no Telegram until admin confirms)
save_alert(db, user_id=1, message="...", ..., confidence_tier="low")

# Auto-detect from detected_issue string (backward-compatible default)
save_alert(db, user_id=1, message="...", detected_issue="Dirty floor detected")
# ^ Auto-detected as "low" because "Dirty floor detected" is in _LOW_CONFIDENCE_ISSUES
```
