## Bakery AI Surveillance & Compliance System

Technical Implementation Plan — YOLOv8 Fine-Tuning, Dataset Strategy, Tracking & Rule Engine, Deployment

Prepared for: Deepak (Project Owner) | Base models: ppe.pt, helmet_model.pt (Safety-Detection-YOLOv8) | Client: Bakery multi-floor facility

## 1. Scope Interpretation — What the Client Actually Asked For

The client requirement document maps to four monitoring zones — Ground Floor, First Floor, Second Floor, and Shop — plus a global dashboard/security requirement. Before touching any model, the requirement must be split into three technically distinct problem types, because a single fine-tuned YOLO model cannot solve all of them:

| Problem Type | Definition | Solved By |
| --- | --- | --- |
| Object / PPE Detection | Is X present | YOLOv8 |
|   | or absent in a | detection |
|   | frame | (fine-tuned) |
|   | (hardhat, |   |
|   | vest, cap, |   |
|   | bangles, |   |
|   | vehicle, |   |
|   | document) |   |
| Temporal / Behavioral | Idle time, | Object |
|   | standing | tracking |
|   | duration, | (ByteTrack) + |
|   | work-start | rule engine |
|   | compliance, | (Python, no |
|   | camera | ML) |
|   | downtime |   |
| Action / State Recognition | Chewing, ha | MediaPipe |
|   | nds-in-motion | landmarks / |
|   | vs idle, | frame-diff |
|   | boiling | heuristics + |
|   | water/oil idle | rules |

This distinction is important to set correct client expectations: only the first category is a "fine-tune the model" task. The rest is application logic built on top of detection + tracking output.

## 2. System Architecture

```
Camera Feed (RTSP/USB)
|
v
YOLOv8 Inference --(ppe.pt + custom fine-tuned weights)
|
v
ByteTrack / BoT-SORT --(built into Ultralytics, gives persistent track IDs)
|
v
Zone Mapper --(per-camera polygon zones: dough table, oven, packing, shop counter...)
|
v
Rule Engine --(idle timers, entry/exit logic, dress-code checks, time-of-day checks)
|
```


## 3. Existing Model Audit

## 3.1 ppe.pt — classes already available

| ID | Class | Type | Client requirement it covers |
| --- | --- | --- | --- |
| 0 | Hardhat | Compliant | Head cap monitoring (proxy, |
|   |   |   | needs bakery-cap fine-tune) |
| 1 | Mask | Compliant | Not explicitly asked, useful |
|   |   |   | bonus for hygiene |
| 2 | NO-Hardhat | Violation | Head cap violation alert |
| 3 | NO-Mask | Violation | Bonus |
| 4 | NO-Safety Vest | Violation | Uniform violation (partial — vest |
|   |   |   | bakery uniform) |
| 5 | Person | Neutral | Base for all tracking / idle logic |
| 6 | Safety Cone | Neutral | Not needed, ignore |
| 7 | Safety Vest | Compliant | Uniform proxy |
| 8 | machinery | Neutral | Dough mixer / biscuit cutter / |
|   |   |   | oven zone anchor |
| 9 | vehicle | Neutral | Loading/unloading monitoring at |
|   |   |   | main entrance |

helmet_model.pt: redundant with classes 0/2 above. Only worth using if a side-by-side accuracy test on bakery cap footage shows it outperforms ppe.pt's Hardhat class — bakery caps are visually different from construction hardhats (soft cloth vs rigid shell), so verify before deciding, don't assume.


## 4. Requirement-by-Requirement Gap Analysis

## 4.1 Ground Floor

| Requirement item | Feasibility | How |
| --- | --- | --- |
| Invoice scan at entry (inward) / order form scan | Medium | Object detect "document-in-hand" class + OCR |
| (outward) |   | (Tesseract/PaddleOCR) — new class needed, no public |
|   |   | dataset |
| Work start by 8 AM | Easy | Timestamp rule, zero ML |
| Dough mixing / biscuit cutting / oven / packing | Easy | Zone-anchored Person + machinery detection, already in |
| zone monitoring |   | ppe.pt |
| Glassdoor entry attendance + stock movement | Medium | Person track count at zone + custom "stock item" class |
| Loading/unloading at entrance | Easy | Vehicle + Person classes already in ppe.pt |
| Floor cleanliness (3 floors) | Hard | Subjective — recommend simple "debris/clutter" binary |
|   |   | classifier as v1, manual audit fallback |
| Head cap / uniform / clean-shaved / haircut / | Mixed | Cap+uniform = fine-tune. Clean-shave/haircut = |
| chewing |   | subjective, deprioritize. Chewing = MediaPipe Face Mesh |
|   |   | mouth-aspect-ratio, not YOLO |
| Employee idle > 5 min | Easy | ByteTrack ID + centroid-stationary timer |
|   | (engineering) |   |

## 4.2 First Floor

| Requirement item | Feasibility | How |
| --- | --- | --- |
| Dough mixing start by 6 AM (4 tables) | Easy | Timestamp + zone rule |
| Lift monitoring (all 3 floors) | Medium | Person detection at lift zone + item-in-lift class |
| Cylinder usage / usage-day count | Medium | New "cylinder" class + presence-duration logging |
| Items not kept openly / cleanliness / items in-out of | Hard/Medium | Custom "exposed item" class + zone logic; cleanliness |
| lift |   | same caveat as above |

## 4.3 Second Floor

| Requirement item | Feasibility | How |
| --- | --- | --- |
| Work starts by 5 AM | Easy | Timestamp rule |
| Gas/flame on, water boiling >10 min idle, oil idle | Hard | Needs flame/steam visual cue + timer; recommend |
| >10 min |   | heuristic v1 (flame-on duration), refine later with thermal |
|   |   | camera if budget allows |
| No eating store goods / dry fruits | Medium | Hand-to-mouth + food-item proximity heuristic, imperfect |
|   |   | — flag as best-effort |
| Theft / throwing items through windows | Medium | Motion-trajectory anomaly at window zones (fast object |
|   |   | leaving frame near window polygon) |
| Camera down alert | Easy | Feed heartbeat / frame-diff-zero check, zero ML |
| Standing in front of camera >1 min | Easy | Track + bbox-overlap-with-camera-zone timer |
|   | (engineering) |   |


## 4.4 Shop

| Requirement item | Feasibility | How |   |   |
| --- | --- | --- | --- | --- |
| Cash handling (not pocketed) | Hard | Hand-trajectory: cash | cashbox vs cash | pocket. |
|   |   | Needs custom pose/action dataset, low accuracy |   |   |
|   |   | expected v1 |   |   |
| Vendor payment photo capture | Easy | Trigger snapshot on detected hand-off event near counter |   |   |
|   |   | zone |   |   |
| Employee idle time in shop | Easy | Same tracking timer logic as other floors |   |   |
| Employee absent from shop >1 min | Easy | Zone-occupancy check, alert if Person count in "shop" |   |   |
|   |   | zone = 0 |   |   |


## 5. New Classes To Add On Top of ppe.pt (IDs 10+)

| ID | New Class | Priority | Data Source |
| --- | --- | --- | --- |
| 10 | Bakery-Head-Cap (cloth cap, not hardhat) | P1 | Client footage + hairnet public datasets (sec. 6) |
| 11 | NO-Bakery-Head-Cap | P1 | **Critical — paired violation class for ID 10.** Annotate from the same sessions as ID 10. Without this class the rule engine has no signal for cap-missing alerts. |
| 12 | Bangles | P1 | Client footage only — no public dataset exists |
| 13 | Document-in-hand (invoice/order form) | P1 | Client footage, ~200-300 crops, high visual variance so augment heavily |
| 14 | Cylinder | P2 | Client footage, low variance object, easy to annotate |
| 15 | Exposed-Item (stock kept openly) | P2 | Client footage |
| 16 | Cashbox | P2 | Client footage |

Keep IDs 0-9 untouched and append new classes starting at 10 — this preserves the pretrained ppe.pt weight alignment when fine-tuning (see Section 8, freeze-layer strategy). Total after extension: **17 classes**.

## 6. Public Datasets To Use (Seed Data — Supplement, Not Replace, Client Footage)

None of these fully solve the bakery-specific classes. Use them to pre-train/seed the head-cap and uniform classes for faster convergence, then dominant training signal must come from the client's own 15-day footage.

| Dataset | Relevance | Link |
| --- | --- | --- |
| SHEL5K (Safety Helmet, 5K images, 6 | Head cap/hardhat baseline, robustness | github.com/MoyoG/SHEL5K |
| classes) |   |   |
| Hairnet Detection (Prince Suman, | Closest analog to bakery cloth cap — | universe.roboflow.com/prince-suman-3oh |
| Roboflow, 3.5K imgs) | direct fit | wu/hairnet-detection-vktcj |
| mask + hairnet + smock-coat ("Safety | Best match: food-industry uniform + | universe.roboflow.com (search "Safety |
| Food System", 9.9K imgs) | headcap combined | Food System hairnet") |
| Coverall/Gloves/Goggles/Hairnet/Mask | Food-grade PPE, multi-class | universe.roboflow.com (search "EPP |
| /Shoe-Cover (EPP Internship, 4.3K |   | Internship hairnet") |
| imgs) |   |   |
| Cap and Hairnet Material | Small but bakery-cap-specific | universe.roboflow.com/tshirtsvariations/ca |
| (tshirtsvariations, 374 imgs) |   | p-and-hairnet-material |
| CPPE-5 (Medical PPE, | Extra mask/uniform variance if needed | huggingface.co/datasets/cppe-5 |
| masks/gloves/gowns) |   |   |

Search tip on Roboflow Universe: universe.roboflow.com/search?q=class:hairnet — this returns a live, continuously updated list; check it again before finalizing since new datasets get published frequently. Bangles, cylinders, invoice/order-forms, cashbox, exposed-items have no usable public dataset — 100% dependent on client's 15-day footage + manual annotation.


## 7. Client Footage Annotated Dataset Pipeline

## 7.1 Frame extraction

```python
import cv2, os

# Zone-adaptive sample rates (frames to skip between saves)
# Adjust based on actual camera FPS (assume 25-30 fps)
ZONE_SAMPLE_RATES = {
    "entrance":    8,   # ~3 fps — events are brief (document flash)
    "shop_counter": 8,  # ~3 fps — fast hand movements
    "dough_table": 25,  # ~1 fps — slow static activity
    "oven":        25,  # ~1 fps — flame/stove rarely changes
    "packing":     15,  # ~2 fps — hand movement needed
    "default":     25,  # ~1 fps for all other zones
}

def extract_frames(video_path, out_dir, zone="default"):
    every_n_frames = ZONE_SAMPLE_RATES.get(zone, ZONE_SAMPLE_RATES["default"])
    os.makedirs(out_dir, exist_ok=True)
    cap = cv2.VideoCapture(video_path)
    i, saved = 0, 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if i % every_n_frames == 0:
            cv2.imwrite(f"{out_dir}/frame_{saved:05d}.jpg", frame)
            saved += 1
        i += 1
    cap.release()
    print(f"Saved {saved} frames from {video_path} (zone={zone}, skip={every_n_frames})")

# Example: run per camera per day across the 15-day archive
# extract_frames("ground_floor/entrance_cam.mp4", "frames/entrance", zone="entrance")
# extract_frames("second_floor/oven_cam.mp4",     "frames/oven",     zone="oven")
```

Prioritize frames spanning different times of day / lighting — bakery has bright oven-area light vs dim storage areas. Capture night-shift footage separately if shift starts at 5 AM before natural light.

## 7.2 Annotation tool

- Roboflow (roboflow.com) — free tier, browser-based, exports directly to YOLOv8 format, built-in augmentation (rotate/brightness/blur) — good for the low-volume classes like bangles.

- CVAT (cvat.ai, self-hostable) — better fit if client's on-prem data-security requirement extends to annotation stage (footage never leaves premises).

## 7.3 Minimum data volume target before first fine-tune run

| Class | Minimum images | Notes |
| --- | --- | --- |
| Bakery-Head-Cap | 300+ | Seed with hairnet public sets, then majority client footage |
| Bangles | 150+ | Rare occurrence — heavy augmentation required, flag to client if |
|   |   | insufficient in 15-day window |
| Document-in-hand | 250+ | High pose variance (angle held, partial occlusion) |
| Cylinder | 100+ | Low visual variance, fewer images needed |
| Exposed-Item / Cashbox | 150+ each | Zone-specific, moderate variance |

## 8. Fine-Tuning on Kaggle — Full Walkthrough

## 8.1 Upload assets as Kaggle Datasets

- Dataset 1: ppe-weights — upload ppe.pt

- Dataset 2: bakery-dataset — YOLO-format images/labels/data.yaml built in Section 7

- Enable GPU: Kaggle Notebook Settings Accelerator GPU T4 x2 (free tier, 30 hrs/week quota)

## 8.2 Environment setup


```
!pip install ultralytics -q
from ultralytics import YOLO
import torch
print(torch.cuda.is_available(), torch.cuda.get_device_name(0))
```

## 8.3 data.yaml — 17 classes, old 10 preserved + 7 new

> **Note:** `NO-Bakery-Head-Cap` (ID 11) is the violation class paired with `Bakery-Head-Cap` (ID 10). Both must be annotated together — the model needs the negative class to fire cap-missing alerts. IDs 12–16 are shifted by 1 vs the original draft.

```yaml
path: /kaggle/input/bakery-dataset
train: images/train
val: images/val
nc: 17
names:
  0: Hardhat
  1: Mask
  2: NO-Hardhat
  3: NO-Mask
  4: NO-Safety Vest
  5: Person
  6: Safety Cone
  7: Safety Vest
  8: machinery
  9: vehicle
  10: Bakery-Head-Cap       # compliant — cloth cap worn correctly
  11: NO-Bakery-Head-Cap    # violation — cap absent/incorrectly worn
  12: Bangles               # violation — always flagged in food production
  13: Document-in-hand      # neutral — triggers OCR pipeline (sec. 9.5)
  14: Cylinder              # neutral — counted for usage logging
  15: Exposed-Item          # violation — stock kept openly
  16: Cashbox               # neutral — zone anchor for cash monitoring
```

## 8.4 Fine-tune command

```
model = YOLO('/kaggle/input/ppe-weights/ppe.pt')
results = model.train(
data='/kaggle/input/bakery-dataset/data.yaml',
epochs=100,
imgsz=640,
batch=16,
freeze=10, # freeze early backbone layers -> protects old-class knowledge
lr0=0.001, # lower LR than fresh training, this is fine-tuning
patience=20, # early stop if val mAP plateaus
device=0,
project='bakery_finetune',
name='v1'
)
```

freeze=10 is the key safeguard against catastrophic forgetting — it keeps the backbone's learned features for the original 10 classes mostly frozen while the head learns the new 6 classes.

## 8.5 Validate — confirm old classes did not degrade

> **Important:** After `.train()` the `model` object points to the last training checkpoint, not the best checkpoint. Reload `best.pt` explicitly before calling `.val()`, otherwise metrics will be misleading.

```python
# Reload best checkpoint (not last epoch)
best_model = YOLO('bakery_finetune/v1/weights/best.pt')
metrics = best_model.val(data='/kaggle/input/bakery-dataset/data.yaml')

print(f"Overall mAP50:    {metrics.box.map50:.3f}")
print(f"Overall mAP50-95: {metrics.box.map:.3f}")
print()
print("Per-class mAP50-95:")
for i, name in best_model.names.items():
    per_cls = metrics.box.maps[i]
    flag = "⚠️ DEGRADED" if i < 10 and per_cls < 0.60 else ""
    print(f"  {i:2d}  {name:<25} {per_cls:.3f}  {flag}")

# Rule of thumb: if any original class (ID 0-9) drops > 5 points vs baseline,
# increase freeze count (e.g. freeze=15) or reduce lr0 (e.g. lr0=0.0005) and retrain.
```

## 8.6 Export for deployment

```
model.export(format='onnx') # or 'engine' for TensorRT if deploying on Jetson/edge GPU
```


## 9. Tracking + Idle/Zone Rule Engine (Non-ML Layer)

## 9.1 Built-in Ultralytics tracking

```python
results = model.track(
    source='rtsp://camera_ip/stream',
    tracker='bytetrack.yaml',
    persist=True,
    stream=True
)
```

> **FastAPI / asyncio threading warning:** `model.track()` is a blocking generator loop. Running it directly inside an `async` FastAPI WebSocket handler will freeze the entire event loop, blocking all other connections. Wrap it in a background thread:

```python
import asyncio, threading, queue

def _tracking_worker(camera_url: str, result_q: queue.Queue):
    """Blocking loop — runs in a daemon thread, never in the async event loop."""
    for result in model.track(source=camera_url, tracker='bytetrack.yaml',
                               persist=True, stream=True, verbose=False):
        result_q.put(result)  # hand off to async consumer

# In your FastAPI WebSocket handler:
async def ws_camera_stream(websocket: WebSocket, camera_id: str):
    await websocket.accept()
    result_q = queue.Queue(maxsize=5)
    t = threading.Thread(target=_tracking_worker,
                         args=(CAMERA_URLS[camera_id], result_q), daemon=True)
    t.start()
    loop = asyncio.get_event_loop()
    while True:
        result = await loop.run_in_executor(None, result_q.get)
        # process result, send frame back via websocket
```

## 9.2 Zone definition (per camera, polygon coordinates)

```
ZONES = {
"dough_table_1": [(120,80),(320,80),(320,300),(120,300)],
"oven_section": [(400,100),(650,100),(650,350),(400,350)],
"shop_counter": [(50,200),(300,200),(300,450),(50,450)],
}
from shapely.geometry import Point, Polygon
zone_polys = {k: Polygon(v) for k, v in ZONES.items()}
def get_zone(cx, cy):
for name, poly in zone_polys.items():
if poly.contains(Point(cx, cy)):
return name
return None
```

## 9.3 Idle-timer state machine

```python
import time

track_state = {}  # track_id -> {last_pos, last_moved_ts, zone}

IDLE_LIMIT_SEC = {
    "default":        300,   # 5 min — general idle rule
    "camera_standing": 60,   # 1 min — blocking camera alert
    "gas_idle":        600,   # 10 min — stove/oil idle
    "shop_counter":    60,    # 1 min — employee absent from shop
}

# Resolution-adaptive movement threshold.
# A 15px threshold works for 640px-wide frames; scale up for higher-res feeds.
# Formula: 15px * (frame_width / 640). E.g. 1920px wide → threshold = 45px.
FRAME_WIDTH = 1280  # update per camera
MOVE_THRESHOLD_PX = max(10, int(15 * (FRAME_WIDTH / 640)))

def update_track(track_id, cx, cy, zone, now):
    st = track_state.get(track_id,
            {"last_pos": (cx, cy), "last_moved_ts": now, "zone": zone})
    dist = ((cx - st["last_pos"][0])**2 + (cy - st["last_pos"][1])**2) ** 0.5
    if dist > MOVE_THRESHOLD_PX:
        st["last_moved_ts"] = now
        st["last_pos"] = (cx, cy)
        st["zone"] = zone
    track_state[track_id] = st
    idle_for = now - st["last_moved_ts"]
    limit = IDLE_LIMIT_SEC.get(zone, IDLE_LIMIT_SEC["default"])
    if idle_for > limit:
        fire_alert(track_id, zone, idle_for)

def fire_alert(track_id, zone, idle_for):
    print(f"ALERT: track {track_id} idle {idle_for:.0f}s in zone {zone}")
    # push to Alert Dispatcher (Section 10)
```

This same pattern covers: idle>5min (default limit), standing-in-front-of-camera>1min (camera_standing zone), and gas/oil idle>10min (gas_idle zone) — one engine, different per-zone thresholds pulled from client's spec.

## 9.4 Time-of-day compliance (work-start checks)

```
import datetime
SHIFT_START = {"ground_floor": "08:00", "first_floor": "06:00", "second_floor": "05:00"}
def check_shift_start(floor, first_activity_ts):
    expected = datetime.datetime.strptime(SHIFT_START[floor], "%H:%M").time()
    if first_activity_ts.time() > expected:
        fire_alert(f"{floor}_late_start", floor, 0)
```


## 9.5 OCR Pipeline — Document-in-Hand (Invoice / Order Form)

This is a **Phase 1 / P1 feature** — the client's entire inward/outward flow depends on it. When the model detects `Document-in-hand` (class 13) at the entrance zone, crop the bounding box and run OCR to extract and store the text.

```python
# Install: pip install easyocr
import easyocr
import cv2, datetime

_ocr_reader = easyocr.Reader(['en'], gpu=True)  # load once at startup

def scan_document_in_frame(frame: "np.ndarray", bbox: list, direction: str) -> dict:
    """
    Called when 'Document-in-hand' detected at entrance zone.
    direction: 'inward' | 'outward'
    Returns dict with extracted text + metadata for DB storage.
    """
    x1, y1, x2, y2 = bbox
    # Expand crop 10% for margin (handles slight bbox misalignment)
    h, w = frame.shape[:2]
    pad_x = int((x2 - x1) * 0.10)
    pad_y = int((y2 - y1) * 0.10)
    x1c = max(0, x1 - pad_x);  y1c = max(0, y1 - pad_y)
    x2c = min(w, x2 + pad_x);  y2c = min(h, y2 + pad_y)
    crop = frame[y1c:y2c, x1c:x2c]

    # Pre-process: grayscale + sharpen improves OCR accuracy on printed text
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    _, sharp = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    results = _ocr_reader.readtext(sharp)
    extracted_text = " ".join([r[1] for r in results if r[2] > 0.4])  # conf > 0.4

    return {
        "timestamp":      datetime.datetime.now().isoformat(),
        "direction":      direction,          # inward / outward
        "raw_text":       extracted_text,
        "snapshot_b64":   _encode_crop(crop), # store image for audit trail
        "approved":       len(extracted_text.strip()) > 10,  # basic sanity check
    }

# Store result in DB + fire deny-entry alert if approved=False
# This integrates with alert_service.py in the existing backend.
```

> **Limitation to set with client:** OCR accuracy degrades with handwritten forms, poor lighting, or document motion blur. For v1, recommend printed/typed invoices only. Handwritten forms = Phase 2 with a form-OCR fine-tune.

## 9.6 Dirty-Floor and Flame Detection — v1 Heuristic Strategy

Both `dirty-floor` and `flame/gas-idle` were explicitly moved to Phase 4 (R&D). The v1 approach below does **not** require model fine-tuning — it uses OpenCV heuristics.

### Dirty Floor — Client-Provided Clean Reference Photos as Baseline

> **The client will supply photos of how each floor/zone looks when it is clean.** These are used as the reference baseline — the detector compares every live camera frame against the client's clean photo and fires an alert when there is significant deviation. Zero model training required.

**What to request from client:**
- One photo per camera view, from the exact mounted camera angle, after morning cleaning before shift start
- One photo per lighting condition per camera if lighting changes between shifts (e.g. 5 AM lights-off vs 6 AM lights-on)

```
backend/baselines/
├── ground_floor/entrance_cam.jpg     ← client-provided clean photo
├── ground_floor/dough_mixing_cam.jpg
├── first_floor/table_cam_01.jpg
└── second_floor/stove_cam.jpg
```

```python
import cv2, numpy as np, os

class DirtyFloorDetector:
    """
    Compares live frame to client-supplied clean-state photo.
    One instance per camera. Client can update the photo anytime — call reload().
    """
    def __init__(self, baseline_path: str, threshold: float = 0.08):
        raw = cv2.imread(baseline_path, cv2.IMREAD_GRAYSCALE)
        self.baseline = cv2.GaussianBlur(raw, (21, 21), 0)
        self.threshold = threshold
        self.baseline_path = baseline_path

    def reload(self):
        """Hot-reload when client provides an updated clean photo."""
        raw = cv2.imread(self.baseline_path, cv2.IMREAD_GRAYSCALE)
        self.baseline = cv2.GaussianBlur(raw, (21, 21), 0)

    def is_dirty(self, frame: np.ndarray, floor_mask: np.ndarray = None) -> tuple:
        h, w = self.baseline.shape[:2]
        gray = cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (w, h))
        gray = cv2.GaussianBlur(gray, (21, 21), 0)
        diff = cv2.absdiff(self.baseline, gray)
        if floor_mask is not None:
            diff = cv2.bitwise_and(diff, diff, mask=floor_mask)
        _, thresh = cv2.threshold(diff, 30, 255, cv2.THRESH_BINARY)
        fraction = thresh.sum() / (255 * thresh.size)
        return fraction > self.threshold, round(fraction, 4)

# Alert only after 5 consecutive dirty detections — avoids false positives
# from workers momentarily walking through the zone.
# threshold=0.08 (8% of frame changed) is a good starting point; tune per zone.
```

### Flame / Gas-Idle — Pre-Trained Fire Model (Separate Inference Pass)

Do NOT bake `flame` into the fine-tuned ppe_factory.pt — it adds annotation burden with low payoff. Use a **dedicated pre-trained fire detector** as a separate inference pass only on the second-floor stove camera:

```python
# Use D-Fire trained YOLOv8 (21K images, publicly available)
# Download from: https://github.com/gaiasd/DFireDataset
from ultralytics import YOLO
fire_model = YOLO('yolov8_dfire.pt')  # pre-trained on D-Fire dataset

class FlameIdleMonitor:
    def __init__(self, idle_limit_sec: int = 600):  # 10 min
        self.flame_first_seen: dict = {}  # zone_id -> first flame timestamp
        self.idle_limit = idle_limit_sec
        self.person_in_zone: dict = {}    # zone_id -> bool (from main model)

    def update(self, zone_id: str, frame: "np.ndarray", person_present: bool, now: float):
        results = fire_model(frame, conf=0.35, verbose=False)
        flame_detected = any(
            fire_model.names[int(b.cls[0])] in ('fire', 'smoke')
            for r in results for b in r.boxes
        )
        if flame_detected:
            self.flame_first_seen.setdefault(zone_id, now)
            self.person_in_zone[zone_id] = person_present
            idle_duration = now - self.flame_first_seen[zone_id]
            # Alert if flame on + no person supervising + > 10 min
            if not person_present and idle_duration > self.idle_limit:
                fire_alert(f"flame_idle_{zone_id}", zone_id, idle_duration)
        else:
            self.flame_first_seen.pop(zone_id, None)  # reset on flame off
```


## 10. Storage, Alerts, Dashboard (Client's Explicit Constraints)

| Requirement (from client doc) | Implementation |
| --- | --- |
| All data stored on premise | Local server/NAS. Postgres/SQLite for events+metadata, raw video |
|   | on NAS, no cloud upload. |
| Mobile notifications compulsory | Firebase Cloud Messaging — works with on-prem backend, only |
|   | push relay leaves premises (no video data). |
| Dashboard clean, easy to understand | Streamlit (matches existing stack) for v1; Grafana for production if |
|   | scaling to many cameras. |
| Data security | Encrypt at rest (LUKS/BitLocker on NAS), role-based access on |
|   | dashboard, TLS on local network for camera streams. |

## 11. Phased Delivery Roadmap

> **Annotation dependency:** Phases 1 and 3 both require labeled client footage. Start annotation work (Section 7) in parallel with Phase 2 engineering work — do not wait. Bangles, Document-in-hand, and Cashbox annotations must be collected during Phase 2 so Phase 3 training is not blocked.

| Phase | Scope | Depends on |
| --- | --- | --- |
| 1 | PPE compliance (cap+NO-cap / mask / vest) + entry-exit doc scan via OCR (Section 9.5) | Annotate Bakery-Head-Cap + NO-Bakery-Head-Cap + Document-in-hand. Run fine-tune on Kaggle. Deploy OCR pipeline. |
| 2 | Idle-time monitoring all floors + shop, shift-start checks, camera-down alerts | ByteTrack + rule engine only (Section 9). No new model needed. Can be built while Phase 1 annotation is in progress. |
| 3 | New object classes: bangles, cylinders, cashbox, exposed-items | Full annotation pipeline (Section 7) completed. Retrain model to add IDs 12-16. |
| 4 | Hard problems: chewing (MediaPipe), cleanliness v1 (frame-diff, Section 9.6), gas-idle v1 (D-Fire model, Section 9.6), cash-in-pocket | Set separate R&D expectations + timeline with client. Accuracy ceiling is real — document limitations before starting. |

## 12. Risks & Client Expectation Notes

- **NO-Bakery-Head-Cap annotation volume:** If the 15-day archive has few frames of workers without caps (e.g. only before shift starts), augment aggressively (crop, rotate, brightness shifts) and flag the risk to the client before committing to an accuracy number.

- **Bangles / Exposed-Items / Cashbox:** Zero public data — accuracy fully depends on how much footage the 15-day archive actually contains for these rare events. If under-represented, flag to client before promising a deadline.

- **Cleanliness detection (dirty-floor):** Use the frame-difference heuristic (Section 9.6) as v1. It requires one-time baseline photograph per zone per camera. Expected accuracy: ~70-80% for obvious debris; misses subtle dirt. Not suitable as sole evidence for disciplinary action — recommend human review of flagged frames.

- **Gas/oil idle >10min:** The D-Fire pre-trained model (Section 9.6) achieves ~85% precision on open-flame detection in good lighting. Steam/vapor from boiling water is significantly harder — expected recall ~40-60% for steam. Set this expectation explicitly and recommend dedicated IoT gas sensor as a reliable fallback.

- **Cash-in-pocket detection:** Visual-only detection has a real accuracy ceiling. Hand-to-pocket gesture is a ~3-5 frame event at typical 25fps — requires action recognition, not object detection. Best-effort v1 accuracy: ~50-60%. Recommend pairing with a cashbox-open sensor (hardware) for reliable monitoring.

- **Catastrophic forgetting risk during fine-tune:** Always validate old-class mAP after each training run before deploying a new checkpoint (Section 8.5). If any original class (ID 0-9) drops >5 mAP points, increase `freeze` count or reduce `lr0` and retrain.

- **helmet_model.pt audit reminder:** Bakery cloth caps are visually very different from rigid construction hardhats. Run a side-by-side val test on 50 sample bakery-cap frames before deciding whether to use `helmet_model.pt` for cap detection or rely on the fine-tuned `Bakery-Head-Cap` class exclusively.

End of document.
